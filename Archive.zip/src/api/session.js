import { apiEndpoints, httpMethods } from "../constants/api.constants";
import i18n from "../i18n/config";
import { setLoader } from "../redux/slices/loader.slices";
import { setUserProfile } from "../redux/slices/userProfile.slices";
import store from "../redux/store";
import axiosInstance from "./api";

const getSessionDetails = async ({ needLoader = true, options = {} } = {}) => {
  if (needLoader) store.dispatch(setLoader({ name: "session" }));
  try {
    const headers = { "Accept-Language": i18n.resolvedLanguage };
    const response = await axiosInstance({
      method: httpMethods.get,
      url: apiEndpoints.session,
      headers,
      ...options,
    });

    store.dispatch(setUserProfile(response.data?.data));
    return response;
  } catch (error) {
    return Promise.resolve(error);
  } finally {
    if (needLoader) store.dispatch(setLoader({ name: "session" }));
  }
};

export default getSessionDetails;
