import { Currency, Date } from "../shared/icon";

export const loaderPath = {
  bankTransferRequests: "bank-transfer-requests",
  confirmBankTransferRequest: "confirm-bank-transfer-request",
  bankTransferDetails: "bank-transfer-request-details",
};

export const bankTransferTableColumns = [
  { key: "request_type", label: "request-type" },
  { key: "requested_from", label: "requested-from" },
  { key: "amount", label: "amount" },
  { key: "status", label: "status" },
  { key: "created_at", label: "created-at" },
  { key: "action", label: "action", align: "center" },
  { key: "confirmation", label: "confirmation" },
];

const transactionTypeOption = [
  { label: "deposit", value: "DEPOSIT" },
  { label: "withdrawal", value: "WITHDRAWAL" },
];

const statusOption = [
  { label: "pending", value: "PENDING" },
  { label: "success", value: "SUCCESS" },
  { label: "failed", value: "FAILED" },
];

export const bankTransferFilterFields = [
  {
    name: "transaction_type",
    formLabel: "transaction-type",
    placeholder: "transaction-type-placeholder",
    type: "select",
    size: { xs: 12 },
    isMultiple: true,
    options: transactionTypeOption,
  },
  {
    name: "status",
    formLabel: "status",
    placeholder: "status-placeholder",
    type: "select",
    size: { xs: 12 },
    isMultiple: true,
    options: statusOption,
  },
  {
    type: "number",
    name: "min_amount",
    formLabel: "min-amount",
    placeholder: "min-amount",
    startAdornment: <Currency />,
    size: { xs: 12 },
  },
  {
    type: "number",
    name: "max_amount",
    formLabel: "max-amount",
    placeholder: "max-amount",
    startAdornment: <Currency />,
    size: { xs: 12 },
  },
  {
    type: "date",
    name: "start_date",
    formLabel: "start-date",
    placeholder: "start-date",
    startAdornment: <Date fill="black" />,
    size: { xs: 12 },
  },
  {
    type: "date",
    name: "end_date",
    formLabel: "end-date",
    placeholder: "end-date",
    startAdornment: <Date fill="black" />,
    size: { xs: 12 },
  },
];

export const defaultBankTransferFilterValues = {
  status: "",
  end_date: "",
  min_amount: "",
  max_amount: "",
  start_date: "",
  business_name: "",
  transaction_type: "",
};

export const confirmationModalFields = [
  {
    name: "remark",
    formLabel: "remark",
    placeholder: "remark-placeholder",
    type: "text",
    registerOptions: {
      maxLength: {
        value: 500,
        message: "remark-max-length-error",
      },
    },
    size: { xs: 12 },
  },
];
