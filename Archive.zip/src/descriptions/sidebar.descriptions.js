import {
  Admin,
  Bank,
  Businesses,
  GroupNetwork,
  MusharkaContract,
  Request,
  Settings,
  Transaction,
} from "../shared/icon";

export const adminSidebarMenu = {
  ADMIN: [
    {
      label: "businesses",
      icon: <Businesses />,
      path: "/businesses",
    },
    {
      label: "sub-admins",
      icon: <Admin />,
      path: "/sub-admins",
    },
    {
      label: "transactions",
      icon: <Transaction />,
      path: "/transactions",
    },
    {
      label: "purchase-requests",
      icon: <Request />,
      path: "/purchase-requests",
    },
    {
      label: "bank-transfer-requests",
      icon: <Bank />,
      path: "/bank-transfer-requests",
    },
    {
      label: "metals-stones-pools",
      icon: <GroupNetwork />,
      path: "/metals-stones-pools",
    },
    {
      label: "musharka-contracts",
      icon: <MusharkaContract />,
      path: "/musharka-contracts",
    },
    {
      label: "settings",
      icon: <Settings />,
      path: "/settings/general-settings",
      list: [
        { label: "general-settings", path: "/settings/general-settings" },
        { label: "tax-settings", path: "/settings/tax-settings" },
        { label: "metal-stone-setting", path: "/settings/metal-stone-setting" },
        { label: "product-setting", path: "/settings/product-setting" },
        { label: "bank-settings", path: "/settings/bank-setting" },
      ],
    },
  ],
  TAQABETH_ENFORCER: [
    {
      label: "settings",
      path: "/settings",
    },
  ],
  JEWELLERY_INSPECTOR: [
    {
      label: "settings",
      path: "/settings",
    },
  ],
  JEWELLERY_BUYER: [
    {
      label: "settings",
      path: "/settings",
    },
  ],
};

export const userSidebarMenu = {
  INVESTOR: [
    {
      label: "settings",
      path: "/settings",
    },
  ],
  MANUFACTURER: [
    {
      label: "settings",
      path: "/settings",
    },
  ],
  JEWELER: [
    {
      label: "settings",
      path: "/settings",
    },
  ],
  SELLER: [
    {
      label: "settings",
      path: "/settings",
    },
  ],
};
