import { Email, Lock, Money, User, UserSystem } from "../../shared/icon";
import { emailRegex, nameRegex } from "../../utils/regex";

const allowNotifications = [
  { value: "yes", label: "yes" },
  { value: "no", label: "no" },
];

const languageOption = [
  { value: "en", label: "English" },
  { value: "ar", label: "العربية - AR" },
];

export const loaderPath = {
  generalSettings: "settings-general-settings",
};

export const defaultValues = {
  name: "",
  email: "",
  password: "",
  confirmPassword: "",
  allow_notifications: "",
  notification_language: "",
  currency: "",
};

export const fields = [
  {
    type: "text",
    name: "name",
    formLabel: "name",
    placeholder: "name",
    required: true,
    startAdornment: <User />,
    size: { xs: 6 },
    registerOptions: {
      required: {
        value: true,
        message: "email-required-error",
      },
      pattern: {
        value: nameRegex,
        message: "invalid-email-error",
      },
    },
  },
  {
    type: "text",
    name: "email",
    formLabel: "email",
    placeholder: "email",
    required: true,
    startAdornment: <Email />,
    size: { xs: 6 },
    registerOptions: {
      required: {
        value: true,
        message: "email-required-error",
      },
      pattern: {
        value: emailRegex,
        message: "invalid-email-error",
      },
    },
  },
  {
    type: "password",
    name: "password",
    formLabel: "password",
    placeholder: "password",
    required: true,
    startAdornment: <Lock />,
    size: { xs: 6 },
    registerOptions: {
      required: {
        value: true,
        message: "password-required-error",
      },
    },
  },
  {
    type: "password",
    name: "confirmPassword",
    formLabel: "confirm password",
    placeholder: "confirm password",
    required: true,
    startAdornment: <Lock />,
    size: { xs: 6 },
    registerOptions: {
      required: {
        value: true,
        message: "confirm-password-required-error",
      },
    },
  },
  {
    name: "allow_notifications",
    formLabel: "allow-notifications",
    placeholder: "allow-notifications",
    type: "select",
    startAdornment: <UserSystem />,
    options: allowNotifications,
    registerOptions: {
      required: {
        value: true,
        message: "allow_notifications-required-error",
      },
    },
    size: { xs: 6 },
  },
  {
    name: "notification_language",
    formLabel: "notification-language",
    placeholder: "notification-language-placeholder",
    type: "select",
    startAdornment: <UserSystem />,
    options: languageOption,
    registerOptions: {
      required: {
        value: true,
        message: "notification_language-required-error",
      },
    },
    size: { xs: 6 },
  },
  {
    name: "currency",
    formLabel: "currency",
    placeholder: "currency-placeholder",
    type: "select",
    options: [],
    startAdornment: <Money />,
    registerOptions: {
      required: {
        value: true,
        message: "currency-required-error",
      },
    },
    size: { xs: 6 },
  },
];

export const settingTabList = [
  { label: "general-settings", value: "generalSettings" },
  { label: "tax-settings", value: "taxSettings" },
  { label: "metal-stone-setting", value: "metalSettings" },
];
