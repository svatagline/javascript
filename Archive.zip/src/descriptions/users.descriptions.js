import { Email, PurchaseManagement, Users } from "../shared/icon";

export const loaderPath = {
  usersLoading: "users",
  userDetailsLoading: "userDetails",
  userSuspendLoading: "userSuspend",
};

export const userTableColumns = [
  { key: "full_name", label: "user-name" },
  { key: "email", label: "email" },
  // { key: "phone_number", label: "phone-number" },
  { key: "user_type", label: "user-type" },
  { key: "action", label: "action", align: "center" },
];

const roleOption = [
  { label: "investor", value: "INVESTOR" },
  { label: "seller", value: "SELLER" },
  { label: "jeweler", value: "JEWELER" },
  { label: "manufacturer", value: "MANUFACTURER" },
];

export const userFilterFields = [
  {
    name: "role",
    formLabel: "role",
    placeholder: "system-role",
    startAdornment: <Users />,
    type: "autocomplete",
    size: { xs: 12 },
    isMultiple: true,
    options: roleOption,
  },
  {
    type: "text",
    name: "email",
    formLabel: "email",
    placeholder: "email",
    startAdornment: <Email />,
    size: { xs: 12 },
  },
  // {
  //   type: "text",
  //   name: "fullname",
  //   formLabel: "fullname",
  //   placeholder: "fullname",
  //   startAdornment: <User />,
  //   size: { xs: 12 },
  // },
  {
    type: "text",
    name: "business_name",
    formLabel: "business-name",
    placeholder: "business-name",
    startAdornment: <PurchaseManagement />,
    size: { xs: 12 },
  },
];

export const defaultUserFilterValues = {
  role: "",
  email: "",
  // fullname: "",
  business_name: "",
};

export const changeAccountStatusFormFields = [
  {
    name: "suspend_reason",
    formLabel: "suspend-reason",
    placeholder: "suspend-reason-placeholder",
    type: "text",
    registerOptions: {
      maxLength: {
        value: 500,
        message: "suspend-reason-max-length-error",
      },
    },
    size: { xs: 12 },
  },
];
