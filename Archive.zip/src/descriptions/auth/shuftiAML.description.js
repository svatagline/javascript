export const loaderPath = {
  shuftiAML: "shufti-aml-verification",
};
