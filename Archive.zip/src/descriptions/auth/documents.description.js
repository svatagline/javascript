export const loaderPath = {
  uploadDocumentS3: "upload-documents-s3",
  uploadAllDocuments: "upload-all-documents",
};
