import {
  businessNameRegex,
  emailRegex,
  nameRegex,
  passwordRegex,
} from "../../utils/regex";

export const loaderPath = {
  register: "register-user",
  shuftiVerification: "shufti-email-number-verification",
};

export const defaultValues = {
  first_name: "",
  last_name: "",
  middle_name: "",
  business_name: "",
  email: "",
  phone_number: "",
};

export const fields = [
  {
    type: "text",
    name: "first_name",
    formLabel: "first-name",
    placeholder: "first-name",
    size: { md: 4, xs: 12 },
    registerOptions: {
      required: { value: true, message: "first-name-required-error" },
      pattern: { value: nameRegex, message: "first-name-invalid-error" },
      minLength: { value: 2, message: "first-name-min-length-error" },
      maxLength: { value: 50, message: "first-name-max-length-error" },
    },
  },
  {
    type: "text",
    name: "middle_name",
    formLabel: "middle-name",
    placeholder: "middle-name",
    size: { md: 4, xs: 12 },
    registerOptions: {
      required: { value: true, message: "middle-name-required-error" },
      pattern: { value: nameRegex, message: "middle-name-invalid-error" },
      minLength: { value: 1, message: "middle-name-min-length-error" },
      maxLength: { value: 50, message: "middle-name-max-length-error" },
    },
  },
  {
    type: "text",
    name: "last_name",
    formLabel: "last-name",
    placeholder: "last-name",
    size: { md: 4, xs: 12 },
    registerOptions: {
      required: { value: true, message: "last-name-required-error" },
      pattern: { value: nameRegex, message: "last-name-invalid-error" },
      minLength: { value: 2, message: "last-name-min-length-error" },
      maxLength: { value: 50, message: "last-name-max-length-error" },
    },
  },
  {
    type: "text",
    name: "business_name",
    formLabel: "business-name",
    placeholder: "business-name",
    size: { xs: 12 },
    registerOptions: {
      required: { value: true, message: "business-name-required-error" },
      maxLength: { value: 100, message: "business-name-max-length-error" },
      pattern: {
        value: businessNameRegex,
        message: "business-name-invalid-error",
      },
    },
  },
  {
    type: "text",
    name: "email",
    formLabel: "email",
    placeholder: "email-address",
    helperText: "general-details-email-helper-text",
    size: { xs: 12 },
    registerOptions: {
      required: { value: true, message: "email-required-error" },
      pattern: { value: emailRegex, message: "invalid-email-error" },
    },
  },
  {
    type: "phone",
    name: "phone_number",
    formLabel: "phone-number",
    placeholder: "phone-number",
    helperText: "general-details-phone-number-helper-text",
    size: { xs: 12 },
    registerOptions: {
      required: { value: true, message: "phone-number-required-error" },
    },
  },
  {
    type: "password",
    name: "password",
    formLabel: "password",
    placeholder: "password",
    size: { xs: 12 },
    registerOptions: {
      required: { value: true, message: "password-required-error" },
      minLength: { value: 8, message: "password-min-length-error" },
      maxLength: { value: 28, message: "password-max-length-error" },
      pattern: { value: passwordRegex, message: "password-pattern-error" },
    },
  },
];
