import { Lock } from "../../shared/icon";
import { passwordRegex } from "../../utils/regex";

export const defaultValues = {
  email: "",
};

export const loaderPath = {
  resetPassword: "reset-password",
};

export const fields = [
  {
    type: "password",
    name: "password",
    formLabel: "password",
    placeholder: "password",
    required: true,
    startAdornment: <Lock />,
    size: { xs: 12 },
    registerOptions: {
      required: {
        value: true,
        message: "password-required-error",
      },
      minLength: {
        value: 8,
        message: "password-min-length-error",
      },
      pattern: {
        value: passwordRegex,
        message: "password-pattern-error",
      },
    },
  },
  {
    type: "password",
    name: "confirmPassword",
    formLabel: "confirm-password",
    placeholder: "confirm-password",
    size: { xs: 12 },
    required: true,
    startAdornment: <Lock />,
    registerOptions: {
      required: {
        value: true,
        message: "confirm-password-required-error",
      },
    },
  },
];
