import { INVESTOR, JEWELER, MANUFACTURER, SELLER } from "../../constants";
import { BitcoinMoney, Document, Lock2, Wallet } from "../../shared/icon";

export const userRoles = {
  refinery: {
    name: "refinery",
    title: "refinery-user-description",
    icon: <Lock2 />,
    role: SELLER,
  },
  investor: {
    name: "investor",
    title: "investor-user-description",
    icon: <Document />,
    isIndividual: true,
    role: INVESTOR,
  },
  manufacturer: {
    name: "manufacturer",
    title: "manufacturer-user-description",
    icon: <BitcoinMoney />,
    role: MANUFACTURER,
  },
  "jewelry-designer": {
    name: "jewelry-designer",
    title: "refinery-user-description",
    isIndividual: true,
    icon: <Wallet />,
    role: JEWELER,
  },
};

export const loaderPath = {
  getAddresses: "get-user-addresses",
};
