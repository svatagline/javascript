import { Email, Lock } from "../../shared/icon";
import { emailRegex } from "../../utils/regex";
export const defaultValues = {
  email: "",
  password: "",
};

export const loaderPath = {
  login: "login",
};

export const fields = [
  {
    type: "text",
    name: "email",
    formLabel: "email",
    placeholder: "email",
    required: true,
    startAdornment: <Email />,
    size: { xs: 12 },
    registerOptions: {
      required: {
        value: true,
        message: "email-required-error",
      },
      pattern: {
        value: emailRegex,
        message: "invalid-email-error",
      },
    },
  },
  {
    type: "password",
    name: "password",
    formLabel: "password",
    placeholder: "password",
    required: true,
    startAdornment: <Lock />,
    size: { xs: 12 },
    registerOptions: {
      required: {
        value: true,
        message: "password-required-error",
      },
    },
  },
];
