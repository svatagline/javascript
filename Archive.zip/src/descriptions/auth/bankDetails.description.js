import { alphaNumericRegex } from "../../utils/regex";

const bahrainBanks = [
  { label: "ahli_united_bank_bsc", value: "ahli_united_bank_bsc" },
  { label: "arab_bank_plc_bahrain", value: "arab_bank_plc_bahrain" },
  {
    label: "arab_banking_corporation_bsc",
    value: "arab_banking_corporation_bsc",
  },
  {
    label: "allied_bank_limited_wholesale_branch",
    value: "allied_bank_limited_wholesale_branch",
  },
  {
    label: "alubaf_arab_international_bank_bahrain_bsc_c",
    value: "alubaf_arab_international_bank_bahrain_bsc_c",
  },
  {
    label: "the_arab_investment_company_saa",
    value: "the_arab_investment_company_saa",
  },
  {
    label: "arab_petroleum_investment_corporation",
    value: "arab_petroleum_investment_corporation",
  },
  {
    label: "askari_wholesale_bank_bahrain",
    value: "askari_wholesale_bank_bahrain",
  },
  { label: "bnp_paribas_crb_bahrain", value: "bnp_paribas_crb_bahrain" },
  {
    label: "bahrain_development_bank_bsc",
    value: "bahrain_development_bank_bsc",
  },
  {
    label: "bank_of_bahrain_and_kuwait_bsc",
    value: "bank_of_bahrain_and_kuwait_bsc",
  },
  {
    label: "bahrain_middle_east_bank_bsc",
    value: "bahrain_middle_east_bank_bsc",
  },
  { label: "rafidain_bank_bahrain", value: "rafidain_bank_bahrain" },
  { label: "sico_bank", value: "sico_bank" },
  {
    label: "the_saudi_national_bank_bahrain",
    value: "the_saudi_national_bank_bahrain",
  },
  {
    label: "standard_chartered_bank_bahrain_limited",
    value: "standard_chartered_bank_bahrain_limited",
  },
  {
    label: "state_bank_of_india_branch_bahrain",
    value: "state_bank_of_india_branch_bahrain",
  },
  { label: "the_housing_bank_bahrain", value: "the_housing_bank_bahrain" },
  { label: "ziraat_bank_bahrain_branch", value: "ziraat_bank_bahrain_branch" },
  { label: "halkbank_bahrain_branch", value: "halkbank_bahrain_branch" },
  { label: "isbank_bahrain_branch", value: "isbank_bahrain_branch" },
  {
    label: "united_bank_limited_bahrain",
    value: "united_bank_limited_bahrain",
  },
  {
    label: "ubs_ag_manama_representative_office",
    value: "ubs_ag_manama_representative_office",
  },
  { label: "united_gulf_bank_bsc_c", value: "united_gulf_bank_bsc_c" },
  { label: "vakifbank_bahrain_branch", value: "vakifbank_bahrain_branch" },
  { label: "woori_bank_bahrain", value: "woori_bank_bahrain" },
  { label: "yapi_kredi_bahrain_branch", value: "yapi_kredi_bahrain_branch" },
  {
    label: "hsbc_bank_middle_east_limited_bahrain",
    value: "hsbc_bank_middle_east_limited_bahrain",
  },
  { label: "hdfc_bank_limited_bahrain", value: "hdfc_bank_limited_bahrain" },
  { label: "icici_bank_bahrain_branch", value: "icici_bank_bahrain_branch" },
  {
    label: "jpmorgan_chase_bank_na_bahrain",
    value: "jpmorgan_chase_bank_na_bahrain",
  },
  { label: "js_bank_bahrain_branch", value: "js_bank_bahrain_branch" },
  {
    label: "keb_hana_bank_bahrain_branch",
    value: "keb_hana_bank_bahrain_branch",
  },
  {
    label: "mcb_wholesale_bank_branch_manama_bahrain",
    value: "mcb_wholesale_bank_branch_manama_bahrain",
  },
  { label: "mufg_bank_bahrain_branch", value: "mufg_bank_bahrain_branch" },
  { label: "mashreqbank_psc_bahrain", value: "mashreqbank_psc_bahrain" },
  {
    label: "national_bank_of_bahrain_bsc",
    value: "national_bank_of_bahrain_bsc",
  },
  {
    label: "national_bank_of_kuwait_sakp_bahrain",
    value: "national_bank_of_kuwait_sakp_bahrain",
  },
  {
    label: "national_bank_of_pakistan_bahrain",
    value: "national_bank_of_pakistan_bahrain",
  },
  {
    label: "palestine_investment_bank_bahrain",
    value: "palestine_investment_bank_bahrain",
  },
  {
    label: "bank_al_habib_wholesale_branch_manama",
    value: "bank_al_habib_wholesale_branch_manama",
  },
  { label: "bank_alfalah_bahrain", value: "bank_alfalah_bahrain" },
  { label: "bank_of_jordan_bahrain", value: "bank_of_jordan_bahrain" },
  {
    label: "citibank_na_kingdom_of_bahrain",
    value: "citibank_na_kingdom_of_bahrain",
  },
  {
    label: "credit_libanais_sal_bahrain",
    value: "credit_libanais_sal_bahrain",
  },
  { label: "cairo_amman_bank_bahrain", value: "cairo_amman_bank_bahrain" },
  {
    label: "citicorp_banking_corporation",
    value: "citicorp_banking_corporation",
  },
  { label: "denizbank_as_bahrain", value: "denizbank_as_bahrain" },
  { label: "eskan_bank_bsc_c", value: "eskan_bank_bsc_c" },
  { label: "qnb_finansbank_as_bahrain", value: "qnb_finansbank_as_bahrain" },
  {
    label: "first_abu_dhabi_bank_bahrain_branch",
    value: "first_abu_dhabi_bank_bahrain_branch",
  },
  {
    label: "gulf_international_bank_bsc",
    value: "gulf_international_bank_bsc",
  },
  {
    label: "habib_bank_limited_hbl_bahrain",
    value: "habib_bank_limited_hbl_bahrain",
  },
];

export const loaderPath = {
  bankAccount: "add-user-bank-account",
};

export const defaultValues = {
  bank_name: "",
  account_number: "",
  account_name: "",
};

export const fields = [
  {
    type: "autocomplete",
    name: "bank_name",
    formLabel: "bank-name",
    placeholder: "select-the-bank",
    size: { xs: 12 },
    options: bahrainBanks,
    registerOptions: {
      required: {
        value: true,
        message: "bank-name-required-error",
      },
    },
  },
  {
    type: "text",
    name: "account_number",
    formLabel: "account-number",
    placeholder: "account-number",
    size: { xs: 12 },
    registerOptions: {
      required: {
        value: true,
        message: "account-number-required-error",
      },
      pattern: {
        value: alphaNumericRegex,
        message: "account-number-invalid-error",
      },
      maxLength: {
        value: 50,
        message: "account-number-max-length-error",
      },
    },
  },
  {
    type: "text",
    name: "account_name",
    formLabel: "account-name",
    placeholder: "account-name",
    size: { xs: 12 },
    registerOptions: {
      required: {
        value: true,
        message: "account-name-required-error",
      },
      minLength: {
        value: 2,
        message: "account-name-min-length-error",
      },
      maxLength: {
        value: 100,
        message: "account-name-max-length-error",
      },
    },
  },
];
