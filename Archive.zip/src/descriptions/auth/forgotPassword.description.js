import { Email } from "../../shared/icon";
import { emailRegex } from "../../utils/regex";

export const defaultValues = {
  email: "",
};

export const loaderPath = {
  forgotPassword: "forgot-password",
  verifyOTP: "verify-otp",
  resendOTP: "resend-otp",
};

export const fields = [
  {
    type: "text",
    name: "email",
    formLabel: "email",
    placeholder: "enter-email-address",
    required: true,
    startAdornment: <Email />,
    size: { xs: 12 },
    registerOptions: {
      required: {
        value: true,
        message: "email-required-error",
      },
      pattern: {
        value: emailRegex,
        message: "invalid-email-error",
      },
    },
  },
];
