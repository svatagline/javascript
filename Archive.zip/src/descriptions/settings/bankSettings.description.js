import { Bank, IFBNCode, NumberIcon, SwiftCode, User } from "../../shared/icon";
import { alphaNumericRegex } from "../../utils/regex";

export const loaderPath = {
  bankSettings: "settings-bank-settings",
};

export const defaultValues = {
  account_name: "",
  bank_name: "",
  account_number: "",
  iban_code: "",
  swift_code: "",
  branch_code: "",
};

export const fields = [
  {
    name: "account_name",
    formLabel: "account-name",
    placeholder: "account-name-placeholder",
    type: "text",
    registerOptions: {
      required: {
        value: true,
        message: "account-name-required-error",
      },
      minLength: {
        value: 2,
        message: "account-name-min-length-error",
      },
      maxLength: {
        value: 100,
        message: "account-name-max-length-error",
      },
    },
    startAdornment: <User />,
    size: { xs: 4 },
  },
  {
    name: "bank_name",
    formLabel: "bank-name",
    placeholder: "bank-name-placeholder",
    type: "text",
    registerOptions: {
      required: {
        value: true,
        message: "bank-name-required-error",
      },
    },
    startAdornment: <Bank />,
    size: { xs: 4 },
  },
  {
    name: "account_number",
    formLabel: "account-number",
    placeholder: "account-number-placeholder",
    type: "text",
    registerOptions: {
      required: {
        value: true,
        message: "account-number-required-error",
      },
      pattern: {
        value: alphaNumericRegex,
        message: "account-number-invalid-error",
      },
      maxLength: {
        value: 50,
        message: "account-number-max-length-error",
      },
    },
    startAdornment: <NumberIcon />,
    size: { xs: 4 },
  },
  {
    name: "iban_code",
    formLabel: "iban-code",
    placeholder: "iban-code-placeholder",
    type: "text",
    registerOptions: {
      required: {
        value: true,
        message: "iban-code-required-error",
      },
      maxLength: {
        value: 50,
        message: "iban-max-length-error",
      },
    },
    startAdornment: <IFBNCode />,
    size: { xs: 4 },
  },
  {
    name: "swift_code",
    formLabel: "swift-code",
    placeholder: "swift-code-placeholder",
    type: "text",
    registerOptions: {
      required: {
        value: true,
        message: "swift-code-required-error",
      },
      maxLength: {
        value: 20,
        message: "swift-code-max-length-error",
      },
    },
    startAdornment: <SwiftCode />,
    size: { xs: 4 },
  },
];
