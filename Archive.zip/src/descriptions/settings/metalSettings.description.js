import { Metals } from "../../shared/icon";

const metalsOptions = [
  { label: "Gold", value: "gold" },
  { label: "Silver", value: "silver" },
  { label: "Platinum", value: "platinum" },
  { label: "Palladium", value: "palladium" },
];

export const loaderPath = {
  metalSettings: "settings-metal-settings",
};

export const defaultValues = {
  metals: "",
  select_metals: "",
};

export const fields = [
  {
    name: "metals",
    formLabel: "metals",
    placeholder: "metals-placeholder",
    type: "select",
    size: { xs: 6 },
    startAdornment: <Metals />,
    registerOptions: {
      required: {
        value: true,
        message: "metals-required-error",
      },
    },
    options: [],
  },
  {
    name: "select_metals",
    formLabel: "select-metals",
    placeholder: "select-metals",
    type: "autocomplete",
    size: { xs: 6 },
    isMultiple: true,
    registerOptions: {
      required: {
        value: true,
        message: "select_metals-required-error",
      },
    },
    options: metalsOptions,
  },
];
