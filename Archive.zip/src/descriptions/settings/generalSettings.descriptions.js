import currencyCodes from "currency-codes";

import { positiveNumber } from "../../utils/regex";
import { countries } from "../auth/addressDetail.descriotion";

export const loaderPath = {
  currency: "settings-currency",
  organization: "settings-organization",
  addCurrency: "settings-add-currency",
  updateCurrency: "settings-update-currency",
};

export const columns = [
  { key: "currency", label: "currency" },
  { key: "rate", label: "rate" },
  { key: "actions", label: "actions" },
];

export const defaultValues = {
  name: "",
  description: "",
  country: "",
  address: "",
  currency: "",
};

export const fields = [
  {
    name: "name",
    formLabel: "name",
    placeholder: "name-placeholder",
    type: "text",
    disabled: true,
    size: { xs: 12 },
  },
  {
    name: "description",
    formLabel: "description",
    placeholder: "description-placeholder",
    type: "text",
    registerOptions: {
      required: { value: true, message: "description-required-error" },
      minLength: { value: 5, message: "description-min-length-error" },
      maxLength: { value: 500, message: "description-max-length-error" },
    },
    size: { xs: 12 },
  },
  {
    type: "autocomplete",
    name: "country",
    formLabel: "country",
    size: { xs: 12 },
    placeholder: "country-placeholder",
    options: countries,
    registerOptions: {
      required: { value: true, message: "country-required-error" },
    },
  },
  {
    name: "address",
    formLabel: "address",
    placeholder: "address-placeholder",
    type: "text",
    registerOptions: {
      required: { value: true, message: "address-required-error" },
      minLength: { value: 5, message: "address-min-length-error" },
      maxLength: { value: 200, message: "address-max-length-error" },
    },
    size: { xs: 12 },
  },
];

export const settingTabList = [
  { label: "general-settings", value: "generalSettings" },
  { label: "tax-settings", value: "taxSettings" },
  { label: "metal-stone-setting", value: "metalSettings" },
];

export const addCurrencyDefaultValues = {
  currency_code: "",
  rate: "",
};

export const addCurrencyFields = [
  {
    name: "currency_code",
    formLabel: "currency-code",
    placeholder: "currency-code-placeholder",
    type: "autocomplete",
    registerOptions: {
      required: { value: true, message: "currency-code-required-error" },
    },
    size: { xs: 12 },
    options: currencyCodes.codes().map((code) => ({
      label: `${code} - ${currencyCodes.code(code)?.currency}`,
      value: code,
    })),
  },
  {
    name: "rate",
    formLabel: "currency-rate",
    placeholder: "currency-rate-placeholder",
    type: "number",
    registerOptions: {
      required: { value: true, message: "currency-rate-required-error" },
      maxLength: { value: 10, message: "currency-rate-max-length-error" },
      pattern: {
        value: positiveNumber,
        message: "currency-rate-positive-value-error",
      },
    },
    size: { xs: 12 },
    inputProps: { step: "any" },
  },
];
