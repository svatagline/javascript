import AccountBalanceWalletOutlinedIcon from "@mui/icons-material/AccountBalanceWalletOutlined";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import PaymentOutlinedIcon from "@mui/icons-material/PaymentOutlined";

export const loaderPath = { taxSettings: "settings-tax-settings" };

export const defaultValues = { vat: "", taxes: "", platform_fee: "" };

export const fields = [
  {
    name: "taxes",
    formLabel: "taxes-label",
    placeholder: "taxes-placeholder",
    type: "number",
    startAdornment: (
      <DescriptionOutlinedIcon sx={{ color: "primary.dark100" }} />
    ),
    registerOptions: {
      required: { value: true, message: "taxes-required-error" },
      min: { value: 0.01, message: "taxes-min-error" },
      maxLength: { value: 10, message: "taxes-max-length-error" },
    },
    size: { xs: 4 },
    inputProps: { step: "any" },
  },
  {
    name: "platform_fee",
    formLabel: "platform-fees-label",
    placeholder: "platform-fees-placeholder",
    helperText: "platform-fees-helper-text",
    type: "number",
    startAdornment: <PaymentOutlinedIcon sx={{ color: "primary.dark100" }} />,
    registerOptions: {
      required: { value: true, message: "platform_fees-required-error" },
      min: { value: 0, message: "platform_fees-min-error" },
      maxLength: { value: 10, message: "platform_fees-max-length-error" },
    },
    size: { xs: 4 },
    inputProps: { step: "any" },
  },
  {
    name: "vat",
    formLabel: "vat-label",
    placeholder: "vat-placeholder",
    helperText: "vat-helper-text",
    type: "number",
    startAdornment: (
      <AccountBalanceWalletOutlinedIcon sx={{ color: "primary.dark100" }} />
    ),
    registerOptions: {
      required: { value: true, message: "vat-required-error" },
      min: { value: 0, message: "vat-min-error" },
      max: { value: 100, message: "vat-max-error" },
    },
    size: { xs: 4 },
    inputProps: { step: "any" },
  },
];
