import { Currency, Date, Material } from "../shared/icon";

export const loaderPath = {
  transactions: "transactions",
  transactionDetails: "transactionDetails",
};

export const transactionTableColumns = [
  { key: "transaction_type", label: "transaction-type" },
  { key: "business_from", label: "business-from" },
  { key: "business_to", label: "business-to" },
  { key: "material_type", label: "material-type" },
  { key: "material_name", label: "material-name" },
  { key: "amount", label: "amount" },
  { key: "status", label: "status" },
  { key: "created_at", label: "created-at" },
  { key: "action", label: "action", align: "center" },
];

const transactionTypeOption = [
  { label: "deposit", value: "DEPOSIT" },
  { label: "withdrawal", value: "WITHDRAWAL" },
  { label: "payment", value: "PAYMENT" },
];

const statusOption = [
  { label: "pending", value: "PENDING" },
  { label: "success", value: "SUCCESS" },
  { label: "failed", value: "FAILED" },
];

export const transactionFilterFields = [
  {
    name: "transaction_type",
    formLabel: "transaction-type",
    placeholder: "transaction-type-placeholder",
    type: "select",
    size: { xs: 12 },
    isMultiple: true,
    options: transactionTypeOption,
  },
  {
    name: "status",
    formLabel: "status",
    placeholder: "status-placeholder",
    type: "select",
    size: { xs: 12 },
    isMultiple: true,
    options: statusOption,
  },
  // {
  //   type: "text",
  //   name: "business_name",
  //   formLabel: "business-name",
  //   placeholder: "business-name",
  //   startAdornment: <PurchaseManagement />,
  //   size: { xs: 12 },
  // },
  {
    type: "text",
    name: "material_name",
    formLabel: "material-name",
    placeholder: "material-name",
    startAdornment: <Material />,
    size: { xs: 12 },
  },
  {
    type: "number",
    name: "min_amount",
    formLabel: "min-amount",
    placeholder: "min-amount",
    startAdornment: <Currency />,
    size: { xs: 12 },
  },
  {
    type: "number",
    name: "max_amount",
    formLabel: "max-amount",
    placeholder: "max-amount",
    startAdornment: <Currency />,
    size: { xs: 12 },
  },
  {
    type: "date",
    name: "start_date",
    formLabel: "start-date",
    placeholder: "start-date",
    startAdornment: <Date fill="black" />,
    size: { xs: 12 },
  },
  {
    type: "date",
    name: "end_date",
    formLabel: "end-date",
    placeholder: "end-date",
    startAdornment: <Date fill="black" />,
    size: { xs: 12 },
  },
];

export const defaultTransactionFilterValues = {
  transaction_type: "",
  status: "",
  business_name: "",
  material_name: "",
  min_amount: "",
  max_amount: "",
  start_date: "",
  end_date: "",
};
