export const loaderPath = {
  metalsStonesPools: "metals-stones-pools",
  metalsStonesPoolsDetails: "metals-stones-pools-details",
  addMetalsStonesPools: "add-metals-stones-pools",
  getPreciousItemAttributes: "get-precious-item-attributes",
  closePool: "close-metals-stones-pool",
};

export const poolsTableColumns = [
  { key: "name", label: "Pool Name" },
  { key: "status", label: "status" },
  { key: "material_type", label: "material-type" },
  { key: "material_item", label: "material-item" },
  { key: "target", label: "target" },
  { key: "risk_level", label: "risk-level" },
  { key: "expected_return_percentage", label: "expected-return-percentage" },
  { key: "created_at", label: "created-at" },
  { key: "view", label: "view", align: "center" },
  { key: "action", label: "action", align: "center" },
];

const riscLevelOption = [
  { label: "low", value: "LOW" },
  { label: "medium", value: "MEDIUM" },
  { label: "high", value: "HIGH" },
];

const statusOption = [
  { label: "open", value: "OPEN" },
  { label: "closed", value: "CLOSED" },
];

const materialTypeOption = [
  { label: "metal", value: "metal" },
  { label: "stone", value: "stone" },
];

export const addPoolFormFields = [
  {
    name: "name",
    formLabel: "pool-name",
    placeholder: "pool-name-placeholder",
    type: "text",
    registerOptions: {
      required: {
        value: true,
        message: "pool-name-required-error",
      },
      validate: {
        noLeadingSpecialChar: (value) =>
          /^[a-zA-Z0-9]/.test(value) || "pool-name-leading-special-char-error",
      },
    },
    size: { xs: 6 },
  },
  {
    name: "material_type",
    formLabel: "material-type",
    placeholder: "select-material-type",
    registerOptions: {
      required: {
        value: true,
        message: "material-type-required-error",
      },
    },
    type: "select",
    size: { xs: 6 },
    isMultiple: true,
    options: materialTypeOption,
  },
  {
    name: "material_item",
    formLabel: "material-item",
    placeholder: "select-material-item",
    registerOptions: {
      required: {
        value: true,
        message: "material-item-required-error",
      },
    },
    type: "select",
    size: { xs: 6 },
    isMultiple: true,
    options: [],
  },
  {
    name: "carat_type",
    formLabel: "carat-type",
    placeholder: "select-carat-type",
    type: "select",
    size: { xs: 6 },
    isMultiple: true,
    options: [],
  },
  {
    name: "risk_level",
    formLabel: "risk-level",
    placeholder: "select-risk-level",
    type: "select",
    size: { xs: 6 },
    isMultiple: true,
    options: riscLevelOption,
  },
  {
    name: "cut_shape",
    formLabel: "cut-shape",
    placeholder: "select-cut-shape",
    type: "select",
    size: { xs: 6 },
    isMultiple: true,
    options: [],
  },
  {
    name: "target",
    formLabel: "target",
    placeholder: "target-placeholder",
    type: "number",
    registerOptions: {
      required: {
        value: true,
        message: "target-required-error",
      },
      validate: {
        notNegativeValue: (value) => {
          if (value < 0) {
            return "less-than-zero-error";
          }
        },
      },
    },
    size: { xs: 6 },
  },
  {
    name: "expected_return_percentage",
    formLabel: "expected-return-percentage",
    placeholder: "expected-return-percentage-placeholder",
    type: "number",
    registerOptions: {
      required: {
        value: true,
        message: "expected-return-percentage-required-error",
      },
      validate: {
        notNegativeValue: (value) => {
          if (value < 0) {
            return "less-than-zero-error";
          }
        },
      },
    },
    size: { xs: 6 },
  },
  {
    name: "closes_on",
    formLabel: "closed-on",
    placeholder: "closes-on-placeholder",
    type: "date",
    registerOptions: {
      required: {
        value: true,
        message: "closes-on-required-error",
      },
      validate: {
        notPastDate: (value) => {
          const selectedDate = new Date(value);
          const today = new Date();
          // Set time to 0 to only compare date
          selectedDate.setHours(0, 0, 0, 0);
          today.setHours(0, 0, 0, 0);
          return selectedDate >= today || "closes-on-past-date-error";
        },
      },
    },
    size: { xs: 6 },
  },
];

export const addPoolFormDefaultValues = {
  name: "",
  material_type: "metal",
  material_item: "",
  carat_type: "",
  risk_level: "",
  cut_shape: "",
  target: "",
  quantity: "",
  expected_return_percentage: "",
  closes_on: "",
};

export const filterFormFields = [
  {
    name: "material_type",
    formLabel: "material-type",
    placeholder: "material-type-placeholder",
    type: "select",
    size: { xs: 6 },
    isMultiple: true,
    options: materialTypeOption,
  },
  // {
  //   name: "material_item",
  //   formLabel: "material-item",
  //   placeholder: "select-material-item",
  //   type: "select",
  //   size: { xs: 6 },
  //   isMultiple: true,
  //   options: [],
  // },
  {
    name: "risk_level",
    formLabel: "risk-level",
    placeholder: "select-risk-level",
    type: "select",
    size: { xs: 6 },
    isMultiple: true,
    options: riscLevelOption,
  },
  {
    name: "target__min",
    formLabel: "target-min",
    placeholder: "target-placeholder",
    type: "number",
    size: { xs: 6 },
  },
  {
    name: "target__max",
    formLabel: "target-max",
    placeholder: "target-placeholder",
    type: "number",
    size: { xs: 6 },
  },
  {
    name: "expected_return__min",
    formLabel: "expected-return-min-(%)",
    placeholder: "expected-return-percentage-placeholder",
    type: "number",
    size: { xs: 6 },
  },
  {
    name: "expected_return__max",
    formLabel: "expected-return-max-(%)",
    placeholder: "expected-return-percentage-placeholder",
    type: "number",
    size: { xs: 6 },
  },
  {
    name: "created_at__min",
    formLabel: "created-at-min",
    placeholder: "created-at-min",
    type: "date",
    size: { xs: 6 },
  },
  {
    name: "created_at__max",
    formLabel: "created-at-max",
    placeholder: "created-at-max",
    type: "date",
    size: { xs: 6 },
  },
  {
    name: "closes_at__min",
    formLabel: "closes-on-min",
    placeholder: "closes-on-min",
    type: "date",
    size: { xs: 6 },
  },
  {
    name: "closes_at__max",
    formLabel: "closes-on-max",
    placeholder: "closes-on-max",
    type: "date",
    size: { xs: 6 },
  },
  {
    type: "select",
    name: "status",
    formLabel: "status",
    placeholder: "status-placeholder",
    size: { xs: 6 },
    isMultiple: true,
    options: statusOption,
  },
];

export const filterDefaultValues = {
  material_type: "",
  // material_item: "",
  risk_level: "",
  target__min: "",
  target__max: "",
  expected_return__max: "",
  expected_return__min: "",
  created_at__min: "",
  created_at__max: "",
  status: "",
  closes_at__min: "",
  closes_at__max: "",
};
