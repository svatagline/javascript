import { Email, Users } from "../shared/icon";
import { emailRegex, passwordRegex } from "../utils/regex";

export const loaderPath = {
  subAdminLoading: "subAdmin",
  addSubAdminLoading: "addSubAdminLoading",
  deleteSubAdminLoading: "deleteSubAdminLoading",
};

export const subAdminTableColumns = [
  { key: "full_name", label: "sub-admin-name" },
  { key: "email", label: "email" },
  // { key: "phone_number", label: "phone-number" },
  { key: "role", label: "role" },
  { key: "date_joined", label: "date-joined" },
  { key: "last_login", label: "last-login" },
  // { key: "account_status", label: "account-status" },
  { key: "action", label: "action", align: "center" },
];

const roleOption = [
  { label: "taqabeth-enforcer", value: "TAQABETH_ENFORCER" },
  { label: "jewellery-inspector", value: "JEWELLERY_INSPECTOR" },
  { label: "jewellery-buyer", value: "JEWELLERY_BUYER" },
];
export const subAdminFilterFields = [
  {
    name: "role",
    formLabel: "role",
    placeholder: "system-role",
    startAdornment: <Users />,
    type: "select",
    size: { xs: 12 },
    isMultiple: true,
    options: roleOption,
  },
  {
    type: "text",
    name: "email",
    formLabel: "email",
    placeholder: "email",
    startAdornment: <Email />,
    size: { xs: 12 },
  },
];

export const defaultSubAdminFilterValues = {
  role: "",
  email: "",
  // fullname: "",
};

export const addSubAdminFormFields = [
  {
    name: "email",
    formLabel: "email",
    placeholder: "email-placeholder",
    type: "text",
    registerOptions: {
      required: {
        value: true,
        message: "email-required-error",
      },
      pattern: {
        value: emailRegex,
        message: "invalid-email-error",
      },
    },
    size: { xs: 12 },
  },
  {
    name: "password",
    formLabel: "password",
    placeholder: "password-placeholder",
    type: "password",
    registerOptions: {
      required: {
        value: true,
        message: "password-required-error",
      },
      minLength: {
        value: 8,
        message: "password-min-length-error",
      },
      pattern: {
        value: passwordRegex,
        message: "password-pattern-error",
      },
    },
    size: { xs: 12 },
  },
  {
    name: "role",
    formLabel: "role",
    placeholder: "select-role",
    startAdornment: <Users />,
    registerOptions: {
      required: {
        value: true,
        message: "role-required-error",
      },
    },
    type: "select",
    size: { xs: 12 },
    isMultiple: true,
    options: roleOption,
  },
  {
    name: "first_name",
    formLabel: "first-name",
    placeholder: "first-name-placeholder",
    type: "text",
    registerOptions: {
      required: {
        value: true,
        message: "first-name-required-error",
      },
      minLength: {
        value: 2,
        message: "first-name-min-length-error",
      },
      maxLength: {
        value: 50,
        message: "first-name-max-length-error",
      },
    },
    size: { xs: 12 },
  },
  {
    name: "middle_name",
    formLabel: "middle-name",
    placeholder: "middle-name-placeholder",
    type: "text",
    registerOptions: {
      required: {
        value: true,
        message: "middle-name-required-error",
      },
      minLength: {
        value: 2,
        message: "middle-name-min-length-error",
      },
      maxLength: {
        value: 50,
        message: "middle-name-max-length-error",
      },
    },
    size: { xs: 12 },
  },
  {
    name: "last_name",
    formLabel: "last-name",
    placeholder: "last-name-placeholder",
    type: "text",
    registerOptions: {
      required: {
        value: true,
        message: "last-name-required-error",
      },
      minLength: {
        value: 2,
        message: "last-name-min-length-error",
      },
      maxLength: {
        value: 50,
        message: "last-name-max-length-error",
      },
    },
    size: { xs: 12 },
  },
];

export const addSubAdminFormDefaultValues = {
  email: "",
  password: "",
  role: "",
  first_name: "",
  middle_name: "",
  last_name: "",
};
