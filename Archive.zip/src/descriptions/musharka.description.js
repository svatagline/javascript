export const loaderPath = {
  musharkaContracts: "musharka-contracts",
};

export const contractsTableColumns = [
  { key: "jeweler", label: "designer" },
  { key: "investor", label: "investor" },
  { key: "design_type", label: "design-type" },
  { key: "status", label: "status" },
  { key: "target", label: "target" },
  { key: "expiry_date", label: "expiry-date" },
  { key: "view", label: "view", align: "center" },
  { key: "action", label: "action", align: "center" },
];
