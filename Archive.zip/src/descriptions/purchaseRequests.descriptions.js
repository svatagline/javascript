import { Currency, PurchaseManagement } from "../shared/icon";
import { nonZeroNumber } from "../utils/regex";

export const loaderPath = {
  purchaseRequests: "purchaseRequests",
  purchaseRequestsDetails: "purchaseRequestsDetails",
  purchaseRequestsComplete: "purchaseRequestsComplete",
};

export const purchaseRequestTableColumns = [
  { key: "request_type", label: "request-type" },
  { key: "total_cost", label: "total-cost", sorting: true },
  { key: "requested_from", label: "requested-from" },
  { key: "requested_to", label: "requested-to" },
  { key: "material_type", label: "material-type" },
  { key: "precious_item", label: "precious-item" },
  { key: "status", label: "status" },
  { key: "created_at", label: "created-at", sorting: true },
  { key: "view", label: "view", align: "center" },
  { key: "action", label: "action", align: "center" },
];

const purchaseRequestsTypeOption = [
  { label: "purchase", value: "PURCHASE" },
  { label: "sale", value: "SALE" },
];

const statusOption = [
  { label: "pending", value: "PENDING" },
  { label: "rejected", value: "REJECTED" },
  { label: "confirmed", value: "CONFIRMED" },
  { label: "completed", value: "COMPLETED" },
  { label: "approved", value: "APPROVED" },
];
const materialTypeOption = [
  { label: "metal", value: "metal" },
  { label: "stone", value: "stone" },
];

export const purchaseRequestsFilterFields = [
  {
    type: "autocomplete",
    name: "request_type",
    formLabel: "get-purchase-requests-type",
    placeholder: "get-purchase-requests-type-placeholder",
    size: { xs: 12 },
    isMultiple: true,
    options: purchaseRequestsTypeOption,
  },
  {
    type: "autocomplete",
    name: "status",
    formLabel: "status",
    placeholder: "status-placeholder",
    size: { xs: 12 },
    isMultiple: true,
    options: statusOption,
  },
  {
    type: "autocomplete",
    name: "material_type",
    formLabel: "material-type",
    placeholder: "material-type-placeholder",
    size: { xs: 12 },
    isMultiple: true,
    options: materialTypeOption,
  },
  {
    type: "number",
    name: "total_cost_min",
    formLabel: "total-cost-min",
    placeholder: "total-cost-min",
    startAdornment: <PurchaseManagement />,
    size: { xs: 12 },
    registerOptions: {
      pattern: {
        value: nonZeroNumber,
        message: "non-zero-amount-validation",
      },
    },
  },
  {
    type: "number",
    name: "total_cost_max",
    formLabel: "total-cost-max",
    placeholder: "total-cost-max",
    startAdornment: <PurchaseManagement />,
    size: { xs: 12 },
    registerOptions: {
      pattern: {
        value: nonZeroNumber,
        message: "non-zero-amount-validation",
      },
    },
  },
  {
    type: "date",
    name: "created_at_min",
    formLabel: "created-at-min",
    placeholder: "created-at-min",
    startAdornment: <Currency />,
    size: { xs: 12 },
  },
  {
    type: "date",
    name: "created_at_max",
    formLabel: "created-at-max",
    placeholder: "created-at-max",
    startAdornment: <Currency />,
    size: { xs: 12 },
  },
];

export const defaultPurchaseRequestsFilterValues = {
  request_type: "",
  status: "",
  material_type: "",
  precious_item: "",
  total_cost_min: "",
  total_cost_max: "",
  // unsold_assets: "",
  created_at_min: "",
  created_at_max: "",
};
