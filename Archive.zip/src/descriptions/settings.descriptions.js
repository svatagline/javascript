import { passwordRegex } from "../utils/regex";

export const loaderPath = {
  loadingChangePassword: "settings-change-password",
  materials: "materials",
  addMaterial: "add-material",
  materialStatus: "material-status",
  uploadImage: "upload-image",
  shapeCuts: "shape-cuts",
  shapeCutStatus: "shape-cut-status",
  addShapeCut: "add-shape-cut",
  metalCaratTypes: "metal-carat-types",
  metalCaratTypeStatus: "metal-carat-type-status",
  addMetalCaratType: "add-metal-carat-type",
  getProductType: "get-product-type",
  getProductTypeStatus: "get-product-type-status",
  getProductColor: "get-product-color",
  getProductColorStatus: "get-product-color-status",
  addEditModal: "add-edit-modal",
};

export const defaultValues = {
  old_password: "",
  new_password: "",
  confirm_password: "",
};

export const fields = [
  {
    type: "password",
    name: "old_password",
    label: "old-password",
    placeholder: "old-password",
    registerOptions: {
      required: { value: true, message: "old-password-required-error" },
    },
  },
  {
    type: "password",
    name: "new_password",
    label: "new-password",
    placeholder: "new-password",
    registerOptions: {
      required: { value: true, message: "new-password-required-error" },
      minLength: { value: 8, message: "password-min-length-error" },
      pattern: { value: passwordRegex, message: "password-pattern-error" },
    },
  },
  {
    type: "password",
    name: "confirm_password",
    label: "confirm-password",
    placeholder: "confirm-password",
    registerOptions: {
      required: { value: true, message: "confirm-password-required-error" },
    },
  },
];

export const stoneTableColumns = [
  { key: "name", label: "Stone Name" },
  { key: "materialType", label: "material-type" },
  { key: "status", label: "status" },
  { key: "action", label: "action" },
];

export const metalTableColumns = [
  { key: "name", label: "Metal Name" },
  { key: "materialType", label: "material-type" },
  { key: "status", label: "status" },
  // { key: "edit", label: "edit" },
  { key: "action", label: "action" },
];

export const shapeCutTableColumns = [
  { key: "name", label: "Shape & Cut Name" },
  { key: "status", label: "status" },
  { key: "action", label: "action" },
];

export const metalCaratTypeTableColumns = [
  { key: "name", label: "Carat Name" },
  { key: "purity", label: "purity" },
  { key: "status", label: "status" },
  { key: "action", label: "action" },
];

export const addMaterialDefaultValues = {
  name: "",
  image: null,
  material_type: "stone",
};

export const addMaterialsFields = [
  {
    name: "name",
    formLabel: "material-name",
    placeholder: "material-name-placeholder",
    type: "text",
    registerOptions: {
      required: { value: true, message: "material-name-required-error" },
      maxLength: { value: 100, message: "material-name-max-length-error" },
      validate: {
        noLeadingSpecialChar: (value) =>
          /^[a-zA-Z0-9]/.test(value) || "name-leading-special-char-error",
      },
    },
    size: { xs: 12 },
  },
];

export const addShapeCutFields = [
  {
    name: "name",
    formLabel: "shape-cut-name",
    placeholder: "shape-cut-name-placeholder",
    type: "text",
    registerOptions: {
      required: { value: true, message: "shape-cut-name-required-error" },
      maxLength: { value: 100, message: "shape-cut-name-max-length-error" },
      validate: {
        noLeadingSpecialChar: (value) =>
          /^[a-zA-Z0-9]/.test(value) || "name-leading-special-char-error",
      },
    },
    size: { xs: 12 },
  },
];

export const addCaratTypeFields = [
  {
    type: "text",
    name: "name",
    formLabel: "carat-type-name",
    placeholder: "carat-type-name-placeholder",
    registerOptions: {
      required: { value: true, message: "carat-type-name-required-error" },
      maxLength: { value: 100, message: "carat-type-name-max-length-error" },
      validate: {
        noLeadingSpecialChar: (value) =>
          /^[a-zA-Z0-9]/.test(value) || "name-leading-special-char-error",
      },
    },
    size: { xs: 12 },
  },
  {
    type: "number",
    name: "purity_percentage",
    formLabel: "purity",
    placeholder: "purity-placeholder",
    registerOptions: {
      required: { value: true, message: "purity-required-error" },
      min: { value: 1, message: "purity-min-error" },
      max: { value: 100, message: "purity-max-error" },
    },
    size: { xs: 12 },
  },
];

export const productTypeTableColumns = [
  { key: "name", label: "name" },
  { key: "status", label: "status" },
  { key: "action", label: "action" },
  { key: "edit", label: "edit" },
];

export const addProductTypeFields = [
  {
    type: "text",
    name: "name",
    formLabel: "product-type-name",
    placeholder: "product-type-name-placeholder",
    registerOptions: {
      required: { value: true, message: "product-type-name-required-error" },
      maxLength: { value: 100, message: "product-type-name-max-length-error" },
      validate: {
        noLeadingSpecialChar: (value) =>
          /^[a-zA-Z0-9]/.test(value) || "name-leading-special-char-error",
      },
    },
    size: { xs: 12 },
  },
];

export const productColorTableColumns = [
  { key: "name", label: "name" },
  { key: "status", label: "status" },
  { key: "action", label: "action" },
  { key: "edit", label: "edit" },
];

export const addProductColorFields = [
  {
    type: "text",
    name: "name",
    formLabel: "product-color-name",
    placeholder: "product-color-name-placeholder",
    registerOptions: {
      required: { value: true, message: "product-color-name-required-error" },
      maxLength: { value: 100, message: "product-color-name-max-length-error" },
      validate: {
        noLeadingSpecialChar: (value) =>
          /^[a-zA-Z0-9]/.test(value) || "name-leading-special-char-error",
      },
    },
    size: { xs: 12 },
  },
];
