import { Email, Users } from "../shared/icon";

export const loaderPath = {
  businesses: "businesses",
  businessOwner: "business-owner",
};

export const tableColumns = [
  { key: "name", label: "business-name" },
  { key: "business_account_type", label: "business-type" },
  { key: "owner_name", label: "owner-name" },
  { key: "owner_email", label: "owner-email" },
  { key: "is_suspended", label: "status" },
  { key: "total_users", label: "total-users", align: "center" },
  { key: "action", label: "action", align: "center" },
];

export const usersTableColumns = [
  { key: "name", label: "user-name" },
  { key: "email", label: "email" },
  { key: "phone_number", label: "phone-number" },
  { key: "last_login", label: "last-login-date" },
  { key: "created_at", label: "date-joined" },
  { key: "status", label: "status" },
  { key: "action", label: "action", align: "center" },
];

const roleOptions = [
  { label: "investor", value: "INVESTOR" },
  { label: "refinery", value: "SELLER" },
  { label: "jeweler", value: "JEWELER" },
  { label: "manufacturer", value: "MANUFACTURER" },
];

export const defaultFilterValues = {
  business_account_type: "",
  owner_email: "",
  owner_name: "",
};

export const businessesFilterFields = [
  {
    type: "select",
    name: "business_account_type",
    formLabel: "business-type",
    placeholder: "select-business-type",
    startAdornment: <Users />,
    size: { xs: 12 },
    isMultiple: true,
    options: roleOptions,
  },
  {
    type: "text",
    name: "owner_name",
    formLabel: "owner-name",
    placeholder: "owner-name",
    startAdornment: <Users />,
    size: { xs: 12 },
  },
  {
    type: "text",
    name: "owner_email",
    formLabel: "owner-email",
    placeholder: "owner-email",
    startAdornment: <Email />,
    size: { xs: 12 },
  },
];
