import { useCallback } from "react";
import { useTranslation } from "react-i18next";

const useI18N = () => {
  const { t, i18n } = useTranslation();

  const setLanguage = useCallback(
    (lang) => {
      const language = ["ar", "en"].includes(lang) ? lang : "en";
      i18n.changeLanguage(language);
      localStorage.setItem("appLang", language);
    },
    [i18n],
  );

  return {
    t,
    setLanguage,
    dir: i18n.dir(),
    currentLang: i18n.resolvedLanguage,
  };
};

export default useI18N;
