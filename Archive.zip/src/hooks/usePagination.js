import { useEffect, useState } from "react";

const usePagination = (count, initialItemsPerPage = 10) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [itemPerPage, setItemPerPage] = useState(initialItemsPerPage);
  const [totalPage, setTotalPage] = useState(0);

  useEffect(() => {
    if (count) setTotalPage(Math.ceil(count / itemPerPage));
  }, [count, itemPerPage]);

  const handleChangeRowsPerPage = (newRowsPerPage) => {
    setItemPerPage(newRowsPerPage);
    setCurrentPage(1);
  };

  return {
    totalPage,
    setTotalPage,
    currentPage,
    setCurrentPage,
    itemPerPage,
    setItemPerPage,
    onRowsPerPageChange: handleChangeRowsPerPage,
  };
};

export default usePagination;
