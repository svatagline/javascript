import { useCallback } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

import axiosInstance from "../api/api";
import { setLoader } from "../redux/slices/loader.slices";
import { logout } from "../utils/functions";
import showToast from "../utils/toast";
import useI18N from "./useI18N";

const useAPI = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { t, currentLang } = useI18N();

  const api = useCallback(
    async ({
      method,
      endPoint,
      data,
      loader,
      params = {},
      headers = {},
      needLoader = false,
      showToastMessage = false,
      showToastOnSuccess = false,
      showToastOnError = false,
      errorToastMessage = "",
      successToastMessage = "",
    } = {}) => {
      if (needLoader) dispatch(setLoader({ name: loader }));

      try {
        const response = await axiosInstance({
          method,
          url: endPoint,
          data,
          params,
          headers: { "Accept-Language": currentLang, ...headers },
        });

        if (showToastOnSuccess || showToastMessage) {
          const toastMessage =
            t(successToastMessage) ||
            response?.data?.message ||
            t("default-success-message");
          showToast(toastMessage || response?.message, { type: "success" });
        }

        return {
          response,
          status: response?.data?.status_code || response?.status,
          data: response?.data?.data || response?.data,
        };
      } catch (error) {
        const { response } = error;

        if (showToastOnError || showToastMessage) {
          const toastMessage =
            t(errorToastMessage) ||
            response?.data?.message ||
            response?.data?.error;
          showToast(toastMessage);
        }

        if ([401].includes(response?.status)) {
          logout();
          navigate("/login");
        }

        return {
          error,
          status: false,
          statusCode: response?.data?.status_code || response?.status,
        };
      } finally {
        if (needLoader) dispatch(setLoader({ name: loader }));
      }
    },
    [dispatch, currentLang],
  );

  return { api };
};

export default useAPI;
