import { PutObjectCommand, S3Client } from "@aws-sdk/client-s3";

import { setLoader } from "../redux/slices/loader.slices";
import store from "../redux/store";
import showToast from "./toast";

const s3Client = new S3Client({
  region: "eu-central-1",
  credentials: {
    accessKeyId: process.env.REACT_APP_AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.REACT_APP_AWS_SECRET_KEY,
  },
});

export const uploadFileToS3 = async ({ file, path, loader = "" }) => {
  if (!file || !path) return;

  if (loader) store.dispatch(setLoader({ name: loader }));

  const fileBuffer = await file.arrayBuffer();

  const params = {
    Bucket: process.env.REACT_APP_AWS_BUCKET,
    Key: path,
    Body: new Uint8Array(fileBuffer),
    ContentType: file.type,
  };

  try {
    const command = new PutObjectCommand(params);
    await s3Client.send(command);

    if (loader) store.dispatch(setLoader({ name: loader }));
    return { status: true, path };
  } catch (error) {
    showToast();
    if (loader) store.dispatch(setLoader({ name: loader }));
    return { status: false, error };
  }
};
