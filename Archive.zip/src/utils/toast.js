import toast from "react-hot-toast";

import i18n from "../i18n/config";

const showToast = (
  message = "default-error-message",
  {
    type = "error",
    duration = 3000,
    position = "top-center",
    className = "toast-message",
    ...rest
  } = {},
) =>
  toast(i18n.t(message), {
    type,
    position,
    duration,
    className,
    ...rest,
  });

export default showToast;
