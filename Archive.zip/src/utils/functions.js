import axios from "axios";
import getSymbolFromCurrency from "currency-symbol-map";
import { jwtDecode } from "jwt-decode";
import { v4 as uuidv4 } from "uuid";

import axiosInstance from "../api/api";
import { ADMIN_ROLES } from "../constants";
import { apiEndpoints, httpMethods } from "../constants/api.constants";
import i18n from "../i18n/config";
import { addAppData } from "../redux/slices/app.slices";
import { setLoader } from "../redux/slices/loader.slices";
import store from "../redux/store";
import showToast from "./toast";

export const getFCMDetails = async () => {
  const deviceId = localStorage.getItem("deviceId") || uuidv4();
  localStorage.setItem("deviceId", deviceId);

  return {
    fcm_token: "unauthorized",
    device_id: deviceId,
    device_type: "WEB",
  };
};

export const decodeToken = (token = "") => {
  const accessToken = localStorage.getItem("accessToken");

  if (!token && !accessToken) return {};

  const decoded = jwtDecode(token || accessToken);
  return {
    role: decoded?.role,
    userId: decoded?.user_id,
    email: decoded?.email,
  };
};

export const logout = () => {
  localStorage.clear();
};

export const createQueryParams = (params) => {
  if (!params || typeof params !== "object") return "";
  const query = Object.entries(params)
    .map(([key, value]) => `${key}=${value}`)
    .join("&");
  return "?".concat(query);
};

export const isAdmin = () => {
  const { role } = decodeToken();
  return Object.keys(ADMIN_ROLES).includes(role);
};

export const shuftiAPI = async ({
  data,
  method = "post",
  endPoint = "",
  needLoader = false,
  loader,
}) => {
  const username = process.env.REACT_APP_SHUFTI_CLIENT_ID;
  const password = process.env.REACT_APP_SHUFTI_SECRET_KEY;
  const credentials = btoa(`${username}:${password}`);

  const baseURL = "https://api.shuftipro.com/";
  const headers = {
    Authorization: `Basic ${credentials}`,
    "Content-Type": "application/json",
  };

  if (needLoader) store.dispatch(setLoader({ name: loader, status: true }));

  try {
    const response = await axios({
      method,
      url: `${baseURL}${endPoint}`,
      data,
      headers,
    });
    if (needLoader) store.dispatch(setLoader({ name: loader, status: false }));

    return response;
  } catch (error) {
    showToast();
    if (needLoader) store.dispatch(setLoader({ name: loader, status: false }));

    return error;
  }
};

export const formatTimestamp = (utcDate, { showDash = true } = {}) => {
  if (!utcDate) return showDash ? "-" : "";
  if (!i18n) throw new Error("i18n instance is required for translation");

  const date = new Date(utcDate);

  const formatTime = date.toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });

  const day = date.getDate().toString().padStart(2, "0");
  const month = i18n.t(
    `${date.toLocaleDateString("en-GB", { month: "short" })}`.toLowerCase(),
  );
  const year = date.getFullYear();

  return `${day} ${month} ${year}, ${formatTime}`;
};

export const validTableValue = (value, showDash = true) => {
  if (!value || [undefined, null, ""].includes(value)) {
    return showDash ? "-" : "";
  } else {
    return value;
  }
};

export function filterValidEntries(obj) {
  return Object.fromEntries(
    Object.entries(obj).filter((i) => {
      let value = i[1];
      return value !== undefined && value !== null && value !== "";
    }),
  );
}

export function objectLength(obj) {
  return Object.keys(obj).length;
}

export function excludeKeys(obj, keysToExclude) {
  if (obj) {
    return Object.fromEntries(
      Object.entries(obj).filter(([key]) => !keysToExclude.includes(key)),
    );
  } else {
    return {};
  }
}

export const validDetailsValue = (value, type) => {
  if (!value || [undefined, null, ""].includes(value)) {
    return "-";
  } else {
    if (type === "date") {
      return formatTimestamp(value);
    } else if (typeof value === "object") {
      return "object";
    } else {
      return value;
    }
  }
};

export const validBooleanValue = (
  value,
  describeTrue = "Yes",
  describeFalse = "No",
) => {
  if (!value || [undefined, null, ""].includes(value)) {
    return describeFalse;
  } else {
    return describeTrue;
  }
};

export function convertDatesToTimestampsInObject(obj, dateKeys, useTimestamp) {
  if (useTimestamp) {
    Array.isArray(dateKeys) &&
      dateKeys.forEach((key) => {
        if (obj[key]) {
          obj[key] = new Date(obj[key]).getTime();
        }
      });
    return obj;
  } else {
    return obj;
  }
}

export const formatAmount = (amount, compact = true) => {
  const formatter = new Intl.NumberFormat("en-US", {
    notation: "compact",
    compactDisplay: "short",
    maximumFractionDigits: 1,
  });

  const formatted = formatter.format(amount || 0);
  return `${compact ? formatted : amount} ${getSymbolFromCurrency("BHD")}`;
};

export const isSameObject = (obj1, obj2) => {
  if (
    typeof obj1 !== "object" ||
    typeof obj2 !== "object" ||
    obj1 === null ||
    obj2 === null
  ) {
    return obj1 === obj2;
  }

  const keys1 = Object.keys(obj1);
  const keys2 = Object.keys(obj2);

  if (keys1.length !== keys2.length) return false;

  return keys1.every((key) => isSameObject(obj1[key], obj2[key]));
};

export function encoder(action, text) {
  const map = [
    "Ac",
    "Xa",
    "Bd",
    "Yb",
    "Ce",
    "Zc",
    "Df",
    "Wd",
    "Eg",
    "Ve",
    "Uf",
  ];
  const reverseMap = Object.fromEntries(
    map.map((val, i) => [val, i < 10 ? i.toString() : "|"]),
  );

  const digitRegex = /\d+/g;

  if (action === "encrypt") {
    return text.replace(digitRegex, (digits) =>
      digits
        .split("")
        .map((char) => (char === "|" ? map[10] : map[parseInt(char, 10)]))
        .join(""),
    );
  }

  if (action === "decrypt") {
    return text.replace(/(?:Ac|Xa|Bd|Yb|Ce|Zc|Df|Wd|Eg|Ve|Uf)+/g, (chunk) =>
      chunk
        .match(/.{2}/g)
        .map((pair) => reverseMap[pair])
        .join(""),
    );
  }

  return "Invalid action";
}

export function dateToTimestamp(dateStr) {
  const date = new Date(dateStr);

  // Check if the date is valid
  if (isNaN(date.getTime())) {
    return 0; // Return 0 if invalid
  }

  return Math.floor(date.getTime() / 1000); // Convert to timestamp (seconds)
}

export function validateInputs(min_amount, max_amount, start_date, end_date) {
  // If both amounts exist, check condition
  if (min_amount !== undefined && max_amount !== undefined) {
    if (min_amount >= max_amount) {
      throw "Total Min Cost must be less than Total Max Cost";
    }
  }

  // Convert dates, default to 0 if invalid
  const startDate = new Date(start_date);
  const endDate = new Date(end_date);

  const startTimestamp = isNaN(startDate.getTime()) ? 0 : startDate.getTime();
  const endTimestamp = isNaN(endDate.getTime()) ? 0 : endDate.getTime();

  // If both dates exist and are valid, check condition
  if (startTimestamp !== 0 && endTimestamp !== 0) {
    if (startTimestamp >= endTimestamp) {
      throw "Starting Date must be earlier than Ending Date";
    }
  }

  return true; // Return true if no errors
}

export function compareAmounts({
  min_amount,
  max_amount,
  min_amount_field = "Total Min Amount",
  max_amount_field = "Total Max Amount",
  errorMessage,
}) {
  if (parseFloat(min_amount) && parseFloat(max_amount)) {
    if (parseFloat(min_amount) > parseFloat(max_amount)) {
      throw (
        i18n.t(errorMessage) ||
        `${min_amount_field} must be less than ${max_amount_field}`
      );
    }
  }
  return true;
}

export function compareDates({
  start_date,
  end_date,
  start_date_field = "Min Date",
  end_date_field = "Max Date",
  errorMessage,
}) {
  const startDate = new Date(start_date);
  const endDate = new Date(end_date);

  const startTimestamp = isNaN(startDate.getTime()) ? 0 : startDate.getTime();
  const endTimestamp = isNaN(endDate.getTime()) ? 0 : endDate.getTime();
  if (startTimestamp && endTimestamp) {
    if (startTimestamp > endTimestamp) {
      throw (
        i18n.t(errorMessage) ||
        `${start_date_field} must be earlier than ${end_date_field}`
      );
    }
  }

  return true;
}

export const getNotifications = async ({
  page = 1,
  pageSize = 10,
  loader = "",
  needLoader = true,
  storeInRedux = true,
} = {}) => {
  if (needLoader)
    store.dispatch(setLoader({ name: loader || "notifications" }));

  try {
    const headers = { "Accept-Language": i18n.resolvedLanguage };
    const response = await axiosInstance({
      method: httpMethods.get,
      url: apiEndpoints.getNotifications,
      headers,
      params: { page, page_size: pageSize },
    });

    if (storeInRedux) {
      store.dispatch(
        addAppData({ name: "notifications", data: response?.data?.data }),
      );
    }

    return response;
  } catch (error) {
    return Promise.resolve(error);
  } finally {
    if (needLoader)
      store.dispatch(setLoader({ name: loader || "notifications" }));
  }
};

export const formatWeight = (weight) => {
  if (!weight) return "";
  return `${parseFloat(weight).toFixed(4)} g`;
};
