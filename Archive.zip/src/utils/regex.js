export const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

export const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;

export const nameRegex = /^(?!\d+$)[A-Za-z0-9'`-]+$/;

export const businessNameRegex = /^(?!\d+$)(?! )[A-Za-z0-9&.,'’\- ]{1,99}$/;

export const alphaNumericRegex = /^[a-zA-Z0-9]+$/;

export const nonZeroNumber = /^(?:[1-9]\d*|0\.\d*[1-9]\d*)$/;

export const positiveNumber = /^(?:0|0?[1-9]\d*|[1-9]\d*)(?:\.\d+)?$/;
