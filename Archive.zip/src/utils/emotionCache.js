import createCache from "@emotion/cache";
import rtlPlugin from "stylis-plugin-rtl";

const createEmotionCache = (isRTL) =>
  createCache({
    key: isRTL ? "mui-rtl" : "mui",
    stylisPlugins: isRTL ? [rtlPlugin] : [],
  });

export default createEmotionCache;
