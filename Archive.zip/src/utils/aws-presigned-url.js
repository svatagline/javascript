import axiosInstance from "../api/api";
import { apiEndpoints, httpMethods } from "../constants/api.constants";
import i18n from "../i18n/config";
import { setLoader } from "../redux/slices/loader.slices";
import store from "../redux/store";
import showToast from "./toast";

export const getS3PresignedUrl = async ({ needLoader, loader, data }) => {
  try {
    if (needLoader)
      store.dispatch(setLoader({ name: loader || "get-presigned-url" }));

    const headers = { "Accept-Language": i18n.resolvedLanguage };
    const payload = {
      bucket_name: process.env.REACT_APP_AWS_BUCKET,
      files: data,
    };
    const response = await axiosInstance({
      method: httpMethods.post,
      url: apiEndpoints.getS3PresignedURL,
      data: payload,
      headers,
    });

    return {
      status: true,
      data: response?.data?.data || response?.data,
    };
  } catch (error) {
    showToast();
    return {
      status: false,
      error,
    };
  } finally {
    if (needLoader)
      store.dispatch(setLoader({ name: loader || "get-presigned-url" }));
  }
};

export const uploadToS3 = async ({ needLoader, loader, file, url }) => {
  try {
    if (needLoader)
      store.dispatch(setLoader({ name: loader || "upload-to-s3" }));

    await fetch(url, { method: "PUT", body: file });
    return { status: true };
  } catch (error) {
    showToast();
    return { status: false, error };
  } finally {
    if (needLoader)
      store.dispatch(setLoader({ name: loader || "upload-to-s3" }));
  }
};
