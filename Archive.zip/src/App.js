import { CssBaseline, ThemeProvider } from "@mui/material";
import { useEffect } from "react";
import { Toaster } from "react-hot-toast";
import { useDispatch, useSelector } from "react-redux";
import { RouterProvider } from "react-router-dom";

import useI18N from "./hooks/useI18N";
import { setAppLanguage } from "./redux/slices/app.slices";
import router from "./routes/Routes";
import theme from "./themes/theme";

const App = () => {
  const dispatch = useDispatch();
  const { dir, setLanguage } = useI18N();
  const language = useSelector((state) => state.app?.language);

  useEffect(() => {
    const appLang = localStorage.getItem("appLang");

    const searchParams = new URLSearchParams(window.location.search);
    const languageParam = searchParams.get("language");

    if (languageParam) {
      const lang = ["en", "ar"].includes(languageParam) ? languageParam : "en";
      localStorage.setItem("appLang", lang);
      dispatch(setAppLanguage(lang));
    } else if (appLang) {
      dispatch(setAppLanguage(appLang));
    }
  }, [dispatch]);

  useEffect(() => {
    setLanguage(language);
    document.documentElement.setAttribute("dir", dir);
  }, [language, dir, setLanguage]);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <RouterProvider router={router} />
      <Toaster />
    </ThemeProvider>
  );
};

export default App;
