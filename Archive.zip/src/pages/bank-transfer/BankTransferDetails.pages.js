import BankTransferDetails from "../../components/bank-transfer/BankTransferDetails";

const BankTransferDetailsPage = () => {
  return <BankTransferDetails />;
};

export default BankTransferDetailsPage;
