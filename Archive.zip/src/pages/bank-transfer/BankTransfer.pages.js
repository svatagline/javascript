import BankTransfer from "../../components/bank-transfer";

const BankTransferPage = () => {
  return <BankTransfer />;
};

export default BankTransferPage;
