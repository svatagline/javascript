import ForgotPassword from "../../components/auth/forgot-password/ForgotPassword";

const ForgotPasswordPage = () => {
  return <ForgotPassword />;
};

export default ForgotPasswordPage;
