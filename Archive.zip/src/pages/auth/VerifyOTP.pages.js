import VerifyOTP from "../../components/auth/forgot-password/VerifyOTP";

const VerifyOTPPage = () => {
  return <VerifyOTP />;
};

export default VerifyOTPPage;
