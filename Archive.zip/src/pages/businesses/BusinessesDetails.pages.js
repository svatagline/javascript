import BusinessDetails from "../../components/businesses/BusinessDetails";

const BusinessesDetailsPage = () => {
  return <BusinessDetails />;
};

export default BusinessesDetailsPage;
