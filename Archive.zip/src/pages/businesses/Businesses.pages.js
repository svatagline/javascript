import Businesses from "../../components/businesses";

const BusinessesPage = () => {
  return <Businesses />;
};

export default BusinessesPage;
