import UserDetails from "../../components/users/UserDetails";

const UserDetailsPage = () => {
  return <UserDetails />;
};

export default UserDetailsPage;
