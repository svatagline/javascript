import PurchaseRequestDetails from "../../components/purchase-request/PurchaseRequestDetails";

const PurchaseRequestDetailsPage = () => {
  return <PurchaseRequestDetails />;
};

export default PurchaseRequestDetailsPage;
