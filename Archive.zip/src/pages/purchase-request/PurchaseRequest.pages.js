import PurchaseRequest from "../../components/purchase-request";

const PurchaseRequestPage = () => {
  return <PurchaseRequest />;
};

export default PurchaseRequestPage;
