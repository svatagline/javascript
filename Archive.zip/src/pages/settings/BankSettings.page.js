import BankSettings from "../../components/settings/BankSettings";

const BankSettingsPage = () => {
  return <BankSettings />;
};

export default BankSettingsPage;
