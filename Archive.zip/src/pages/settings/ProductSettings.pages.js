import ProductSettings from "../../components/settings/product-settings";

const ProductSettingsPage = () => {
  return (
    <div>
      <ProductSettings />
    </div>
  );
};

export default ProductSettingsPage;
