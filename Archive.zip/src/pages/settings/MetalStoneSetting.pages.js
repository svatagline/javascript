import MetalStoneSettings from "../../components/settings/metal-stone-settings";

const MetalStoneSettingPage = () => {
  return <MetalStoneSettings />;
};

export default MetalStoneSettingPage;
