import TaxSettings from "../../components/settings/TaxSettings";

const TaxSettingsPage = () => {
  return <TaxSettings />;
};

export default TaxSettingsPage;
