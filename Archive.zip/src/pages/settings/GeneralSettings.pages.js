import GeneralSettings from "../../components/settings/GeneralSettings";

const GeneralSettingsPage = () => {
  return <GeneralSettings />;
};

export default GeneralSettingsPage;
