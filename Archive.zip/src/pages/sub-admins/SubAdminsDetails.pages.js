import SubAdminDetails from "../../components/sub-admins/SubAdminDetails";

const SubAdminDetailsPage = () => {
  return <SubAdminDetails />;
};

export default SubAdminDetailsPage;
