import SubAdmins from "../../components/sub-admins";

const SubAdminsPage = () => {
  return <SubAdmins />;
};

export default SubAdminsPage;
