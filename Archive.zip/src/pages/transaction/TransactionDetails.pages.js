import TransactionDetails from "../../components/transaction/TransactionDetails";

const TransactionDetailsPage = () => {
  return <TransactionDetails />;
};

export default TransactionDetailsPage;
