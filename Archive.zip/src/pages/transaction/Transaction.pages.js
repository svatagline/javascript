import Transaction from "../../components/transaction";

const TransactionPage = () => {
  return <Transaction />;
};

export default TransactionPage;
