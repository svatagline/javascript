import MusharkaContracts from "../../components/musharka-contracts";

const MusharkaContractsPage = () => {
  return <MusharkaContracts />;
};

export default MusharkaContractsPage;
