import MetalsStonesPools from "../../components/metals-stones-pools";

const MetalsStonesPoolsPages = () => {
  return <MetalsStonesPools />;
};

export default MetalsStonesPoolsPages;
