import PoolsDetails from "../../components/metals-stones-pools/PoolsDetails";

const MetalsStonesPoolsDetailsPages = () => {
  return <PoolsDetails />;
};

export default MetalsStonesPoolsDetailsPages;
