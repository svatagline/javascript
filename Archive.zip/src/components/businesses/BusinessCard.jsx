import { CardContent, Typography } from "@mui/material";

import useI18N from "../../hooks/useI18N";
import SABox from "../../shared/SABox";
import SAPopover from "../../shared/SAPopover";

const BusinessCard = ({ data }) => {
  const { business_documents } = data ?? {};
  const businessDocumentsList = business_documents?.map((doc) => ({
    color: "primary",
    title: doc?.doc_type,
    icon: doc?.image,
  }));
  const { t } = useI18N();
  return (
    <SABox sx={{ padding: "0" }}>
      {/* Card Content */}
      <CardContent sx={{ padding: "0 px" }}>
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            justifyContent: "space-between",
            gap: "16px",
          }}
        >
          {businessDocumentsList?.map((item, index) => (
            <div
              key={index}
              style={{ display: "flex", alignItems: "center", gap: "12px" }}
            >
              <SAPopover
                onHover={true}
                content={<img style={{ width: "300px" }} src={item.icon}></img>}
              >
                <img
                  style={{
                    width: "50px",
                    height: "50px",
                    borderRadius: "12px",
                  }}
                  src={item.icon}
                ></img>
              </SAPopover>

              <div>
                <Typography variant="h5">{item.stats}</Typography>
                <Typography>{t(`${item.title}`.toLowerCase())}</Typography>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </SABox>
  );
};

export default BusinessCard;
