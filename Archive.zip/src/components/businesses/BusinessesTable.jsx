import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import { INDIVIDUAL } from "../../constants";
import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  loaderPath,
  tableColumns,
} from "../../descriptions/businesses.description";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import usePagination from "../../hooks/usePagination";
import { addAppData } from "../../redux/slices/app.slices";
import { Admin, Eye } from "../../shared/icon";
import SABasicTable from "../../shared/SABasicTable";
import SABox from "../../shared/SABox";
import SAButton from "../../shared/SAButton";
import SAStack from "../../shared/SAStack";
import SAStatusBadge from "../../shared/SAStatusBadge";
import SATruncateWithEllipsis from "../../shared/SATruncateWithEllipsis";
import SATypography from "../../shared/SATypography";
import { validTableValue } from "../../utils/functions";

const BusinessesTable = ({ searchQuery, submitFilterData }) => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();
  const navigation = useNavigate();

  const [refreshList, setRefreshList] = useState(false);

  const loading = useSelector((state) => state.loader?.[loaderPath.businesses]);
  const businessesData = useSelector((state) => state.app?.businesses) || {};

  const { count, results: businessesList } = businessesData;

  const onHandleView = (ownerId, businessId) =>
    navigation(`${businessId}`, { state: { ownerId } });

  const {
    totalPage,
    currentPage,
    setCurrentPage,
    itemPerPage,
    setItemPerPage,
  } = usePagination(count);

  const getBusinessesList = async ({
    page,
    page_size,
    name = "",
    submitFilterData,
  } = {}) => {
    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints?.getBusinesses}`,
      needLoader: true,
      loader: loaderPath.businesses,
      showToastOnError: true,
      params: {
        page,
        page_size,
        name,
        ...submitFilterData,
      },
    });

    if (response?.status) {
      dispatch(addAppData({ name: "businesses", data: response?.data }));
    }
  };

  const renderCell = (columnKey, data, _, value) => {
    const { email, name, account_status } = data?.owner || {};

    switch (columnKey) {
      case "name":
        return (
          <SATypography variant="body2" fontWeight={600}>
            {data?.owner?.user_type === INDIVIDUAL
              ? INDIVIDUAL
              : validTableValue(data?.name)}
          </SATypography>
        );

      case "business_account_type":
        return (
          <SAStatusBadge
            status={validTableValue(data?.business_account_type)}
          />
        );

      case "owner_name":
        return (
          <SATypography variant="body2" fontWeight={600}>
            {validTableValue(name)}
          </SATypography>
        );

      case "owner_email":
        return (
          <SATypography
            variant="body2"
            fontWeight={500}
            color="primary.main"
            sx={{
              padding: "4px 8px",
              borderRadius: "6px",
              backgroundColor: "#EEF2FF",
              display: "inline-block",
              fontSize: "0.875rem",
            }}
          >
            <SATruncateWithEllipsis
              maxLength={30}
              text={validTableValue(email)}
            />
          </SATypography>
        );

      case "total_users":
        return (
          <SAStack
            direction="row"
            alignItems="center"
            justifyContent="center"
            gap={1}
          >
            <SABox
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                bgcolor: "primary.light",
                borderRadius: 1,
                p: 0.5,
              }}
            >
              <Admin sx={{ fontSize: 18, color: "primary.main" }} />
            </SABox>
            <SATypography variant="body2" fontWeight="600" color="text.primary">
              {validTableValue(value)}
            </SATypography>
          </SAStack>
        );

      case "is_suspended":
        return (
          <SAStatusBadge
            tooltip={account_status === "DELETED"}
            title={
              account_status === "DELETED" ? data?.owner?.delete_reason : ""
            }
            status={
              account_status === "DELETED"
                ? account_status
                : value
                  ? "SUSPENDED"
                  : "ACTIVATED"
            }
          />
        );

      case "action":
        return (
          <SAButton
            onClick={() => onHandleView(data?.owner?.id, data?.id)}
            size="small"
            variant="outlined"
            sx={{
              px: 2,
              textTransform: "none",
              borderRadius: 2,
              borderColor: "grey.400",
              color: "grey.700",
              gap: 0.5,
              "&:hover": {
                backgroundColor: "grey.100",
                borderColor: "grey.600",
              },
            }}
          >
            {t("view")} <Eye />
          </SAButton>
        );

      default:
        return (
          <SATypography variant="body2">{validTableValue(value)}</SATypography>
        );
    }
  };

  const paginationProps = {
    currentPage,
    page: totalPage,
    rowsPerPage: itemPerPage,
    setItemPerPage,
    setCurrentPage,
  };

  useEffect(() => {
    getBusinessesList({
      page: currentPage,
      page_size: itemPerPage,
      name: searchQuery,
      submitFilterData: submitFilterData,
    });
  }, [currentPage, itemPerPage, searchQuery, submitFilterData]);

  useEffect(() => {
    if (refreshList) {
      setCurrentPage(1);
      setRefreshList(false);
      getBusinessesList({ page: 1 });
    }
  }, [refreshList]);

  return (
    <>
      <SABasicTable
        {...{
          loading,
          renderCell,
          data: businessesList,
          columns: tableColumns,
          paginationProps,
        }}
      />
    </>
  );
};

export default BusinessesTable;
