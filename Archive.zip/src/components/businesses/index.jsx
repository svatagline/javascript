import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Outlet, useParams } from "react-router-dom";

import {
  businessesFilterFields,
  defaultFilterValues,
} from "../../descriptions/businesses.description";
import useDebounce from "../../hooks/useDebounce";
import useI18N from "../../hooks/useI18N";
import { Search } from "../../shared/icon";
import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import { MUIStyled } from "../../shared/MUIStyled";
import SACard from "../../shared/SACard";
import SAFilterMenu from "../../shared/SAFilterMenu";
import SAStack from "../../shared/SAStack";
import SATextField from "../../shared/SATextField";
import theme from "../../themes/theme";
import BusinessesTable from "./BusinessesTable";

const SearchWrapper = MUIStyled(SAStack)(() => ({
  maxWidth: 400,
  width: "100%",
}));

const Businesses = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const debouncedSearch = useDebounce(searchTerm, 300);
  const [submitFilterData, setSubmitFilterData] = useState({});
  const [filterData, setFilterData] = useState({ ...defaultFilterValues });
  const { businessName } = useParams();
  const { t } = useI18N();
  const {
    register,
    handleSubmit,
    formState,
    control,
    reset,
    getValues,
    watch,
    setValue,
  } = useForm({
    mode: "onChange",
    defaultValues: filterData,
  });
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const watchFields = watch();

  useEffect(() => {
    if (open) {
      Object.keys(filterData).forEach((i) => {
        setValue(i, filterData[i]);
      });
    }
  }, [open]);

  const handleClick = (event) => setAnchorEl(event.currentTarget);

  const handleClose = () => setAnchorEl(null);

  const breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: "businesses" },
  ];

  const handleFilterSubmit = (formData) => {
    setSubmitFilterData(formData);
    handleClose();
  };

  const useFormControls = {
    reset,
    register,
    handleSubmit,
    formState,
    control,
    getValues,
    watchFields,
  };

  if (businessName) return <Outlet />;

  return (
    <>
      <SAStack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        mb={3}
      >
        <SAStack>
          <MUIBreadcrumbs breadcrumbsData={breadcrumbsData} />
        </SAStack>
      </SAStack>
      <SACard>
        <SAStack
          pb={2}
          mb={2}
          direction="row"
          justifyContent="space-between"
          borderBottom={`1px solid ${theme.palette.gray.main}50`}
          alignItems="center"
          flexWrap="wrap"
          gap={3}
        >
          <SearchWrapper>
            <SATextField
              placeholder={t("search-for-business-name")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{ startAdornment: <Search /> }}
            />
          </SearchWrapper>
          <SAFilterMenu
            t={t}
            anchorEl={anchorEl}
            open={open}
            handleClose={handleClose}
            onSubmit={handleFilterSubmit}
            handleClick={handleClick}
            useFormControls={useFormControls}
            setFilterData={setFilterData}
            setSubmitFilterData={setSubmitFilterData}
            defaultFilterValues={defaultFilterValues}
            filterFields={businessesFilterFields}
          />
        </SAStack>
        <BusinessesTable
          searchQuery={debouncedSearch}
          submitFilterData={submitFilterData}
        />
      </SACard>
    </>
  );
};

export default Businesses;
