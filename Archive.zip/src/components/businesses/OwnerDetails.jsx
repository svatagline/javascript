import ProfileImage from "../../assets/images/user-profile-placeholder.png";
import { BUSINESS, INDIVIDUAL } from "../../constants";
import { Email, Phone } from "../../shared/icon";
import SAShowDetails from "../../shared/SAShowDetails";
import SAStatusBadge from "../../shared/SAStatusBadge";
import SATypography from "../../shared/SATypography";
import { formatTimestamp } from "../../utils/functions";
import BusinessCard from "./BusinessCard";

const OwnerDetails = ({ ownerData, isBusinessExist, loading, businessId }) => {
  const businessData = ownerData?.businesses?.find(
    (business) => business.id == businessId,
  );

  const isBusiness = ownerData?.user_type === BUSINESS;
  const isAccountDeleted = ownerData?.account_status === "DELETED";

  const fullName = `${ownerData?.first_name} ${ownerData?.middle_name} ${ownerData?.last_name}`;

  const detailObject = {
    dataExist: isBusinessExist,
    loading: loading,
    imageSize: "sm",
    mainDetail: {
      images:
        ownerData?.user_type === INDIVIDUAL
          ? [{ url: { url: ownerData?.profile_image?.url || ProfileImage } }]
          : [{ url: { url: ProfileImage } }],
      title: isBusiness ? businessData?.name : fullName,
      badge: {
        title: `${isAccountDeleted ? "DELETED" : businessData?.is_suspended ? "SUSPENDED" : "ACTIVATED"}`,
        tooltip: isAccountDeleted,
        tooltipText: ownerData?.delete_reason,
      },
      data: [
        {
          key: "phone-number",
          value: ownerData?.phone_number,
          label: "",
          icon: <Phone />,
        },
        {
          key: "email",
          value: (
            <SATypography
              variant="body2"
              fontWeight={500}
              color="primary.main"
              sx={{
                padding: "4px 8px",
                borderRadius: "6px",
                backgroundColor: "#EEF2FF",
                display: "inline-block",
                fontSize: "0.875rem",
              }}
            >
              {ownerData?.email}
            </SATypography>
          ),
          label: "",
          icon: <Email />,
          isSeparated: true,
        },
      ],
    },
    otherDetails: [
      {
        division: 2,
        list: [
          {
            title: "business-details",
            details: [
              {
                value: isBusiness ? businessData?.name : fullName,
                title: "name",
              },
              {
                title: "account-type",
                value: (
                  <SAStatusBadge status={businessData?.business_account_type} />
                ),
                isSeparated: true,
              },
              ...(isBusiness ? [{ value: fullName, title: "owner-name" }] : []),
              {
                title: "date-joined",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={500}
                    sx={{
                      padding: "4px 8px",
                      borderRadius: "6px",
                      backgroundColor: "#F3F4F6",
                      color: "#374151",
                      display: "inline-block",
                      fontSize: "0.875rem",
                    }}
                  >
                    {ownerData?.date_joined
                      ? formatTimestamp(ownerData?.date_joined)
                      : "-"}
                  </SATypography>
                ),
                isSeparated: true,
              },
              {
                title: "last-login",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={500}
                    sx={{
                      padding: "4px 8px",
                      borderRadius: "6px",
                      backgroundColor: "#F3F4F6",
                      color: "#374151",
                      display: "inline-block",
                      fontSize: "0.875rem",
                    }}
                  >
                    {ownerData?.last_login
                      ? formatTimestamp(ownerData?.last_login)
                      : "-"}
                  </SATypography>
                ),
                isSeparated: true,
              },
            ],
          },
          {
            title: "verification-details",
            details: [
              {
                value: ownerData?.email_verified,
                title: "email-verified",
              },
              {
                value: ownerData?.phone_verified,
                title: "phone-verified",
              },
              ...(isBusiness
                ? [
                    {
                      value: ownerData?.document_verified,
                      title: "document-verified",
                    },
                    {
                      value: ownerData?.due_diligence_verified,
                      title: "due-diligence-verified",
                    },
                    {
                      value: ownerData?.business_aml_verified,
                      title: "business-aml-verified",
                    },
                  ]
                : [
                    {
                      value: ownerData?.face_verified,
                      title: "face-verified",
                    },
                    {
                      value: ownerData?.individual_aml_verified,
                      title: "individual-aml-verified",
                    },
                  ]),
            ],
          },
        ],
      },
      ...(businessData?.business_documents?.length
        ? [
            {
              data_type: "widget",
              division: 1,
              widget: {
                title: "business-documents",
                element: <BusinessCard data={businessData} />,
              },
            },
          ]
        : []),
    ],
  };
  return <SAShowDetails detailObject={detailObject} />;
};

export default OwnerDetails;
