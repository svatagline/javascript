import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Outlet, useLocation, useNavigate, useParams } from "react-router-dom";

import ProfileImage from "../../assets/images/user-profile-placeholder.png";
import { BUSINESS } from "../../constants";
import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  loaderPath,
  usersTableColumns,
} from "../../descriptions/businesses.description";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import MUITabs from "../../shared/MUITabs";
import SABasicTable from "../../shared/SABasicTable";
import SABox from "../../shared/SABox";
import SACard from "../../shared/SACard";
import LazyImage from "../../shared/SAImageLoader";
import SAStack from "../../shared/SAStack";
import SAStatusBadge from "../../shared/SAStatusBadge";
import SATruncateWithEllipsis from "../../shared/SATruncateWithEllipsis";
import SATypography from "../../shared/SATypography";
import { formatTimestamp, validTableValue } from "../../utils/functions";
import SuspendUser from "../users/SuspendUser";
import OwnerDetails from "./OwnerDetails";
import SuspendBusiness from "./SuspendBusiness";

const BusinessDetails = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const navigate = useNavigate();
  const { state } = useLocation();
  const { businessName, username } = useParams();

  const [refreshDetails, setRefreshDetails] = useState(false);
  const [businessData, setBusinessData] = useState({});

  const [isBusinessExist, setIsBusinessExist] = useState(false);
  const loading = useSelector(
    (state) => state.loader?.[loaderPath.businessOwner],
  );

  const currentBusiness = businessData?.businesses?.find(
    ({ id }) => businessName === id.toString(),
  );

  useEffect(() => {
    if (!businessName || !state?.ownerId) navigate("/");
    getBusinessOwnerDetails();
  }, [businessName, state?.ownerId]);

  useEffect(() => {
    if (refreshDetails) {
      getBusinessOwnerDetails();
      setRefreshDetails(false);
    }
  }, [refreshDetails]);

  const getBusinessOwnerDetails = async () => {
    if (!state?.ownerId) return;

    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints.getUsers}${state?.ownerId}/`,
      needLoader: true,
      loader: loaderPath.businessOwner,
      showToastOnError: true,
    });

    setIsBusinessExist(!!response?.status);
    if (response?.status) setBusinessData(response?.data);
  };

  const breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: "businesses", href: "/businesses" },
    {
      label:
        businessData?.user_type === BUSINESS
          ? currentBusiness?.name
          : `${validTableValue(businessData?.first_name, false)} ${validTableValue(businessData?.last_name, false)}`,
      noTranslate: true,
    },
  ];

  const renderCell = (columnKey, data, _, value) => {
    const currentBusiness = businessData?.businesses?.find(
      (business) => business.id == businessName,
    );

    const isAccountDeleted = data?.account_status === "DELETED";

    switch (columnKey) {
      case "name":
        return (
          <SAStack direction="row" alignItems="center" gap={1.5}>
            <SABox sx={{ width: "50px", height: "50px" }}>
              <LazyImage
                eyeIcon={false}
                src={data?.profile_image?.url || ProfileImage}
                style={{
                  width: "50px",
                  height: "50px",
                  borderRadius: "50%",
                  objectFit: "contain",
                }}
              />
            </SABox>
            <SATypography variant="body2" fontWeight={600}>
              <SATruncateWithEllipsis
                maxLength={30}
                text={`${data?.first_name} ${data?.middle_name} ${data?.last_name}`}
              />{" "}
              {data?.is_owner && (
                <SATypography
                  component="span"
                  variant="caption"
                  fontWeight={550}
                  color="grey.600"
                >
                  {`(${t("owner")})`}
                </SATypography>
              )}
            </SATypography>
          </SAStack>
        );

      case "user_type":
        return (
          <SATypography variant="body2" fontWeight="500">
            {t(validTableValue(value))}
          </SATypography>
        );

      case "created_at":
        return (
          <SATypography
            variant="body2"
            fontWeight={500}
            sx={{
              padding: "4px 8px",
              borderRadius: "6px",
              backgroundColor: "#F3F4F6",
              color: "#374151",
              display: "inline-block",
              fontSize: "0.875rem",
            }}
          >
            {value ? formatTimestamp(value) : "-"}
          </SATypography>
        );

      case "last_login":
        return (
          <SATypography
            variant="body2"
            fontWeight={500}
            sx={{
              padding: "4px 8px",
              borderRadius: "6px",
              backgroundColor: "#F3F4F6",
              color: "#374151",
              display: "inline-block",
              fontSize: "0.875rem",
            }}
          >
            {data?.last_login ? formatTimestamp(data?.last_login) : "-"}
          </SATypography>
        );

      case "status":
        return (
          <SAStatusBadge
            tooltip={isAccountDeleted}
            title={data?.delete_reason}
            status={
              isAccountDeleted
                ? "DELETED"
                : data?.is_active
                  ? "ACTIVATED"
                  : "SUSPENDED"
            }
          />
        );

      case "action":
        return (
          <SABox sx={{ display: "flex", justifyContent: "center" }}>
            <SuspendUser
              data={data}
              refresh={() => setRefreshDetails(true)}
              isBusinessSuspended={currentBusiness?.is_suspended}
            />
          </SABox>
        );

      case "email":
        return (
          <SATypography
            variant="body2"
            fontWeight={500}
            color="primary.main"
            sx={{
              padding: "4px 8px",
              borderRadius: "6px",
              backgroundColor: "#EEF2FF",
              display: "inline-block",
              fontSize: "0.875rem",
            }}
          >
            <SATruncateWithEllipsis
              text={validTableValue(value)}
              maxLength={30}
            />
          </SATypography>
        );

      default:
        return (
          <SATypography variant="body2">{validTableValue(value)}</SATypography>
        );
    }
  };

  if (username) return <Outlet />;

  return (
    <>
      <SAStack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        mb={3}
      >
        <SAStack sx={{ width: "100%" }}>
          <MUIBreadcrumbs breadcrumbsData={breadcrumbsData} />
        </SAStack>
      </SAStack>
      <SAStack sx={{ width: "100%" }}>
        <MUITabs
          afterComponent={
            <SuspendBusiness
              data={businessData}
              businessId={businessName}
              refresh={() => setRefreshDetails(true)}
            />
          }
          tabs={[
            {
              label: t("owner-details"),
              content: (
                <OwnerDetails
                  {...{
                    t,
                    loading,
                    isBusinessExist,
                    ownerData: businessData,
                    businessId: businessName,
                  }}
                />
              ),
            },
            {
              label: t("business-users"),
              content: (
                <SACard>
                  <SABasicTable
                    {...{
                      loading,
                      renderCell,
                      data: businessData?.business_users,
                      columns: usersTableColumns,
                    }}
                  />
                </SACard>
              ),
            },
          ]}
        />
      </SAStack>
    </>
  );
};

export default BusinessDetails;
