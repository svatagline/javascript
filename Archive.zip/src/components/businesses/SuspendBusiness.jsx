import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import { loaderPath } from "../../descriptions/users.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import { isRefreshList } from "../../redux/slices/users.slices";
import MUIModal from "../../shared/MUIModal";
import SABox from "../../shared/SABox";
import SAButton from "../../shared/SAButton";
import SAStack from "../../shared/SAStack";
import SATypography from "../../shared/SATypography";

const SuspendBusinessContent = ({ handleClose, t, data, refresh }) => {
  const { api } = useAPI();
  const dispatch = useDispatch();
  const { is_suspended, id } = data ?? {};

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.userSuspendLoading],
  );

  const onSubmit = async () => {
    const accountStatus = !is_suspended ? "SUSPEND" : "REACTIVATE";

    const response = await api({
      method: httpMethods.patch,
      endPoint: apiEndpoints.businessSuspension(id),
      data: { business_account_status: accountStatus },
      needLoader: true,
      loader: loaderPath.userSuspendLoading,
      showToastMessage: true,
    });

    if (response?.status) {
      handleClose();
      refresh && refresh();
      dispatch(isRefreshList(true));
    }
  };

  return (
    <SABox p={2}>
      <SATypography variant="h6" fontWeight={500} textAlign="center">
        {t(`${is_suspended ? "activate" : "suspend"}-business-title`)}
      </SATypography>
      <SAStack direction="row" mt={3} justifyContent="center" gap={2}>
        <SAButton variant="outlined" color="primary" onClick={handleClose}>
          {t("cancel")}
        </SAButton>
        <SAButton
          color="primary"
          variant="contained"
          loading={loading}
          onClick={onSubmit}
          sx={{ borderRadius: "8px" }}
        >
          {t(is_suspended ? "activate" : "suspend")}
        </SAButton>
      </SAStack>
    </SABox>
  );
};

const SuspendBusiness = ({ isEditAction, data, refresh, businessId }) => {
  const { t } = useI18N();
  const [addEditSubAdminModal, setAddEditSubAdminModal] = useState(false);

  const businessData = data?.businesses?.find(
    (business) => business.id == businessId,
  );

  const isAccountDeleted = data?.account_status === "DELETED";

  const handleClose = () => setAddEditSubAdminModal(false);

  return (
    <>
      <SABox sx={{ width: "auto", display: "flex", justifyContent: "end" }}>
        <SAButton
          color="primary"
          onClick={() => setAddEditSubAdminModal(true)}
          size="small"
          variant="outlined"
          sx={{ "& svg": { ml: 1 }, margin: "0" }}
          disabled={isAccountDeleted}
        >
          {t(`${!businessData?.is_suspended ? "suspend" : "approve"}-business`)}
        </SAButton>
      </SABox>
      <MUIModal
        open={addEditSubAdminModal}
        handleClose={handleClose}
        content={
          <SuspendBusinessContent
            t={t}
            refresh={refresh}
            data={businessData}
            handleClose={handleClose}
            isEditAction={isEditAction}
          />
        }
      />
    </>
  );
};

export default SuspendBusiness;
