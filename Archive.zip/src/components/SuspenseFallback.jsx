import SABox from "../shared/SABox";
import SALoader from "../shared/SALoader";

const SuspenseFallback = () => {
  return (
    <SABox
      display="flex"
      justifyContent="center"
      alignItems="center"
      height="100vh"
      bgcolor="#f8f9fa"
      flexGrow={1}
    >
      <SALoader size={45} />
    </SABox>
  );
};

export default SuspenseFallback;
