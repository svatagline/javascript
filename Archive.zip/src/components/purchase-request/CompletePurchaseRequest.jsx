import TaskAltIcon from "@mui/icons-material/TaskAlt";
import { useState } from "react";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import { loaderPath } from "../../descriptions/purchaseRequests.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import SAButton from "../../shared/SAButton";

const CompletePurchaseRequest = ({ id, status, onCompleted }) => {
  const { t } = useI18N();
  const { api } = useAPI();
  const [loading, setLoading] = useState(false);

  const onSubmit = async () => {
    setLoading(true);
    const response = await api({
      method: httpMethods.patch,
      endPoint: `${apiEndpoints.completeAssetRequest}${id}/`,
      needLoader: true,
      loader: loaderPath.purchaseRequestsComplete,
      showToastMessage: true,
    });
    setLoading(false);
    if (response?.status) onCompleted();
  };

  return (
    <SAButton
      size="small"
      onClick={onSubmit}
      variant="outlined"
      loading={loading}
      disabled={status === "COMPLETED"}
      sx={{
        textTransform: "none",
        borderColor: "#115293",
        color: "#115293",
        "& svg": { ml: 1 },
      }}
    >
      {t("complete")} <TaskAltIcon sx={{ height: 16, width: 16 }} />
    </SAButton>
  );
};

export default CompletePurchaseRequest;
