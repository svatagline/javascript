import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import { loaderPath } from "../../descriptions/purchaseRequests.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import {
  Brand,
  Condition,
  Date,
  Packaging,
  SerialNum,
  WeighingScale,
} from "../../shared/icon";
import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import SAShowDetails from "../../shared/SAShowDetails";
import SAStack from "../../shared/SAStack";
import SAStatusBadge from "../../shared/SAStatusBadge";
import SATruncateWithEllipsis from "../../shared/SATruncateWithEllipsis";
import SATypography from "../../shared/SATypography";
import {
  formatAmount,
  formatTimestamp,
  formatWeight,
  validDetailsValue,
  validTableValue,
} from "../../utils/functions";

const PurchaseRequestDetails = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const urlParams = useParams();

  const [transactionData, setPurchaseRequestData] = useState({});
  const [purchaseRequestDataExist, setPurchaseRequestDataExist] =
    useState(false);

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.purchaseRequestsDetails],
  );

  useEffect(() => {
    getPurchaseRequestsDetails();
  }, [urlParams?.purchaseRequestsId]);

  const getPurchaseRequestsDetails = async () => {
    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints?.getPurchaseRequest}${urlParams?.purchaseRequestsId}/`,
      needLoader: true,
      loader: loaderPath.purchaseRequestsDetails,
      showToastOnError: true,
    });

    if (response?.status) {
      setPurchaseRequestData(response?.data);
      setPurchaseRequestDataExist(true);
    } else {
      setPurchaseRequestDataExist(false);
    }
  };

  const breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: "purchase-requests", href: "/purchase-requests" },
    { label: urlParams?.purchaseRequestsId, noTranslate: true },
  ];

  let materialType = transactionData?.precious_item?.precious_stone_details
    ? "precious_stone_details"
    : transactionData?.precious_item?.precious_metal_details
      ? "precious_metal_details"
      : {};

  const detailObject = {
    dataExist: purchaseRequestDataExist,
    loading: loading,
    mainDetail: {
      images: transactionData?.precious_item?.precious_item_images,
      title: transactionData?.precious_item?.name,
      badge: { title: transactionData?.status?.toUpperCase() },
      data: [
        {
          key: "weight",
          value: (
            <SATypography
              variant="body2"
              sx={{
                fontWeight: 600,
                color: "#1F2937",
                backgroundColor: "#F3F4F6",
                padding: "4px 8px",
                borderRadius: "6px",
                display: "inline-block",
              }}
            >
              {formatWeight(
                transactionData?.precious_item?.[materialType]?.weight,
              )}
            </SATypography>
          ),
          label: "",
          icon: <WeighingScale />,
          isSeparated: true,
        },
        {
          key: "brand",
          value: transactionData?.precious_item?.[materialType]?.brand,
          label: "",
          icon: <Brand />,
        },
        {
          key: "serial-number",
          value: transactionData?.precious_item?.[materialType]?.serial_number,
          label: "",
          icon: <SerialNum />,
        },
        {
          key: "condition",
          value: transactionData?.precious_item?.[materialType]?.condition,
          label: "",
          icon: <Condition />,
        },
        {
          key: "packaging",
          value: transactionData?.precious_item?.[materialType]?.packaging,
          label: "",
          icon: <Packaging />,
        },
        {
          key: "manufacture-date",
          value: validDetailsValue(
            transactionData?.precious_item?.[materialType]?.manufacture_date,
            "date",
          ),
          label: "",
          icon: <Date fill="#ffffff" width="15px" height="15px" />,
        },
      ],
    },
    otherDetails: [
      {
        division: 2,
        list: [
          {
            title: "precious-item-details",
            details: [
              {
                value: t(transactionData?.precious_item?.name),
                title: "name",
              },
              {
                title: "material-type",
                value: (
                  <SAStatusBadge
                    status={transactionData?.precious_item?.material_item?.material_type?.toUpperCase()}
                  />
                ),
                isSeparated: true,
              },
              {
                value: transactionData?.precious_item?.created_by,
                title: "created-by",
              },
              {
                title: "created-at",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={500}
                    sx={{
                      padding: "4px 8px",
                      borderRadius: "6px",
                      backgroundColor: "#F3F4F6",
                      color: "#374151",
                      display: "inline-block",
                      fontSize: "0.875rem",
                    }}
                  >
                    {transactionData?.precious_item?.created_at
                      ? formatTimestamp(
                          transactionData?.precious_item?.created_at,
                        )
                      : ""}
                  </SATypography>
                ),
                isSeparated: true,
              },
              {
                title: "description",
                value: (
                  <SATruncateWithEllipsis
                    text={transactionData?.precious_item?.description}
                    maxLength={35}
                  />
                ),
                isSeparated: true,
              },
              {
                value: transactionData?.precious_item?.premium_price_percentage,
                title: "premium-price-percentage",
              },
              {
                title: "premium-price-amount",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={550}
                    fontSize={16}
                    color={"#027A48"}
                  >
                    {formatAmount(
                      transactionData?.precious_item?.premium_price_amount,
                      false,
                    )}
                  </SATypography>
                ),
                isSeparated: true,
              },
              {
                value: transactionData?.precious_item?.additional_features,
                title: "additional-features",
              },
              {
                value: transactionData?.precious_item?.certificate_type,
                title: "certificate-type",
              },
            ],
          },
          {
            title: "request-details",
            details: [
              {
                title: "request-type",
                value: (
                  <SAStatusBadge
                    status={validTableValue(transactionData?.request_type)}
                  />
                ),
                isSeparated: true,
              },
              {
                value: transactionData?.created_by,
                title: "created-by",
              },
              {
                value: transactionData?.requested_quantity,
                title: "requested-quantity",
              },
              {
                title: "price-locked",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={550}
                    fontSize={16}
                    color={"#027A48"}
                  >
                    {formatAmount(transactionData?.price_locked, false)}
                  </SATypography>
                ),
                isSeparated: true,
              },
              {
                title: "total-cost",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={550}
                    fontSize={16}
                    color={"#027A48"}
                  >
                    {formatAmount(transactionData?.total_cost, false)}
                  </SATypography>
                ),
                isSeparated: true,
              },
              {
                title: "created-at",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={500}
                    sx={{
                      padding: "4px 8px",
                      borderRadius: "6px",
                      backgroundColor: "#F3F4F6",
                      color: "#374151",
                      display: "inline-block",
                      fontSize: "0.875rem",
                    }}
                  >
                    {transactionData?.created_at
                      ? formatTimestamp(transactionData?.created_at)
                      : ""}
                  </SATypography>
                ),
                isSeparated: true,
              },
              {
                title: "updated-at",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={500}
                    sx={{
                      padding: "4px 8px",
                      borderRadius: "6px",
                      backgroundColor: "#F3F4F6",
                      color: "#374151",
                      display: "inline-block",
                      fontSize: "0.875rem",
                    }}
                  >
                    {transactionData?.updated_at
                      ? formatTimestamp(transactionData?.updated_at)
                      : ""}
                  </SATypography>
                ),
                isSeparated: true,
              },
              {
                title: "status",
                value: (
                  <SAStatusBadge
                    status={validTableValue(transactionData?.status)}
                  />
                ),
                isSeparated: true,
              },
              {
                title: "completed-at",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={500}
                    sx={{
                      padding: "4px 8px",
                      borderRadius: "6px",
                      backgroundColor: "#F3F4F6",
                      color: "#374151",
                      display: "inline-block",
                      fontSize: "0.875rem",
                    }}
                  >
                    {transactionData?.completed_at
                      ? formatTimestamp(transactionData?.completed_at)
                      : ""}
                  </SATypography>
                ),
                isSeparated: true,
              },
            ],
          },
        ],
      },
    ],
  };

  return (
    <>
      <SAStack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        mb={3}
      >
        <SAStack>
          <MUIBreadcrumbs breadcrumbsData={breadcrumbsData} />
        </SAStack>
      </SAStack>
      <SAShowDetails detailObject={detailObject} />
    </>
  );
};

export default PurchaseRequestDetails;
