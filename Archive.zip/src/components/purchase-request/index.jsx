import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { Outlet, useParams } from "react-router-dom";

import { TABLE_RECORD_PER_PAGE } from "../../constants";
import {
  defaultPurchaseRequestsFilterValues,
  purchaseRequestsFilterFields,
} from "../../descriptions/purchaseRequests.descriptions";
import useDebounce from "../../hooks/useDebounce";
import useI18N from "../../hooks/useI18N";
import usePagination from "../../hooks/usePagination";
import { Search } from "../../shared/icon";
import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import { MUIStyled } from "../../shared/MUIStyled";
import SACard from "../../shared/SACard";
import SAFilterMenu from "../../shared/SAFilterMenu";
import SAStack from "../../shared/SAStack";
import SATextField from "../../shared/SATextField";
import theme from "../../themes/theme";
import { compareAmounts, compareDates } from "../../utils/functions";
import showToast from "../../utils/toast";
import PurchaseRequestTable from "./PurchaseRequestTable";

const SearchWrapper = MUIStyled(SAStack)(() => ({
  maxWidth: 400,
  width: "100%",
}));

const PurchaseRequest = () => {
  const { t } = useI18N();
  const { purchaseRequestsId } = useParams();

  const [searchTerm, setSearchTerm] = useState("");
  const [submitFilterData, setSubmitFilterData] = useState({});
  const [anchorEl, setAnchorEl] = useState(null);
  const [filterData, setFilterData] = useState({
    ...defaultPurchaseRequestsFilterValues,
  });

  const purchaseRequestList =
    useSelector((state) => state?.purchaseRequests?.purchaseRequests) ?? [];

  const { count, results: purchaseRequestData } = purchaseRequestList;

  const {
    totalPage,
    currentPage,
    setCurrentPage,
    itemPerPage,
    setItemPerPage,
  } = usePagination(count, TABLE_RECORD_PER_PAGE);

  const debouncedSearch = useDebounce(searchTerm, 300, () => {
    setCurrentPage(1);
  });

  const {
    register,
    handleSubmit,
    formState,
    control,
    reset,
    getValues,
    watch,
    setValue,
  } = useForm({
    mode: "onChange",
    defaultValues: filterData,
  });

  const open = Boolean(anchorEl);
  const watchFields = watch();

  useEffect(() => {
    if (open) {
      Object.keys(filterData).forEach((i) => {
        setValue(i, filterData[i]);
      });
    }
  }, [open]);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: "purchase-requests" },
  ];

  const handleFilterSubmit = (formData) => {
    try {
      const { total_cost_min, total_cost_max, created_at_max, created_at_min } =
        formData;

      compareAmounts({
        min_amount: total_cost_min,
        max_amount: total_cost_max,
        min_amount_field: "Total Min Cost",
        max_amount_field: "Total Max Cost",
        errorMessage: "min-cost-should-be-less-than-max-cost",
      });

      compareDates({
        start_date: created_at_min,
        end_date: created_at_max,
        start_date_field: "Min Created Date",
        end_date_field: "Max Created Date",
        errorMessage: "min-created-date-should-be-less-than-created-max-date",
      });

      setCurrentPage(1);
      setSubmitFilterData(formData);
      handleClose();
    } catch (error) {
      showToast(error);
    }
  };

  if (purchaseRequestsId) return <Outlet />;

  const useFormControls = {
    register,
    handleSubmit,
    formState,
    control,
    reset,
    getValues,
    watchFields,
  };

  return (
    <>
      <SAStack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        mb={3}
      >
        <SAStack>
          <MUIBreadcrumbs breadcrumbsData={breadcrumbsData} />
        </SAStack>
      </SAStack>
      <SACard>
        <SAStack
          pb={2}
          mb={2}
          direction="row"
          justifyContent="space-between"
          borderBottom={`1px solid ${theme.palette.gray.main}50`}
          alignItems="center"
          flexWrap="wrap"
          gap={3}
        >
          <SearchWrapper>
            <SATextField
              placeholder={t("search-for-precious-item")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{ startAdornment: <Search /> }}
            />
          </SearchWrapper>
          <SAFilterMenu
            t={t}
            anchorEl={anchorEl}
            open={open}
            handleClose={handleClose}
            onSubmit={handleFilterSubmit}
            handleClick={handleClick}
            useFormControls={useFormControls}
            setFilterData={setFilterData}
            setSubmitFilterData={setSubmitFilterData}
            defaultFilterValues={defaultPurchaseRequestsFilterValues}
            filterFields={purchaseRequestsFilterFields}
          />
        </SAStack>
        <PurchaseRequestTable
          searchQuery={debouncedSearch}
          submitFilterData={submitFilterData}
          totalPage={totalPage}
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          itemPerPage={itemPerPage}
          setItemPerPage={setItemPerPage}
          purchaseRequestData={purchaseRequestData}
        />
      </SACard>
    </>
  );
};

export default PurchaseRequest;
