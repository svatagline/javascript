import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  loaderPath,
  purchaseRequestTableColumns,
} from "../../descriptions/purchaseRequests.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import {
  addPurchaseRequests,
  isRefreshList,
} from "../../redux/slices/purchaseRequests.slice";
import { Eye } from "../../shared/icon";
import SABasicTable from "../../shared/SABasicTable";
import SABox from "../../shared/SABox";
import SAButton from "../../shared/SAButton";
import SAStatusBadge from "../../shared/SAStatusBadge";
import SATruncateWithEllipsis from "../../shared/SATruncateWithEllipsis";
import SATypography from "../../shared/SATypography";
import {
  convertDatesToTimestampsInObject,
  excludeKeys,
  formatAmount,
  formatTimestamp,
  validTableValue,
} from "../../utils/functions";
import CompletePurchaseRequest from "./CompletePurchaseRequest";

const PurchaseRequestTable = ({
  searchQuery,
  submitFilterData,
  totalPage,
  currentPage,
  setCurrentPage,
  itemPerPage,
  purchaseRequestData,
  setItemPerPage,
}) => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();
  const navigation = useNavigate();
  const [sort, setSort] = useState({ field: "created_at", sortType: "2" }); //1 Ascending; 2 Descending
  const loading = useSelector(
    (state) => state.loader?.[loaderPath.purchaseRequests],
  );

  const refreshList = useSelector(
    (state) => state?.purchaseRequests?.refreshList,
  );

  const onHandleView = (id) => navigation(`${id}`);

  const getPurchaseRequestsList = async ({
    page,
    page_size,
    precious_item = "",
    ordering = "created_at",
    submitFilterData,
  } = {}) => {
    const statusParams = submitFilterData?.status?.length
      ? submitFilterData?.status.map((status) => `status=${status}`)
      : [];
    const requestsTypeParams = submitFilterData?.request_type?.length
      ? submitFilterData?.request_type.map(
          (request_type) => `request_type=${request_type}`,
        )
      : [];
    const materialTypeParams = submitFilterData?.material_type?.length
      ? submitFilterData?.material_type.map(
          (material_type) => `material_type=${material_type}`,
        )
      : [];

    const params = [
      ...statusParams,
      ...requestsTypeParams,
      ...materialTypeParams,
    ];
    const paramsString = params?.length
      ? `?${params.map((p) => p).join("&")}`
      : "";

    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints.getPurchaseRequests}${paramsString}`,
      needLoader: true,
      loader: loaderPath.purchaseRequests,
      showToastOnError: true,
      params: {
        page,
        page_size,
        precious_item,
        ordering,
        ...convertDatesToTimestampsInObject(
          excludeKeys(submitFilterData, [
            "status",
            "request_type",
            "material_type",
          ]),
          ["created_at_min", "created_at_max"],
        ),
      },
    });

    if (response?.status)
      dispatch(addPurchaseRequests({ data: response?.data }));
  };

  const paginationProps = {
    currentPage,
    page: totalPage,
    rowsPerPage: itemPerPage,
    setItemPerPage,
    setCurrentPage,
  };

  useEffect(() => {
    callPurchaseRequests();
  }, [currentPage, itemPerPage, searchQuery, submitFilterData, sort]);

  useEffect(() => {
    if (refreshList) {
      setCurrentPage(1);
      getPurchaseRequestsList({ page: 1 });
      dispatch(isRefreshList(false));
    }
  }, [refreshList]);

  const callPurchaseRequests = () => {
    getPurchaseRequestsList({
      page: currentPage,
      page_size: itemPerPage,
      precious_item: searchQuery,
      submitFilterData: submitFilterData,
      ordering: sort.sortType === "2" ? `-${sort?.field}` : sort?.field,
    });
  };

  const renderCell = (columnKey, data, _, value) => {
    const { id, status, precious_item, created_by } = data || {};
    switch (columnKey) {
      case "action":
        return (
          <SABox sx={{ display: "flex", justifyContent: "center", gap: 10 }}>
            {["APPROVED", "COMPLETED"].includes(status) ? (
              <CompletePurchaseRequest
                {...{ id, status, onCompleted: callPurchaseRequests }}
              />
            ) : (
              "-"
            )}
          </SABox>
        );

      case "view":
        return (
          <SABox sx={{ display: "flex", justifyContent: "center" }}>
            <SAButton
              size="small"
              variant="outlined"
              onClick={() => onHandleView(id)}
              sx={{
                px: 2,
                textTransform: "none",
                borderRadius: 2,
                borderColor: "grey.400",
                color: "grey.700",
                "&:hover": {
                  backgroundColor: "grey.100",
                  borderColor: "grey.600",
                },
                "& svg": { ml: 1 },
              }}
            >
              {t("view")} <Eye />
            </SAButton>
          </SABox>
        );

      case "total_cost":
        return (
          <SATypography
            variant="body2"
            fontWeight={600}
            color={"#027A48"}
            sx={{
              padding: "6px 12px",
              borderRadius: "6px",
              display: "inline-block",
            }}
          >
            {`${formatAmount(value)}`}
          </SATypography>
        );

      case "material_type":
        return (
          <SAStatusBadge
            status={validTableValue(
              precious_item?.material_type?.toUpperCase(),
            )}
          />
        );

      case "precious_item":
        return (
          <SATypography variant="body2">
            <SATruncateWithEllipsis
              maxLength={21}
              text={validTableValue(precious_item?.name)}
            />
          </SATypography>
        );

      case "created_at":
        return (
          <SATypography
            variant="body2"
            fontWeight={500}
            sx={{
              padding: "4px 8px",
              borderRadius: "6px",
              backgroundColor: "#F3F4F6",
              color: "#374151",
              display: "inline-block",
              fontSize: "0.875rem",
            }}
          >
            {formatTimestamp(value)}
          </SATypography>
        );

      case "requested_from":
        return (
          <SATypography
            sx={{ color: "grey.900", fontWeight: 500, fontSize: 14 }}
          >
            <SATruncateWithEllipsis
              maxLength={20}
              text={validTableValue(created_by)}
            />
          </SATypography>
        );

      case "requested_to":
        return (
          <SATypography
            sx={{ color: "grey.900", fontWeight: 500, fontSize: 14 }}
          >
            <SATruncateWithEllipsis
              maxLength={20}
              text={validTableValue(precious_item?.created_by)}
            />
          </SATypography>
        );

      case "request_type":
        return <SAStatusBadge status={validTableValue(value)} />;

      case "status":
        return <SAStatusBadge status={validTableValue(value)} />;

      default:
        return (
          <SATypography variant="body2">{validTableValue(value)}</SATypography>
        );
    }
  };

  const modifiedColumns = () => {
    return purchaseRequestTableColumns.map((column) => {
      if (column.key === sort.field) {
        return {
          ...column,
          sortType: sort.sortType === "1" ? "1" : "2",
        };
      }
      return column;
    });
  };

  const onSort = ({ key, sortType }) => {
    setSort({ field: key, sortType: sortType === "1" ? "2" : "1" });
  };
  return (
    <>
      <SABasicTable
        {...{
          loading,
          data: purchaseRequestData || [],
          columns: modifiedColumns(),
          renderCell,
          paginationProps,
          colSpan: 5,
          onSort,
        }}
      />
    </>
  );
};

export default PurchaseRequestTable;
