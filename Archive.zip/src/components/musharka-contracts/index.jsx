import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import SACard from "../../shared/SACard";
import SAStack from "../../shared/SAStack";
import MusharkaTable from "./MusharkaTable";

// const contractsTableData = [
//   {
//     designer: "Alice Design Co.",
//     investor: "Green Capital",
//     material_type: "metal",
//     material_item: "Gold Ring",
//     status: "Active",
//     created_at: "2025-03-15",
//     target: "5",
//     action: "View",
//   },
//   {
//     designer: "Bold Blueprint Studio",
//     investor: "NextGen Ventures",
//     material_type: "stone",
//     material_item: "Onyx",
//     status: "Pending",
//     created_at: "2025-04-05",
//     target: "12",
//     action: "View",
//   },
// ];

const MusharkaContracts = () => {
  const breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: "musharka-contracts" },
  ];

  return (
    <>
      <SAStack
        mb={3}
        direction="row"
        alignItems="center"
        justifyContent="space-between"
      >
        <SAStack>
          <MUIBreadcrumbs {...{ breadcrumbsData }} />
        </SAStack>
      </SAStack>
      <SACard>
        <MusharkaTable />
      </SACard>
    </>
  );
};

export default MusharkaContracts;
