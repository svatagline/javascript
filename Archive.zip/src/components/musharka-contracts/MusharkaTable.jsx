import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

import { TABLE_RECORD_PER_PAGE } from "../../constants";
import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  contractsTableColumns,
  loaderPath,
} from "../../descriptions/musharka.description";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import usePagination from "../../hooks/usePagination";
import {
  addMusharkaContracts,
  isRefreshList,
} from "../../redux/slices/musharkaContracts.slice";
import { Eye } from "../../shared/icon";
import SABasicTable from "../../shared/SABasicTable";
import SAButton from "../../shared/SAButton";
import SAStack from "../../shared/SAStack";
import SAStatusBadge from "../../shared/SAStatusBadge";
import SATruncateWithEllipsis from "../../shared/SATruncateWithEllipsis";
import SATypography from "../../shared/SATypography";
import { formatTimestamp } from "../../utils/functions";

const MusharkaTable = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();

  const musharkaData = useSelector(
    (state) => state.musharkaContracts?.musharkaContracts || {},
  );
  const refreshList = useSelector(
    (state) => state.musharkaContracts?.refreshList,
  );
  const loading = useSelector(
    (state) => state.loader?.[loaderPath.musharkaContracts],
  );

  const { count, results: musharkaList } = musharkaData;

  const {
    totalPage,
    currentPage,
    itemPerPage,
    setCurrentPage,
    setItemPerPage,
  } = usePagination(count, TABLE_RECORD_PER_PAGE);

  useEffect(() => {
    getMusharkaList({ page: currentPage, page_size: itemPerPage });
  }, [currentPage, itemPerPage]);

  useEffect(() => {
    if (refreshList) {
      setCurrentPage(1);
      dispatch(isRefreshList(false));
      getMusharkaList({ page: 1, page_size: itemPerPage });
    }
  }, [refreshList]);

  const getMusharkaList = async ({ page, page_size } = {}) => {
    const response = await api({
      method: httpMethods.get,
      endPoint: apiEndpoints.getMusharkaContracts,
      needLoader: true,
      loader: loaderPath.musharkaContracts,
      showToastOnError: true,
      params: { page, page_size },
    });

    if (response?.status) {
      dispatch(
        addMusharkaContracts({
          name: "musharkaContracts",
          data: response?.data,
        }),
      );
    }
  };

  const renderCell = (columnKey, rowData, _, value) => {
    switch (columnKey) {
      case "design":
      case "design_type":
        return (
          <SATypography sx={{ fontWeight: 550, fontSize: 14 }}>
            <SATruncateWithEllipsis text={value} maxLength={25} />
          </SATypography>
        );

      case "investor":
        return (
          <SATypography sx={{ fontWeight: 550, fontSize: 14 }}>
            {rowData?.investor?.name || "NOT ASSIGNED"}
          </SATypography>
        );

      case "jeweler":
        return (
          <SATypography sx={{ fontWeight: 550, fontSize: 14 }}>
            {rowData?.jeweler?.name || "-"}
          </SATypography>
        );

      case "status":
        return <SAStatusBadge status={value?.toUpperCase()} />;

      case "target":
        return (
          <SATypography sx={{ fontWeight: 600, fontSize: 14 }}>
            {`${value} kg`}
          </SATypography>
        );

      case "expiry_date":
        return (
          <SATypography
            variant="body2"
            fontWeight={500}
            sx={{
              padding: "4px 8px",
              borderRadius: "6px",
              color: "#374151",
              backgroundColor: "#F3F4F6",
              display: "inline-block",
              fontSize: "0.875rem",
            }}
          >
            {value ? formatTimestamp(value) : "-"}
          </SATypography>
        );

      case "view":
        return (
          <SAButton
            size="small"
            variant="outlined"
            // onClick={() => handleView(rowData?.id)}
            sx={{
              px: 2,
              gap: 0.5,
              borderRadius: 2,
              color: "grey.700",
              textTransform: "none",
              borderColor: "grey.400",
              "&:hover": {
                borderColor: "grey.600",
                backgroundColor: "grey.100",
              },
            }}
          >
            {t("view")} <Eye />
          </SAButton>
        );

      case "action":
        return (
          <SAStack direction="row" justifyContent="center" gap={2}>
            <SAButton
              type="submit"
              color="primary"
              variant="contained"
              disabled={!rowData?.investor}
              // loading={loading}
            >
              {t("approve")}
            </SAButton>
            <SAButton
              variant="outlined"
              color="primary"
              disabled={!rowData?.investor}
              // onClick={handleCloseModal}
            >
              {t("cancel")}
            </SAButton>
          </SAStack>
        );

      default:
        return value ?? "-";
    }
  };

  const paginationProps = {
    currentPage,
    setItemPerPage,
    setCurrentPage,
    page: totalPage,
    rowsPerPage: itemPerPage,
  };

  return (
    <SABasicTable
      {...{
        loading,
        renderCell,
        paginationProps,
        data: musharkaList,
        columns: contractsTableColumns,
      }}
    />
  );
};

export default MusharkaTable;
