import { Box, List, ListItem, Typography } from "@mui/material";

import Logo from "../assets/images/logo.png";

const TermsAndConditions = () => {
  return (
    <Box
      sx={{
        padding: 2,
        maxWidth: "1000px",
        margin: "0 auto",
        "& .MuiListItem-root": {
          flexDirection: "column",
          justifyContent: "start",
          alignItems: "start",
          textAlign: "start",
          paddingLeft: 0,
          paddingRight: 0,
          "& .MuiTypography-h6,& .MuiTypography-root:has(strong)": {
            "&::after": {
              display: "none",
            },
          },
          "& .MuiList-root": {
            paddingLeft: 4,
          },
          "& .MuiTypography-root": {
            position: "relative",
            "&::after": {
              content: "''",
              position: "absolute",
              top: 8,
              left: -12,
              height: 5,
              width: 5,
              borderRadius: "50%",
              backgroundColor: "#000000",
            },
          },
        },
      }}
    >
      <Box
        sx={{
          img: {
            display: "block",
            cursor: "pointer",
            margin: "12px auto 24px",
          },
        }}
        onClick={() => (window.location.href = "https://sooqalthahab.com/")}
      >
        <img src={Logo} alt="logo" />
      </Box>
      <Typography variant="h4" textAlign="center" gutterBottom>
        Sooq Al Thahab Subscription Terms and Conditions
      </Typography>

      <List>
        <ListItem>
          <Typography variant="h6" fontSize={30}>
            Definitions
          </Typography>
        </ListItem>
        <ListItem>
          <Typography variant="body1">
            <strong>Platform:</strong> refers to the Sooq Al Thahab and its
            services, encompassing the Online Marketplace, Showroom, and Gold
            Cloud System, designed to streamline the digital and physical
            operations of savers, jewelers/designers, manufacturers, and
            precious metal and stone sellers.
          </Typography>
        </ListItem>
        <ListItem>
          <Typography variant="body1">
            <strong>Consumer:</strong> Consumers are individuals or businesses
            who purchase jewelry, precious metals, and precious stones or
            request custom-made designs through the Sooq Al Thahab platform.
            They can also use the Gold Cloud system to save precious metals and
            precious stones for future use in Musharakah or pool agreements.
          </Typography>
        </ListItem>
        <ListItem>
          <Typography variant="body1">
            <strong>Jeweler/Designer:</strong> refers to an individual or legal
            entity that offers jewelry or jewelry designs under their brand for
            inclusion in the Platform. This includes entities operating as sole
            proprietors, partnerships, or corporations.
          </Typography>
        </ListItem>
        <ListItem>
          <Typography variant="body1">
            <strong>Manufacturer:</strong> refers to an individual or legal
            entity engaged in the production of finished jewelry products using
            raw materials and designs provided by Jewelers/Designers.
            Manufacturers must comply with all relevant industry standards and
            legal certifications.
          </Typography>
        </ListItem>
        <ListItem>
          <Typography variant="body1">
            <strong>Precious Metal and Stone Seller:</strong> refers to an
            individual or legal entity authorized to supply certified materials,
            such as gold or gemstones, for use in the manufacturing of jewelry.
            Sellers must hold all necessary certifications and comply with
            applicable legal and industry standards.
          </Typography>
        </ListItem>
        <ListItem>
          <Typography variant="body1">
            <strong>Agreement:</strong> refers to these Terms and Conditions and
            any supplementary agreements entered into between the user and Sooq
            Althahab, including but not limited to the Wekalah (Power of
            Attorney) arrangement where applicable.
          </Typography>
        </ListItem>
        <ListItem>
          <Typography variant="body1">
            <strong>User:</strong> refers to any individual or legal entity that
            registers on or interacts with the Sooq Al Thahab platform. A User
            may be a Consumer, Jeweler/Designer, Manufacturer, or Precious Metal
            and Stone Seller, depending on their activities within the platform.
            Users agree to abide by these Terms and Conditions and any
            applicable agreements when using the platform’s services.
          </Typography>
        </ListItem>

        <ListItem>
          <Typography variant="h6">General Terms of Use</Typography>
        </ListItem>
        <ListItem>
          <List>
            <ListItem>
              <Typography variant="body1">
                By registering on the Platform, users agree to be bound by these
                Terms and Conditions.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body1">
                The Platform facilitates interactions between the aforementioned
                user types and each user is held responsible for their own
                responsibilities and actions.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body1">
                All users must ensure compliance with applicable laws and
                regulations of the Kingdom of Bahrain, including without
                limitation to anti-money laundering (AML), Personal Data
                Protection (PDPL), and counter-financing of terrorism (CFT)
                obligations.
              </Typography>
            </ListItem>
          </List>
        </ListItem>

        <ListItem>
          <Typography variant="h6">User Roles and Obligations</Typography>
        </ListItem>
        <ListItem sx={{ "&.MuiListItem-root": { pl: "24px !important" } }}>
          <Typography variant="body1">
            <strong>Consumers:</strong>
          </Typography>
          <List>
            <ListItem>
              <Typography variant="body2">For Marketplace:</Typography>
              <List>
                <ListItem>
                  <Typography variant="body2">
                    Purchase Jewelry, Precious Metals, & Precious Stones:
                    Consumers can browse and buy jewelry pieces, gold,
                    gemstones, and other certified materials from verified
                    sellers, jewelers, and manufacturers.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Place Custom Orders: Consumers may request customized
                    jewelry designs, including engraving, modifications, and
                    bespoke creations from jewelers/designers.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Order Fulfillment & Delivery: Orders will be processed based
                    on the timeline agreed with the seller. Consumers must
                    review and approve the final design before production
                    begins. Delivery terms, tracking, and insurance options will
                    be clearly stated at checkout.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Consumer Protection & Dispute Resolution: Consumers can file
                    complaints regarding order issues, product quality, or
                    delivery problems via the platform’s dispute resolution
                    system. The platform will mediate disputes, and unresolved
                    cases will proceed to arbitration under Bahraini law.
                  </Typography>
                </ListItem>
              </List>
            </ListItem>
            <ListItem>
              <Typography variant="body2">For Gold Cloud:</Typography>
              <List>
                <ListItem>
                  <Typography variant="body2">
                    Purchase & Save Precious Metals & Precious Stones: Consumers
                    may buy gold, silver, gemstones, or other precious materials
                    (or provide their own - All provided assets must be
                    certified and comply with the platform’s authenticity
                    verification) and store them securely within the Gold Cloud
                    system under an annual subscription plan.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Musharakah & Pool Agreements: Consumers may use their stored
                    precious metals and stones to enter Musharakah agreements
                    with jewelers/designers or pool agreements with Sooq
                    Althahab or third parties.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Withdrawal & Selling: Consumers may withdraw their stored
                    precious metals and stones or sell them within the
                    platform’s marketplace.
                  </Typography>
                </ListItem>
              </List>
            </ListItem>
          </List>
        </ListItem>

        <ListItem sx={{ "&.MuiListItem-root": { pl: "24px !important" } }}>
          <Typography variant="body1">
            <strong>Jewelers/Designers:</strong>
          </Typography>
          <List>
            <ListItem>
              <Typography variant="body2">
                Use the platform to find and enter Musharakah agreements with
                Savers to obtain precious metals and stones for jewelry
                production.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Use Musharakah materials solely for the agreed purposes,
                ensuring transparency and proper documentation of material
                usage.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Use the platform to find and contract Manufacturers for jewelry
                creation while maintaining clear records of designs, material
                consumption, and production progress.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">Use the marketplace to:</Typography>
              <List>
                <ListItem>
                  <Typography variant="body2">
                    List and sell original jewelry designs and finished
                    products.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Showcase design concepts for collaboration with potential
                    buyers.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Offer custom jewelry services while ensuring transparency
                    about pricing, materials, and expected delivery timelines.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Accurately describe products, avoiding misleading claims or
                    false advertising.
                  </Typography>
                </ListItem>
              </List>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Intellectual Property (IP) Compliance:
              </Typography>
              <List>
                <ListItem>
                  <Typography variant="body2">
                    Originality Requirement: Jewelers/Designers may only upload
                    and sell original designs that they own or have licensed
                    rights to.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    No Infringement: Users are strictly prohibited from copying,
                    reproducing, or selling patented, copyrighted, or
                    trademarked designs unless they have obtained proper
                    authorization.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Liability for IP Violations: Any user found infringing on
                    third-party intellectual property assumes full legal
                    responsibility for any resulting claims, damages, or
                    disputes.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Dispute Handling: If a copyright or patent dispute arises,
                    the platform reserves the right to remove the infringing
                    listing and take appropriate action, including account
                    suspension or legal reporting.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Maintain proper records and documentation of all
                    transactions, designs, and manufacturing processes to ensure
                    compliance with platform rules and industry regulations.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    If selling directly to customers, Jewelers/Designers must
                    comply with customer service, refund, and warranty policies
                    as stipulated by the platform.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Retain intellectual property rights over their original
                    jewelry designs unless otherwise agreed in writing.
                  </Typography>
                </ListItem>
              </List>
            </ListItem>
          </List>
        </ListItem>

        <ListItem sx={{ "&.MuiListItem-root": { pl: "24px !important" } }}>
          <Typography variant="body1">
            <strong>Manufacturers:</strong>
          </Typography>
          <List>
            <ListItem>
              <Typography variant="body2">
                Manufacturers are responsible for producing finished jewelry
                using materials and designs provided by Jewelers/Designers.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Manufacturers receive precious metals, precious stones, and
                design specifications from Jewelers/Designers and must use them
                exclusively for the intended production.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Manufacturers must provide accurate and competitive quotes for
                production requests and respond to quote inquiries from
                Jewelers/Designers in a timely manner.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Once a quote is provided and accepted, manufacturers must honor
                the original quote unless material costs or production
                requirements change significantly, in which case they must
                notify the Jeweler/Designer for re-evaluation.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                All finished products must meet industry quality standards, and
                manufacturers must ensure compliance with design specifications,
                material usage, and finishing requirements.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Manufacturers must adhere to agreed-upon deadlines for each
                production order and communicate any potential delays in
                advance.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Manufacturers must maintain accurate records of materials
                received, production progress, and final deliveries.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Any excess precious metals or stones that remain after
                production must be returned to the Jeweler/Designer, unless
                otherwise agreed in writing. Manufacturers are prohibited from
                using, selling, or repurposing excess materials for any other
                purpose.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                If a defect is found in the final product due to poor
                craftsmanship or material mismanagement, the Manufacturer must
                correct or replace the item within the agreed period at their
                own cost.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The finished jewelry must be delivered exclusively to the
                assigned recipient as specified by the platform, with no
                unauthorized third-party redirection or alternative deliveries.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Manufacturers must not reproduce or use any designs beyond the
                scope of their contractual obligations and must maintain
                confidentiality regarding design details and production methods.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Manufacturers must comply with industry regulations, safety
                standards, and legal requirements, ensuring ethical labor
                conditions and safe manufacturing practices.
              </Typography>
            </ListItem>
          </List>
        </ListItem>

        <ListItem sx={{ "&.MuiListItem-root": { pl: "24px !important" } }}>
          <Typography variant="body1">
            <strong>Precious Metal and Stone Sellers:</strong>
          </Typography>
          <List>
            <ListItem>
              <Typography variant="body2">
                Supply certified precious metals and precious stones to
                Consumers, Jewelers/Designers, and Manufacturers for jewelry
                production, storage, or resale.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Sellers must ensure that all materials provided meet the
                platforms certification and authenticity standards and comply
                with industry regulations, including anti-money laundering (AML)
                laws.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Sellers must respond to requests from Consumers,
                Jewelers/Designers, and Manufacturers in a timely and
                transparent manner, providing accurate pricing, quantity
                availability, and delivery timelines.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Once an order is accepted, sellers must honor the original price
                and agreed terms, except in cases where significant time and
                market fluctuations necessitate renegotiation, in which case
                prior approval must be obtained from the buyer.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Sellers must ensure that all transactions and materials comply
                with legal and industry standards, including sourcing from
                ethically responsible suppliers.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Any discrepancy in material quality, weight, or certification
                must be addressed immediately upon delivery, with sellers
                bearing full responsibility for rectifying any issues.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Sellers must provide detailed documentation, including invoices,
                certifications, and receipts for every transaction.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Sellers are strictly prohibited from misrepresenting material
                quality, falsifying certifications, or engaging in deceptive
                pricing practices.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Sellers must offer a buyback option, allowing Consumers,
                Jewelers/Designers, and Manufacturers to resell their precious
                metals and stones back to the seller at an agreed market rate,
                subject to quality inspection and verification.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                All deliveries must be made only to the assigned recipient as
                per the platforms instructions, ensuring that no orders are
                redirected to unauthorized third parties.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                If a dispute arises regarding the quality, quantity, or
                authenticity of the materials, the platform will facilitate
                mediation, and unresolved disputes will be escalated to
                arbitration under Bahraini law.
              </Typography>
            </ListItem>
          </List>
        </ListItem>
        <ListItem>
          <Typography variant="h6">Intellectual Property Rights</Typography>
        </ListItem>
        <ListItem>
          <List>
            <ListItem>
              <Typography variant="body2">
                Ownership of Designs: The ownership of jewelry designs,
                sketches, and creative concepts remains with the
                Jeweler/Designer unless explicitly transferred through a
                separate written agreement.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                License for Use: By listing a design or product on the platform,
                the Jeweler/Designer grants the platform a limited,
                non-exclusive license to use images, descriptions, and related
                content for marketing and promotional purposes.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Use of Non-Consumer Brand Information for Marketing: The
                platform reserves the right to use the names, logos, and
                branding materials of Jewelers, Manufacturers, and Precious
                Metal & Stone Sellers for the marketing and promotion of Sooq
                Althahab, provided that such use does not misrepresent their
                business activities or endorsements.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Protection of Proprietary Content: Unauthorized reproduction,
                copying, or modification of any designs, jewelry, trademarks,
                brand names, proprietary methods, or manufacturing techniques
                listed on the platform is strictly prohibited. Any user engaging
                in such unauthorized use may be subject to legal claims and
                penalties.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Intellectual Property Violations: If a user believes that their
                intellectual property rights have been infringed by another
                user, they may file a complaint with the platform. The platform
                reserves the right to suspend, remove, or restrict access to
                content that violates intellectual property laws and to take
                further action as required.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Manufacturer Confidentiality: Manufacturers are prohibited from
                reproducing, copying, or selling jewelry based on a
                Jeweler/Designer’s designs beyond the scope of their production
                agreement. They must maintain confidentiality regarding all
                designs and techniques received for manufacturing.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Precious Metal and Stone Authenticity: Sellers must ensure that
                any hallmarks, stamps, or certifications on precious metals and
                stones are authentic and not misleading or falsified.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Consumer Protection: Consumers may not replicate, modify, or
                redistribute purchased designs for commercial purposes without
                explicit permission from the original designer.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Platform Intellectual Property: The platform retains full rights
                over its proprietary algorithms, data analytics, content
                structure, and transaction facilitation tools, which may not be
                copied or reverse-engineered.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Unauthorized Use of Intellectual Property: Unauthorized copying,
                reproduction, modification, or distribution of designs,
                manufacturing methods, trademarks, or proprietary techniques
                listed on the platform is strictly prohibited. Any User found
                engaging in such violations may be subject to legal action and
                platform-imposed penalties. Users who suffer material or
                non-material damage due to unauthorized use of their
                intellectual property have the right to seek compensation in
                accordance with applicable laws. The platform reserves the right
                to take corrective measures, including removing infringing
                content, suspending accounts, and cooperating with legal
                enforcement authorities.
              </Typography>
            </ListItem>
          </List>
        </ListItem>

        <ListItem>
          <Typography variant="h6">Fees, Payments, and Refunds</Typography>
        </ListItem>
        <ListItem>
          <List>
            <ListItem>
              <Typography variant="body2">
                Users must pay all applicable subscription fees, transaction
                fees, and service charges as specified in the platform’s pricing
                schedule.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Subscription fees are non-refundable.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Additional fees may apply for specific services, such as premium
                listings, expedited processing, or enhanced security features,
                which will be communicated transparently before purchase.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Users agree to process all payments through the platform’s
                designated payment options, ensuring compliance with regulatory
                and security standards.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Any dispute over fees or payments must be reported within 14
                days of the transaction. The platform reserves the right to
                review and resolve such disputes at its discretion.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                If a payment is not received or a chargeback is initiated, the
                platform reserves the right to suspend or terminate the user’s
                account until the outstanding balance is settled.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                In cases of service disruptions or platform downtime, the
                platform is not obligated to issue refunds unless the disruption
                exceeds a specified threshold where then case-by-case basis at
                the platform’s sole discretion. Users who subscribe to the
                platform’s Gold Cloud system must maintain active subscriptions,
                and failure to renew may result in penalties, storage fees, or
                limitations on asset withdrawal as per the storage agreement.
              </Typography>
            </ListItem>
          </List>
        </ListItem>

        <ListItem>
          <Typography variant="h6">No Returns Policy</Typography>
        </ListItem>
        <ListItem>
          <List>
            <ListItem>
              <Typography variant="body2">
                Scope & Applicability: This clause applies to all Products
                (gold, jewelry) and any Sooq Al Thahab Services (e.g.,
                subscriptions, platform usage, white-label integrations). By
                purchasing any Product or Service, you acknowledge and agree to
                the terms in Clause 6 of these Terms & Conditions.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                All Sales Final (Gold & Jewelry): Once a purchase is confirmed
                for physical gold or jewelry, the transaction cannot be canceled
                or reversed. We do not accept returns, exchanges, or provide
                refunds for gold or jewelry unless required by applicable law
                (e.g., misrepresentation or defective items under certain
                consumer protection regulations).
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Gold Price Volatility: Your purchase price is locked in at
                checkout due to global market fluctuations, making refunds
                impractical.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Non-Refundable Services (Sooq Al Thahab): Any fees or
                subscriptions paid for Sooq Al Thahab Services—including, but
                not limited to, platform usage and white-label solutions—are
                strictly non-refundable. No partial or prorated refunds will be
                issued if a subscription or service is terminated before its
                scheduled end, unless explicitly stated otherwise in a separate
                written agreement.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Shipping & Insurance: Physical gold and jewelry are shipped via
                secure or insured methods, depending on the shipping option
                selected. If a shipment arrives damaged or tampered with, you
                must notify us immediately so we can assist in filing a claim
                with the carrier or insurer. Notifying us of damage does not
                constitute a right to return the item or request a refund.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Misrepresentation or Vendor Disputes: If you believe a jewelry
                item is significantly misrepresented (e.g., incorrect metal
                purity, missing stones) compared to the listing, please provide
                documentation (e.g., photos, certificates) to our support team.
                We will attempt to mediate a resolution with the vendor.
                However, a refund or return is not guaranteed unless legally
                mandated. Vendor-specific warranties (if any) are described in
                product listings and do not override this no-returns policy.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Legal Compliance & Exceptions: We comply with all applicable
                consumer protection and trade laws. If your jurisdiction
                mandates specific return or refund rights for defective or
                misrepresented goods, we will fulfill those legal obligations.
                Outside of those legally mandated exceptions, all sales are
                final, and no refunds will be offered.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Acknowledgment & Acceptance: By purchasing Products or using any
                Sooq Al Thahab Services, you acknowledge that you have read,
                understood, and agree to this No Returns & No Refunds clause. It
                is the customer’s sole responsibility to confirm all order
                details (including but not limited to product specifications,
                purity, weight, and any other relevant information) before
                finalizing the purchase. Once a purchase is completed, no
                changes, returns, or refunds will be granted unless legally
                mandated.
              </Typography>
            </ListItem>
          </List>
        </ListItem>

        <ListItem>
          <Typography variant="h6">Confidentiality and Data Privacy</Typography>
        </ListItem>
        <ListItem>
          <List>
            <ListItem>
              <Typography variant="body2">
                Users agree to maintain the confidentiality of all transaction
                details, agreements, designs, pricing, proprietary information,
                and any other sensitive data obtained through the platform.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The platform is committed to protecting user data and complies
                with applicable data protection laws, including Bahrain’s
                Personal Data Protection Law (PDPL) and the General Data
                Protection Regulation (GDPR), where applicable.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Users consent to the collection, storage, and processing of
                their data for purposes related to transaction processing,
                dispute resolution, compliance with legal and regulatory
                obligations, and platform improvements.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The platform does not sell, trade, or share personal or business
                data with third parties for marketing purposes without explicit
                user consent.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Users agree to the following confidentiality obligations:
              </Typography>
              <List>
                <ListItem>
                  <Typography variant="body2">
                    Confidential Information: Users acknowledge that
                    confidential information includes but is not limited to
                    business processes, pricing structures, trade secrets,
                    design details, customer data, transaction records, and any
                    non-public platform-related information.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Non-Disclosure: Users shall not disclose, share, reproduce,
                    or use confidential information outside of its intended
                    purpose or beyond what is permitted by the platform.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Limited Access: Users shall ensure that confidential
                    information is only accessible to authorized individuals and
                    that reasonable precautions are taken to prevent
                    unauthorized access.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Duration of Confidentiality: Users agree that
                    confidentiality obligations shall remain in effect during
                    their engagement with the platform and continue beyond
                    account termination for a specified period as determined by
                    the platform.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Permitted Disclosures: Confidential information may only be
                    disclosed if legally required (e.g., government or court
                    order) or with explicit written consent from the disclosing
                    party.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Intellectual Property Protection: Users shall not copy,
                    modify, or misuse designs, proprietary methods, trade
                    secrets, or any intellectual property shared within the
                    platform.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Consequences of Breach: Any unauthorized disclosure or
                    misuse of confidential information may result in account
                    suspension, legal action, financial penalties, and liability
                    for damages.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    If a user is found to have improperly disclosed confidential
                    information, the platform reserves the right to take legal
                    action, suspend the user’s account, and seek compensation
                    for damages.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    The platform employs industry-standard security measures to
                    safeguard user data but cannot guarantee complete protection
                    against cyber threats. Users are encouraged to use strong
                    authentication methods and report any security breaches
                    immediately.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    In the event of a data breach affecting user information,
                    the platform will notify affected users in accordance with
                    applicable legal requirements.
                  </Typography>
                </ListItem>
              </List>
            </ListItem>
          </List>
        </ListItem>

        <ListItem>
          <Typography variant="h6">Dispute Resolution</Typography>
        </ListItem>
        <ListItem>
          <List>
            <ListItem>
              <Typography variant="body2">
                Users agree to first attempt to resolve any disputes through
                direct negotiation with the involved party before escalating the
                matter to the platform.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                If direct negotiation fails, users must submit the dispute to
                the platform for internal mediation, where the platform will
                facilitate discussions and propose a resolution within 30 days
                of receiving the dispute request.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                If mediation does not result in a resolution, disputes will be
                referred to binding arbitration under Bahraini law.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The arbitration process will be conducted by a neutral
                arbitrator appointed by the platform or an agreed third-party
                arbitration service, and the decision will be final and legally
                binding on all parties.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Users waive their right to file a lawsuit in any court
                jurisdiction unless required by law, and they agree that
                arbitration shall be the exclusive method of resolving disputes
                related to the platform, services, or agreements.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The costs of arbitration shall be borne by the losing party,
                unless otherwise decided by the arbitrator.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Claims of intellectual property infringement, fraud, or
                violations of confidentiality may be pursued through legal
                action without requiring arbitration.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The platform reserves the right to suspend, restrict, or
                terminate any user account if a dispute arises regarding
                compliance with these Terms and Conditions.
              </Typography>
            </ListItem>
          </List>
        </ListItem>
        <ListItem>
          <Typography variant="h6">Regulatory Compliance</Typography>
        </ListItem>
        <ListItem>
          <List>
            <ListItem>
              <Typography variant="body2">
                Users must provide accurate and complete information during
                registration and when conducting transactions on the platform to
                ensure compliance with legal and regulatory requirements.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                All users must comply with the Kingdom of Bahrain’s laws and
                regulations, including but not limited to:
              </Typography>
              <List>
                <ListItem>
                  <Typography variant="body2">
                    Anti-Money Laundering (AML) and Counter-Financing of
                    Terrorism (CFT) regulations.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Personal Data Protection Law (PDPL) and other applicable
                    data privacy laws.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Trade and financial regulations for the sale, purchase, and
                    transfer of precious metals and stones.
                  </Typography>
                </ListItem>
              </List>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Users may be required to undergo Know Your Customer (KYC) and
                Know Your Business (KYB) verification, including identity and
                business validation, prior to transacting on the platform.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The platform reserves the right to suspend or terminate user
                accounts that fail to meet regulatory requirements or provide
                false, misleading, or incomplete information.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                All transactions must comply with local and international trade
                and financial laws, and users must ensure that their funds and
                assets do not originate from illegal activities.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The platform may report suspicious activities to relevant
                regulatory authorities without prior notice to the user if such
                activities raise concerns regarding financial crimes or
                violations of applicable laws.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Users must ensure that all precious metals and stones sold,
                purchased, or stored through the platform are properly
                certified, legally sourced, and in compliance with trade
                regulations.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The platform is not liable for legal violations committed by
                users, and users assume full responsibility for ensuring their
                compliance with applicable laws.
              </Typography>
            </ListItem>
          </List>
        </ListItem>

        <ListItem>
          <Typography variant="h6">Liability and Indemnification</Typography>
        </ListItem>
        <ListItem>
          <List>
            <ListItem>
              <Typography variant="body2">
                The platform provides its services on an as-is and as-available
                basis and does not guarantee uninterrupted service, error-free
                functionality, or specific business outcomes.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The platform is not liable for:
              </Typography>
              <List>
                <ListItem>
                  <Typography variant="body2">
                    Losses arising from user disputes related to transactions,
                    agreements, or services.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Defective, fraudulent, or misrepresented materials or
                    products supplied by users.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Delays, disruptions, or failures caused by third parties,
                    service providers, or unforeseen circumstances.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Financial losses, reputational damage, or indirect damages
                    resulting from errors, omissions, or misuse of the platform.
                  </Typography>
                </ListItem>
              </List>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Users agree to indemnify and hold the platform harmless from any
                claims, damages, losses, legal fees, or liabilities resulting
                from:
              </Typography>
              <List>
                <ListItem>
                  <Typography variant="body2">
                    Non-compliance with these Terms and Conditions or applicable
                    laws.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Violations of intellectual property rights, privacy laws, or
                    confidentiality agreements.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Fraudulent transactions, misrepresentation, or disputes with
                    other users.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Any legal actions taken against the platform due to the
                    user’s actions or omissions.
                  </Typography>
                </ListItem>
              </List>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                In cases where legal or regulatory action is taken against the
                platform due to a users violation of the law, the platform
                reserves the right to recover financial damages, legal costs,
                and additional penalties from the responsible user.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The platforms total liability, if any, shall be limited to the
                amount of fees paid by the user in the last three (3) months
                prior to the claim, except in cases of fraud or intentional
                misconduct by the platform.
              </Typography>
            </ListItem>
          </List>
        </ListItem>

        <ListItem>
          <Typography variant="h6">
            Termination and Account Suspension
          </Typography>
        </ListItem>
        <ListItem>
          <List>
            <ListItem>
              <Typography variant="body2">
                The platform reserves the right to suspend or terminate any user
                account at its sole discretion if a user violates these Terms
                and Conditions, regulatory requirements, or engages in
                fraudulent or illegal activities.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Users will be notified of the reason for suspension or
                termination and may submit an appeal within 14 days of receiving
                the notification.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                A user’s account may be suspended or terminated for reasons
                including, but not limited to:
              </Typography>
              <List>
                <ListItem>
                  <Typography variant="body2">
                    Failure to comply with regulatory requirements such as AML,
                    CFT, KYC, and KYB verification.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Misrepresentation or fraud in transactions, pricing, or
                    product descriptions.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Breach of confidentiality, intellectual property rights, or
                    privacy laws.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Failure to pay outstanding fees, penalties, or charges owed
                    to the platform.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Repeated disputes or unresolved claims filed by other users.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Engaging in unethical, deceptive, or harmful business
                    practices.
                  </Typography>
                </ListItem>
              </List>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Users remain responsible for any outstanding financial
                obligations incurred before the termination or suspension of
                their account.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                If an account is terminated, the platform may:
              </Typography>
              <List>
                <ListItem>
                  <Typography variant="body2">
                    Restrict access to stored data, ongoing transactions, or
                    financial records.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Withhold pending payments until disputes or outstanding
                    charges are resolved.
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Take legal action against users found to have engaged in
                    serious violations.
                  </Typography>
                </ListItem>
              </List>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The platform reserves the right to retain user data for a
                reasonable period as required by law, even after account
                termination.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Users may request voluntary account termination, but they must
                settle any active agreements, pending transactions, or financial
                obligations before the request is processed.
              </Typography>
            </ListItem>
          </List>
        </ListItem>

        <ListItem>
          <Typography variant="h6">Force Majeure</Typography>
        </ListItem>
        <ListItem>
          <List>
            <ListItem>
              <Typography variant="body2">
                No party shall be liable or deemed to have defaulted under or
                breached this Agreement for any failure or delay in fulfilling
                or performing any obligation (except for payment obligations)
                when such failure or delay is caused by events beyond the
                impacted party’s (“Impacted Party”) reasonable control,
                including but not limited to the following Force Majeure Events:
              </Typography>
              <List>
                <ListItem>
                  <Typography variant="body2">Acts of God;</Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Natural disasters including fires, explosions, earthquakes,
                    hurricanes, flooding, storms, infestations, fog, or extreme
                    weather conditions;
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Epidemics or pandemics;
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    War, invasion, hostilities (whether war is declared or not),
                    terrorist threats or acts, riots, or other civil unrest;
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Government orders, laws, or regulations;
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Embargoes, blockades, or trade restrictions in effect on or
                    after the date of this Agreement;
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Actions by any governmental authority that directly impact
                    the performance of obligations;
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    National or regional emergencies;
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Strikes, labor stoppages, slowdowns, or other industrial
                    disturbances;
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Loss or malfunction of utilities, transportation, or
                    critical infrastructure, including power outages, internet
                    failures, or cyberattacks;
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    Illegal acts by individuals or crowds that disrupt
                    operations or the execution of contractual obligations;
                  </Typography>
                </ListItem>
                <ListItem>
                  <Typography variant="body2">
                    IT and hardware outages affecting the platforms operations,
                    including failures in cloud infrastructure, data center
                    malfunctions, cybersecurity breaches, or disruptions in
                    third-party IT service providers.
                  </Typography>
                </ListItem>
              </List>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The Impacted Party shall provide written notice to the other
                party within one (1) day of the Force Majeure Event, specifying
                the expected duration, its impact, and any mitigating actions
                being taken.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The Impacted Party shall make reasonable efforts to reduce the
                effects of the Force Majeure Event and resume the performance of
                its obligations as soon as reasonably possible after the event
                is resolved.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                If the Force Majeure Event continues for more than 30
                consecutive days, either party may terminate the affected
                agreement(s) without penalty.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The platform reserves the right to suspend or modify its
                services in response to a Force Majeure Event if necessary to
                ensure security, compliance, or operational stability.
              </Typography>
            </ListItem>
          </List>
        </ListItem>

        <ListItem>
          <Typography variant="h6">Amendments</Typography>
        </ListItem>
        <ListItem>
          <List>
            <ListItem>
              <Typography variant="body2">
                The platform reserves the right to modify, update, or amend
                these Terms and Conditions at any time, provided that users are
                given prior notice of any material changes.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Users will be notified of amendments through email, platform
                notifications, or an official announcement on the platform’s
                website at least [X] days before the changes take effect.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Continued use of the platform after the effective date of any
                amendments constitutes acceptance of the revised Terms and
                Conditions.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                If a user does not agree with the proposed amendments, they may
                terminate their account or request a review within the notice
                period.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Any amendments required by law, regulation, or security policies
                may take effect immediately, without prior notice.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The platform is not responsible for a user’s failure to review
                amended terms, and it is the user’s responsibility to stay
                updated on the latest Terms and Conditions.
              </Typography>
            </ListItem>
          </List>
        </ListItem>

        <ListItem>
          <Typography variant="h6">Governing Law</Typography>
        </ListItem>
        <ListItem>
          <List>
            <ListItem>
              <Typography variant="body2">
                These Terms and Conditions, along with any disputes arising from
                or related to the platform, shall be governed by and construed
                in accordance with the laws of the Kingdom of Bahrain.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Any disputes that cannot be resolved through negotiation or
                arbitration shall be subject to the exclusive jurisdiction of
                the courts of the Kingdom of Bahrain.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                Users agree to waive any objections to jurisdiction, venue, or
                inconvenient forum with respect to legal proceedings initiated
                in Bahrain.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                If any provision of these Terms and Conditions is found to be
                unenforceable or invalid under Bahraini law, the remaining
                provisions shall continue to be fully enforceable.
              </Typography>
            </ListItem>
            <ListItem>
              <Typography variant="body2">
                The platform reserves the right to comply with local, regional,
                and international laws and regulations, including those related
                to financial transactions, data protection, and consumer rights.
              </Typography>
            </ListItem>
          </List>
        </ListItem>
      </List>
    </Box>
  );
};

export default TermsAndConditions;
