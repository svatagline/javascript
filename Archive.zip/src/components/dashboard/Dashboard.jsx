import { ADMIN_ROLES, USER_ROLES } from "../../constants";
import useI18N from "../../hooks/useI18N";
import SAStack from "../../shared/SAStack";
import SATypography from "../../shared/SATypography";
import { decodeToken, isAdmin } from "../../utils/functions";

const Dashboard = () => {
  const { t } = useI18N();
  const { role } = decodeToken();

  return (
    <SAStack alignItems="center" justifyContent="center">
      <SATypography variant="h6">
        {t(isAdmin() ? ADMIN_ROLES[role] : USER_ROLES[role])}
      </SATypography>
    </SAStack>
  );
};

export default Dashboard;
