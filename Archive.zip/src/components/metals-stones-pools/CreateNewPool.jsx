import { useState } from "react";

import useI18N from "../../hooks/useI18N";
import SAButton from "../../shared/SAButton";

const CreateNewPool = () => {
  const { t } = useI18N();

  const [setPoolModal] = useState(false);

  return (
    <SAButton
      color="primary"
      variant="contained"
      onClick={() => setPoolModal(true)}
    >
      {t("create-new-pool")}
    </SAButton>
  );
};

export default CreateNewPool;
