import { Box, Divider, Grid } from "@mui/material";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import { loaderPath } from "../../descriptions/metalStonePools.description";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import { MUIStyled } from "../../shared/MUIStyled";
import SABox from "../../shared/SABox";
import SACard from "../../shared/SACard";
import SALoader from "../../shared/SALoader";
import SAStack from "../../shared/SAStack";
import SAStatusBadge from "../../shared/SAStatusBadge";
import SATypography from "../../shared/SATypography";
import { formatTimestamp } from "../../utils/functions";

const LoaderWrapper = MUIStyled(SABox)({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
});

const Row = MUIStyled(SABox)({
  gap: "12px",
  display: "flex",
  alignItems: "center",
  backgroundColor: "#f9fafb",
  padding: "8px 12px",
  borderRadius: "8px",
  marginBottom: "8px",
});

const StyledLabel = MUIStyled(SATypography)({
  color: "#6B7280",
  fontSize: "0.875rem",
  fontWeight: 500,
  whiteSpace: "nowrap",
});

const PoolsDetails = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const { poolId } = useParams();

  const [poolDetails, setPoolDetails] = useState({});

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.metalsStonesPoolsDetails],
  );

  useEffect(() => {
    getPoolDetails();
  }, [poolId]);

  const getPoolDetails = async () => {
    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints.getPools}${poolId}/`,
      needLoader: true,
      loader: loaderPath.metalsStonesPoolsDetails,
      showToastOnError: true,
    });

    if (response?.status) setPoolDetails(response?.data);
  };

  const breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: "metals-stones-pools", href: "/metals-stones-pools" },
    { label: poolDetails?.name || poolId, noTranslate: true },
  ];

  const {
    name,
    status,
    material_type,
    material_item,
    cut_shape,
    carat_type,
    target,
    risk_level,
    expected_return_percentage,
    actual_return_percentage,
    return_amount,
    created_at,
    closes_on,
  } = poolDetails || {};

  const TableRow = ({ label, value }) => (
    <Row>
      <StyledLabel variant="body2">{`${t(label)}:`}</StyledLabel>
      <Box sx={{ textAlign: "right", whiteSpace: "nowrap", ml: 1 }}>
        {["string", "number"].includes(typeof value) ? (
          <SATypography
            sx={{ color: "#111827", fontSize: "0.875rem", fontWeight: 500 }}
          >
            {value}
          </SATypography>
        ) : (
          value || "-"
        )}
      </Box>
    </Row>
  );

  return (
    <SABox>
      <SAStack mb={3}>
        <MUIBreadcrumbs breadcrumbsData={breadcrumbsData} />
      </SAStack>
      {loading ? (
        <SABox
          sx={{
            flexGrow: 1,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <LoaderWrapper>
            <SALoader />
          </LoaderWrapper>
        </SABox>
      ) : (
        <SACard>
          <SABox
            sx={{
              mb: 2,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <SATypography variant="h5" fontWeight={600}>
              {name}
            </SATypography>
            <SAStatusBadge status={status} />
          </SABox>
          <Divider sx={{ mb: 2 }} />
          <Grid container spacing={4}>
            <Grid item xs={12} md={6}>
              <SATypography
                variant="subtitle1"
                fontSize={15}
                fontWeight={550}
                gutterBottom
              >
                {t("material-details")}
              </SATypography>
              <TableRow
                label="material-type"
                value={<SAStatusBadge status={material_type?.toUpperCase()} />}
              />
              <TableRow label="material-item" value={material_item} />
              <TableRow label="cut-shape" value={cut_shape} />
              <TableRow label="carat-type" value={carat_type} />
            </Grid>
            <Grid item xs={12} md={6}>
              <SATypography
                variant="subtitle1"
                fontSize={15}
                fontWeight={500}
                gutterBottom
              >
                {t("investment-details")}
              </SATypography>
              <TableRow label="target" value={`${target} kg`} />
              <TableRow
                label="risk-level"
                value={<SAStatusBadge status={risk_level} />}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <SATypography
                variant="subtitle1"
                fontSize={15}
                fontWeight={600}
                gutterBottom
              >
                {t("return-details")}
              </SATypography>
              <TableRow
                label="expected-return-percentage"
                value={expected_return_percentage || "-"}
              />
              <TableRow
                label="actual-return-percentage"
                value={actual_return_percentage || "-"}
              />
              <TableRow label="return-amount" value={return_amount} />
            </Grid>
            <Grid item xs={12} md={6}>
              <SATypography
                variant="subtitle1"
                fontSize={15}
                fontWeight={600}
                gutterBottom
              >
                {t("timeline")}
              </SATypography>
              <TableRow
                label="created-at"
                value={created_at ? formatTimestamp(created_at) : "-"}
              />
              <TableRow
                label="closes-on"
                value={closes_on ? formatTimestamp(closes_on) : "-"}
              />
            </Grid>
          </Grid>
        </SACard>
      )}
    </SABox>
  );
};

export default PoolsDetails;
