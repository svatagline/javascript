import HttpsOutlinedIcon from "@mui/icons-material/HttpsOutlined";
import LockOpenOutlinedIcon from "@mui/icons-material/LockOpenOutlined";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import { TABLE_RECORD_PER_PAGE } from "../../constants";
import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  loaderPath,
  poolsTableColumns,
} from "../../descriptions/metalStonePools.description";
import useAPI from "../../hooks/useAPI";
import useDebounce from "../../hooks/useDebounce";
import useI18N from "../../hooks/useI18N";
import usePagination from "../../hooks/usePagination";
import {
  addPools,
  isRefreshList,
} from "../../redux/slices/metalsStonesPools.slices";
import { Eye } from "../../shared/icon";
import SABasicTable from "../../shared/SABasicTable";
import SAButton from "../../shared/SAButton";
import SAStatusBadge from "../../shared/SAStatusBadge";
import SATruncateWithEllipsis from "../../shared/SATruncateWithEllipsis";
import SATypography from "../../shared/SATypography";
import {
  convertDatesToTimestampsInObject,
  excludeKeys,
  formatTimestamp,
  validTableValue,
} from "../../utils/functions";
import PoolsStatusModal from "./PoolsStatusModal";

const PoolsTable = ({ searchTerm, submitFilterData }) => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const pools = useSelector((state) => state.metalsStonesPools?.pools);
  const refreshList = useSelector(
    (state) => state.metalsStonesPools?.refreshList,
  );
  const loading = useSelector((state) => ({
    metalsStonesPools: state.loader?.[loaderPath.metalsStonesPools],
    closePool: state.loader?.[loaderPath.closePool],
  }));

  const { count, results: poolsData } = pools || {};

  const {
    totalPage,
    currentPage,
    itemPerPage,
    setCurrentPage,
    setItemPerPage,
  } = usePagination(count, TABLE_RECORD_PER_PAGE);

  const [selectedPool, setSelectedPool] = useState(null);

  const debouncedSearch = useDebounce(searchTerm, 300, () => {
    setCurrentPage(1);
  });

  const handleView = (id) => navigate(`/metals-stones-pools/${id}`);
  const handleAction = (data) => setSelectedPool(data);

  const handleClosePool = async () => {
    if (!selectedPool) return;
    const { status, id } = selectedPool || {};

    const response = await api({
      method: httpMethods.patch,
      endPoint: `${apiEndpoints.getPools}${id}/`,
      data: { status: status?.toUpperCase() === "OPEN" ? "CLOSED" : "OPEN" },
      needLoader: true,
      loader: loaderPath.closePool,
      showToastMessage: true,
    });

    if (response?.status) {
      callPoolsAPI();
      setSelectedPool(null);
    }
  };

  const callPoolsAPI = async () => {
    const statusParams = submitFilterData?.status?.length
      ? [`status=${submitFilterData.status}`]
      : [];
    const materialTypeParams = submitFilterData?.material_type
      ? [`material_type=${submitFilterData.material_type}`]
      : [];

    const params = [...statusParams, ...materialTypeParams];
    const paramsString = params.length ? `?${params.join("&")}` : "";

    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints.getPools}${paramsString}`,
      needLoader: true,
      loader: loaderPath.metalsStonesPools,
      showToastOnError: true,
      params: {
        page: currentPage,
        page_size: itemPerPage,
        name: searchTerm,
        // ordering: sort.sortType === "2" ? `-${sort.field}` : sort.field,
        ...convertDatesToTimestampsInObject(
          excludeKeys(submitFilterData, ["status", "material_type"]),
          [
            "created_at_min",
            "created_at_max",
            "closes_on_min",
            "closes_on_max",
          ],
        ),
      },
    });

    if (response?.status) dispatch(addPools({ data: response?.data }));
  };

  useEffect(() => {
    callPoolsAPI();
  }, [currentPage, itemPerPage, debouncedSearch, submitFilterData]);

  useEffect(() => {
    if (refreshList) {
      setCurrentPage(1);
      callPoolsAPI();
      dispatch(isRefreshList(false));
    }
  }, [refreshList]);

  const paginationProps = {
    currentPage,
    setItemPerPage,
    setCurrentPage,
    page: totalPage,
    rowsPerPage: itemPerPage,
  };

  const renderCell = (columnKey, data, _, value) => {
    switch (columnKey) {
      case "name":
        return (
          <SATypography sx={{ fontWeight: 550, fontSize: 14 }}>
            <SATruncateWithEllipsis text={value} maxLength={25} />
          </SATypography>
        );

      case "material_type":
      case "status":
      case "risk_level":
        return <SAStatusBadge status={validTableValue(value?.toUpperCase())} />;

      case "target":
        return (
          <SATypography sx={{ fontWeight: 600, fontSize: 14 }}>
            {`${validTableValue(value)} kg`}
          </SATypography>
        );

      case "expected_return_percentage":
        return (
          <SATypography sx={{ fontWeight: 600, fontSize: 14 }}>
            {validTableValue(value)}
          </SATypography>
        );

      case "created_at":
        return (
          <SATypography
            variant="body2"
            fontWeight={500}
            sx={{
              padding: "4px 8px",
              borderRadius: "6px",
              backgroundColor: "#F3F4F6",
              color: "#374151",
              display: "inline-block",
              fontSize: "0.875rem",
            }}
          >
            {formatTimestamp(value)}
          </SATypography>
        );

      case "view":
        return (
          <SAButton
            size="small"
            variant="outlined"
            onClick={() => handleView(data?.id)}
            sx={{
              px: 2,
              gap: 0.5,
              borderRadius: 2,
              color: "grey.700",
              textTransform: "none",
              borderColor: "grey.400",
              "&:hover": {
                borderColor: "grey.600",
                backgroundColor: "grey.100",
              },
            }}
          >
            {t("view")} <Eye />
          </SAButton>
        );

      case "action":
        return (
          <SAButton
            size="small"
            variant="outlined"
            onClick={() => handleAction(data)}
            sx={{
              px: 2,
              gap: 0.5,
              borderRadius: 2,
              color:
                data?.status?.toUpperCase() === "OPEN" ? "#B42318" : "grey.700",
              textTransform: "none",
              borderColor:
                data?.status?.toUpperCase() === "OPEN" ? "#B42318" : "grey.400",
            }}
          >
            {t(
              `${data?.status?.toUpperCase() === "OPEN" ? "close" : "reopen"}-the-pool`,
            )}
            {data?.status?.toUpperCase() === "OPEN" ? (
              <HttpsOutlinedIcon sx={{ height: 18, width: 18 }} />
            ) : (
              <LockOpenOutlinedIcon sx={{ height: 18, width: 18 }} />
            )}
          </SAButton>
        );

      default:
        return (
          <SATypography variant="body2">{validTableValue(value)}</SATypography>
        );
    }
  };

  return (
    <>
      <SABasicTable
        {...{
          loading: loading.metalsStonesPools,
          data: poolsData,
          columns: poolsTableColumns,
          renderCell,
          paginationProps,
          colSpan: 5,
        }}
      />
      <PoolsStatusModal
        open={!!selectedPool}
        loading={loading.closePool}
        onClose={() => setSelectedPool(null)}
        onSuccess={handleClosePool}
        isOpen={selectedPool?.status?.toUpperCase() === "OPEN"}
      />
    </>
  );
};

export default PoolsTable;
