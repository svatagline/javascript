import useI18N from "../../hooks/useI18N";
import MUIModal from "../../shared/MUIModal";
import SABox from "../../shared/SABox";
import SAButton from "../../shared/SAButton";
import SAStack from "../../shared/SAStack";
import SATypography from "../../shared/SATypography";

const PoolsStatusModal = ({ open, onClose, onSuccess, loading, isOpen }) => {
  const { t } = useI18N();

  return (
    <MUIModal
      open={open}
      maxWidth="xs"
      handleClose={onClose}
      title={t("pool-status-confirmation")}
      titleSx={{ textAlign: "center" }}
      content={
        <SABox p={2}>
          <SATypography variant="body1" textAlign="center">
            {t(
              isOpen
                ? "are-you-sure-you-want-to-close-the-pool"
                : "are-you-sure-you-want-to-reopen-the-pool",
            )}
          </SATypography>
          <SAStack direction="row" mt={3} justifyContent="center" gap={2}>
            <SAButton variant="outlined" color="primary" onClick={onClose}>
              {t("cancel")}
            </SAButton>
            <SAButton
              type="submit"
              color="primary"
              variant="contained"
              onClick={onSuccess}
              loading={loading}
            >
              {t(isOpen ? "close-the-pool" : "reopen-the-pool")}
            </SAButton>
          </SAStack>
        </SABox>
      }
    />
  );
};

export default PoolsStatusModal;
