import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Outlet, useParams } from "react-router-dom";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  filterDefaultValues,
  filterFormFields,
  loaderPath,
} from "../../descriptions/metalStonePools.description";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import { Search } from "../../shared/icon";
import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import { MUIStyled } from "../../shared/MUIStyled";
import SABox from "../../shared/SABox";
import SACard from "../../shared/SACard";
import SAFilterMenu from "../../shared/SAFilterMenu";
import SAStack from "../../shared/SAStack";
import SATextField from "../../shared/SATextField";
import theme from "../../themes/theme";
import { compareAmounts, compareDates } from "../../utils/functions";
import showToast from "../../utils/toast";
import AddPool from "./AddPools";
import PoolsTable from "./PoolsTable";

const SearchWrapper = MUIStyled(SAStack)({ width: "100%", maxWidth: 400 });

const MetalsStonesPools = () => {
  const { t } = useI18N();
  const { poolId } = useParams();
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const [filterData, setFilterData] = useState({
    ...filterDefaultValues,
  });
  const [submitFilterData, setSubmitFilterData] = useState({});
  const { api } = useAPI();
  const [preciousItemAttributes, setPreciousItemAttributes] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  const getPreciousItemAttributes = async () => {
    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints?.preciousItemAttributes}`,
      needLoader: true,
      loader: loaderPath.getPreciousItemAttributes,
      showToastOnError: true,
    });
    if (response?.status) {
      setPreciousItemAttributes(response?.data);
    } else {
      setPreciousItemAttributes([]);
    }
  };

  const {
    register,
    handleSubmit,
    formState,
    control,
    reset,
    getValues,
    watch,
    setValue,
  } = useForm({
    mode: "onChange",
    defaultValues: filterData,
  });
  const watchFields = watch();

  useEffect(() => {
    const fetchData = async () => {
      await getPreciousItemAttributes();
    };
    fetchData();
  }, []);

  useEffect(() => {
    if (open) {
      Object.keys(filterData).forEach((i) => {
        setValue(i, filterData[i]);
      });
    }
  }, [open]);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: "metals-stones-pools" },
  ];

  const handleFilterSubmit = (formData) => {
    try {
      const {
        target__min,
        target__max,
        expected_return__max,
        expected_return__min,
        created_at__min,
        created_at__max,
        closes_at__min,
        closes_at__max,
      } = formData;

      const compareFields = (type, fields) => {
        const comparator = type === "amount" ? compareAmounts : compareDates;
        comparator(fields);
      };

      const validations = [
        {
          type: "amount",
          fields: {
            min_amount: target__min,
            max_amount: target__max,
            min_amount_field: "Target Min",
            max_amount_field: "Target Max",
            errorMessage: "target-min-less-than-target-max",
          },
        },
        {
          type: "amount",
          fields: {
            min_amount: expected_return__min,
            max_amount: expected_return__max,
            min_amount_field: "Expected Return Min Percentage",
            max_amount_field: "Expected Return Max Percentage",
            errorMessage: "expected-return-min-less-than-return-max",
          },
        },
        {
          type: "date",
          fields: {
            start_date: created_at__min,
            end_date: created_at__max,
            start_date_field: "Min Created Date",
            end_date_field: "Max Created Date",
            errorMessage: "min-created-less-than-created-max",
          },
        },
        {
          type: "date",
          fields: {
            start_date: closes_at__min,
            end_date: closes_at__max,
            start_date_field: "Min Closes Date",
            end_date_field: "Max Closes Date",
            errorMessage: "min-closes-less-than-closes-max",
          },
        },
      ];

      validations.forEach(({ type, fields }) => compareFields(type, fields));
      setSubmitFilterData(formData);
      handleClose();
    } catch (error) {
      showToast(error);
    }
  };

  if (poolId) return <Outlet />;
  const primaryActionStyle = {
    sx: { "& svg": { ml: 1 } },
  };

  const useFormControls = {
    register,
    handleSubmit,
    formState,
    control,
    reset,
    getValues,
    watchFields,
  };

  return (
    <>
      <SAStack
        mb={3}
        direction="row"
        alignItems="center"
        justifyContent="space-between"
      >
        <SAStack>
          <MUIBreadcrumbs {...{ breadcrumbsData }} />
        </SAStack>
      </SAStack>
      <SACard>
        <SAStack
          pb={2}
          mb={2}
          gap={3}
          direction="row"
          flexWrap="wrap"
          alignItems="center"
          justifyContent="space-between"
          borderBottom={`1px solid ${theme.palette.gray.main}50`}
        >
          <SearchWrapper>
            <SATextField
              value={searchTerm}
              placeholder={t("search-for-pools")}
              InputProps={{ startAdornment: <Search /> }}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </SearchWrapper>
          <SABox sx={{ display: "flex", gap: "10px" }}>
            <SAFilterMenu
              t={t}
              anchorEl={anchorEl}
              open={open}
              handleClose={handleClose}
              onSubmit={handleFilterSubmit}
              slotProps={{ paper: { sx: { p: 2 } } }}
              handleClick={handleClick}
              useFormControls={useFormControls}
              setFilterData={setFilterData}
              defaultFilterValues={filterDefaultValues}
              setSubmitFilterData={setSubmitFilterData}
              filterFields={filterFormFields}
            />

            <AddPool
              primaryActionStyle={primaryActionStyle}
              primaryActionName={"add-pool-action-name"}
              isEditAction={false}
              preciousItemAttributes={preciousItemAttributes}
              data={{}} // Use the data prop as need on edit action
            />
          </SABox>
        </SAStack>
        <PoolsTable
          submitFilterData={submitFilterData}
          searchTerm={searchTerm}
        />
      </SACard>
    </>
  );
};

export default MetalsStonesPools;
