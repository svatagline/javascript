import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  addPoolFormDefaultValues,
  addPoolFormFields,
  loaderPath,
} from "../../descriptions/metalStonePools.description";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import { isRefreshList } from "../../redux/slices/metalsStonesPools.slices";
import MUIModal from "../../shared/MUIModal";
import { MUIStyled } from "../../shared/MUIStyled";
import SABox from "../../shared/SABox";
import SAButton from "../../shared/SAButton";
import SAForm from "../../shared/SAForm";
import SAFormFields from "../../shared/SAFormFields";
import SAStack from "../../shared/SAStack";

const StyledForm = MUIStyled(SAForm)(() => ({
  padding: "10px",
  width: "100%",
  "& .MuiInputBase-input": { padding: 8 },
  "& .formFields": {
    maxHeight: "44vh",
    overflow: "auto",
    padding: "10px 12px",
  },
}));

const AddPoolContent = ({
  handleClose,
  t,
  isEditAction,
  preciousItemAttributes,
  data,
}) => {
  const { api } = useAPI();
  const dispatch = useDispatch();
  const formDefaultValue = addPoolFormDefaultValues;

  const [selectedMaterial, setSelectedMaterial] = useState("");
  const { register, handleSubmit, formState, control, watch, setValue } =
    useForm({
      mode: "onChange",
      defaultValues: formDefaultValue,
    });
  const watchForm = watch();

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.addMetalsStonesPools],
  );

  useEffect(() => {
    const newMaterialType = watchForm?.material_type;
    if (selectedMaterial !== newMaterialType) {
      setSelectedMaterial(newMaterialType);
      setValue("material_item", null);
    }
  }, [watchForm?.material_type]);

  const getFormattedOption = (data) => {
    return data?.map((opt) => {
      return { label: opt.name, value: opt?.id };
    });
  };
  const formFields = addPoolFormFields
    .filter(
      (field) =>
        field?.name !==
        (selectedMaterial == "metal" ? "cut_shape" : "carat_type"),
    )
    .map((field) => {
      if (field?.name === "material_item") {
        return {
          ...field,
          options: getFormattedOption(
            preciousItemAttributes?.material_items?.filter(
              (item) => item?.material_type === selectedMaterial,
            ),
          ),
        };
      } else if (field?.name === "carat_type") {
        return {
          ...field,
          options: getFormattedOption(
            preciousItemAttributes?.metal_carat_types,
          ),
        };
      } else if (field?.name === "cut_shape") {
        return {
          ...field,
          options: getFormattedOption(preciousItemAttributes?.stone_cut_shapes),
        };
      } else {
        return field;
      }
    });
  const onSubmit = async (formData) => {
    const response = await api({
      method: isEditAction ? httpMethods.patch : httpMethods.post,
      endPoint: isEditAction
        ? `${apiEndpoints.getPools}${data.id}/`
        : apiEndpoints.getPools,
      data: formData,
      needLoader: true,
      loader: loaderPath.addMetalsStonesPools,
      showToastMessage: true,
    });
    if (response?.status) {
      dispatch(isRefreshList(true));
      handleClose();
    }
  };

  return (
    <StyledForm onSubmit={handleSubmit(onSubmit)}>
      <SABox className={"formFields"}>
        <SAFormFields
          spacing={2}
          {...{ fields: formFields, register, formState, control }}
        />
      </SABox>
      <SAStack mt={3} justifyContent="center" gap={1} direction="row">
        <SAButton variant="outlined" color="primary" onClick={handleClose}>
          {t("cancel")}
        </SAButton>
        <SAButton
          sx={{ borderRadius: "8px" }}
          variant="contained"
          color="primary"
          type="submit"
          loading={loading}
        >
          {t(isEditAction ? "update-pool" : "add-pool")}
        </SAButton>
      </SAStack>
    </StyledForm>
  );
};

const AddPool = ({
  primaryActionStyle,
  primaryActionName,
  isEditAction,
  preciousItemAttributes,
  data,
}) => {
  const { t } = useI18N();
  const [addEditPoolModal, setAddEditPoolModal] = useState(false);

  const handleClose = () => setAddEditPoolModal(false);

  return (
    <>
      <SAButton
        color="primary"
        variant="contained"
        onClick={() => setAddEditPoolModal(true)}
        {...primaryActionStyle}
      >
        {t(primaryActionName)}
      </SAButton>
      <MUIModal
        open={addEditPoolModal}
        handleClose={handleClose}
        title={t(isEditAction ? "update-pool" : "add-pool")}
        content={
          <AddPoolContent
            t={t}
            preciousItemAttributes={preciousItemAttributes}
            handleClose={handleClose}
            isEditAction={isEditAction}
            data={data}
          />
        }
      />
    </>
  );
};

export default AddPool;
