import { Box, Divider, List, ListItem, Typography } from "@mui/material";

import Logo from "../assets/images/logo.png";

const PrivacyPolicy = () => {
  return (
    <Box sx={{ padding: 4, maxWidth: 1000, margin: "auto", fontSize: 12 }}>
      <Box
        onClick={() => (window.location.href = "https://sooqalthahab.com/")}
        sx={{
          img: { display: "block", margin: "8px auto 30px", cursor: "pointer" },
        }}
      >
        <img src={Logo} alt="logo" />
      </Box>
      <Typography variant="h4" marginBottom={2} textAlign="center">
        Privacy Policy
      </Typography>
      <List>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            Welcome to Sooq Al Thahab (the “App”), owned and operated by The
            Gold Market Platform WLL (“we,” “us,” or “our”). We value your trust
            and are committed to protecting your personal data. This Privacy
            Policy describes how we collect, use, disclose, and safeguard your
            personal information when you download and use our mobile
            application on Android and iOS devices. It also outlines your rights
            under Bahrain’s Personal Data Protection Law (PDPL) and other
            applicable regulations.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            By using our App, you agree to the collection and use of your
            information in accordance with this Privacy Policy. If you do not
            agree with the terms of this Privacy Policy, please do not use our
            App.
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">Scope</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            This Privacy Policy applies to all users of The Gold Market Platform
            in the Kingdom of Bahrain and any other jurisdiction. It outlines
            our practices regarding the personal data we process, including how
            we collect, store, use, and disclose such data.
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">Information We Collect</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            We may collect personal data from you when you use our App. The
            personal data we collect includes, but is not limited to:
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Personal Identification Information
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Full name
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Contact information (email address, phone number)
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Nationality or other demographic information, as required for
            compliance with financial regulations in Bahrain
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Account Information
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Username and password
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Profile picture or avatar (if applicable)
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Transaction Information
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Payment method details, payment transaction IDs, or billing
            information if you make purchases through the App
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Transaction history and receipts
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Device and Usage Information
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Device identifiers (e.g., IP address, unique device ID)
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Operating system and browser type
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            App usage data, including log-in times, activity, and feature usage
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Location Data (if applicable)
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Approximate or precise location information, if you grant us
            permission
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Communications
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Information contained in your correspondence with us (e.g., through
            email or App support)
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">How We Use Your Information</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            We may use your personal data for one or more of the following
            purposes:
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            To Provide and Maintain Our App
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Create and manage your account
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Allow access to core App features
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            To Process Transactions
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Facilitate purchases or sales of gold or other related assets
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Verify payment details and complete transactions
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            To Improve Our Services
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Analyze usage to enhance user experience, optimize performance, and
            develop new features
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Conduct research to better understand market trends and customer
            preferences
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            To Communicate With You
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Send notifications, updates, and administrative messages
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Respond to your inquiries and provide customer support
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            To Ensure Compliance and Security
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Monitor and detect fraud, illegal activities, and potential security
            threats
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Comply with applicable legal obligations, including PDPL and other
            Bahrain-specific laws
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Marketing and Promotional Activities (where applicable and with your
            consent)
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Send you promotions, offers, and updates that may be relevant to you
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Personalize marketing and promotional messages
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">Legal Basis for Processing</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            Under Bahrain’s PDPL, we process your personal data only where there
            is a lawful basis to do so. Depending on the context, this may
            include:
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Consent: Where you have given us clear permission to process your
            personal data for a specific purpose.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Contractual Necessity: Where processing is necessary for the
            performance of a contract with you.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Legal Obligation: Where we must comply with a legal or regulatory
            obligation under Bahraini law or other applicable laws.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Legitimate Interests: Where processing is necessary for our
            legitimate business interests, provided your rights and freedoms do
            not override these interests.
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">Cookies and Similar Technologies</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            We may use cookies or similar tracking technologies in the App to:
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Remember your preferences
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Monitor App usage patterns
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Enhance security and prevent fraud
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            You can control certain tracking mechanisms through your device
            settings or by adjusting App permissions. Please note that disabling
            some tracking technologies may affect your ability to use certain
            features.
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">Disclosure of Your Information</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            We may share your personal data with:
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Service Providers and Partners
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Third parties who perform services on our behalf (e.g., payment
            processors, hosting providers, analytics providers), subject to
            appropriate confidentiality and security obligations.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Business Transfers
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            In connection with a merger, acquisition, or sale of all or a
            portion of our assets, user data may be transferred as part of the
            transaction.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Legal and Regulatory Authorities
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            If we believe disclosure is necessary to comply with a legal
            obligation (e.g., court order, law enforcement request), to protect
            our rights or the rights of others, or to enforce our Terms of
            Service.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            With Your Consent
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            We may share your personal data for other purposes if you have
            specifically consented to such disclosure.
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">Data Retention and Deletion</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            We retain personal data only as long as necessary to fulfill the
            purposes described in this Privacy Policy, or as required by
            Bahraini law and regulations. Once retention is no longer required,
            we securely delete or anonymize the data in accordance with
            recognized industry standards and local regulatory requirements.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            fontWeight={500}
          >
            1. Requesting Data Deletion
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15} component="span">
            If you wish to delete your personal data, you may submit a request
            by contacting us using the details in the “Contact Us” section or
            through our in-app support. Or using the details below:
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Email:{" "}
            <span style={{ fontWeight: 550 }}>support@sooqalthahab.com</span>
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Phone: <span style={{ fontWeight: 550 }}>+973 1768 7222</span>
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Address:{" "}
            <span style={{ fontWeight: 550 }}>
              Area: Manama Block: 304 Road: 341 Building: 71 Flat: 302
            </span>
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15} component="span">
            We will make reasonable efforts to accommodate your request unless
            we are legally obligated or otherwise permitted by law to retain the
            information. For example, certain transaction records and
            identification documents may be kept for anti-money laundering (AML)
            or other regulatory compliance requirements, or for resolving
            disputes and enforcing our policies.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            fontWeight={500}
          >
            2. Legal and Regulatory Obligations
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15} component="span">
            We may be required to store some of your data (e.g., purchase
            history, identification data) for statutory record-keeping,
            auditing, or security purposes—especially if your transactions are
            governed by financial regulations.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15} component="span">
            Once these obligations no longer apply, we will securely delete or
            anonymize any remaining personal data.
          </Typography>
        </ListItem>

        <Divider sx={{ margin: "16px 0" }} />

        <ListItem>
          <Typography variant="h6">Data Security</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            We implement appropriate technical and organizational measures to
            protect your personal data against accidental or unlawful
            destruction, loss, alteration, unauthorized disclosure, or access.
            However, no method of data transmission or storage can be guaranteed
            as 100% secure. You are responsible for keeping your account
            credentials confidential.
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">Your Rights Under Bahrain’s PDPL</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            Under the PDPL, you have the right to:
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Access Your Personal Data
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Request a copy of the personal data we hold about you.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Rectify Your Personal Data
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Ask us to update or correct any inaccurate or incomplete
            information.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Delete Your Personal Data
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Request that we erase your personal data, where legally permissible.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Object to or Restrict Processing
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            In certain circumstances, object to the processing of your personal
            data or request that we restrict such processing.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Withdraw Consent
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Where we rely on your consent to process your personal data, you may
            withdraw this consent at any time.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            To exercise any of these rights or for more information, please
            contact us at the details provided in the “Contact Us” section
            below. We will respond within the timeframes required by law.
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">International Data Transfers</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            Your personal data may be transferred to and processed in countries
            outside the Kingdom of Bahrain. Whenever such transfers take place,
            we ensure that appropriate safeguards are in place to protect your
            personal data consistent with the requirements of the PDPL and other
            applicable laws.
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">Children’s Privacy</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            Our App is not intended for individuals under the age of 18. We do
            not knowingly collect personal data from minors. If you believe we
            have accidentally collected personal data from a minor, please
            contact us immediately so we can delete that information.
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">
            Links to Third-Party Websites or Services
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            Our App may contain links to third-party websites or services that
            are not operated or controlled by us. We are not responsible for the
            content or privacy practices of those websites or services. We
            encourage you to review the privacy policies of any third-party
            websites or services you visit.
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">Updates to This Privacy Policy</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            We may update this Privacy Policy from time to time to reflect
            changes in our data practices or to comply with legal requirements.
            We will notify you of any material changes by updating the
            “Effective Date” at the top of this policy or through other
            appropriate communication channels. Your continued use of the App
            after the posting of any changes constitutes acceptance of those
            changes.
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">Contact Us</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            If you have any questions or concerns about this Privacy Policy or
            our data practices, or if you wish to exercise your rights under
            Bahrain’s PDPL, please contact us at:
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            fontWeight={500}
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            The Gold Market Platform W L.L
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Email:{" "}
            <span style={{ fontWeight: 550 }}>support@sooqalthahab.com</span>
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Phone: <span style={{ fontWeight: 550 }}>+973 1768 7222</span>
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">
            Force Majeure and Security Incidents
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Reasonable Security Measures: We implement appropriate technical and
            organizational safeguards to protect your personal data. However,
            you acknowledge that no method of electronic transmission or storage
            is completely secure.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Events Beyond Our Control: We shall not be held responsible or
            liable for any breach, unauthorized access, disclosure, alteration,
            or loss of personal data caused by events beyond our reasonable
            control (“Force Majeure Events”). Such events include, but are not
            limited to, natural disasters, government actions or regulations,
            war, civil unrest, acts of terrorism, insurrection, embargoes,
            strikes, lockouts or other labor disputes, system malfunctions,
            power failures, cyber-attacks (including hacking or
            denial-of-service attacks), or the acts or omissions of third
            parties.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Human Error: While we strive to minimize errors through internal
            policies and regular training, inadvertent human error may occur. We
            will take prompt corrective measures upon discovering or being
            notified of such errors. However, we shall not be liable for damages
            arising from unintentional or inadvertent human errors if we have
            taken reasonable precautions and measures in line with applicable
            law.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Notification and Mitigation: In the event of a security incident
            affecting your personal data, we will notify you and relevant
            authorities if and as required by applicable law. We will also take
            reasonable steps to contain and investigate the incident, mitigate
            potential harm, and implement measures to prevent future incidents.
          </Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography
            variant="body1"
            fontSize={15}
            component="span"
            sx={{ "::before": { content: '"•"', marginRight: "8px" } }}
          >
            Applicable Laws and Limitations: Nothing in this clause is intended
            to limit any legal rights you may have under applicable data
            protection laws. Our liability (if any) for data breaches, security
            incidents, or force majeure events will be governed by this Privacy
            Policy and any mandatory provisions of applicable law.
          </Typography>
        </ListItem>
        <Divider sx={{ margin: "16px 0" }} />
        <ListItem>
          <Typography variant="h6">Disclaimer</Typography>
        </ListItem>
        <ListItem sx={{ position: "relative", paddingLeft: "20px" }}>
          <Typography variant="body1" fontSize={15}>
            This Privacy Policy template is provided as a general guide. It may
            not cover all legal or business requirements specific to your App or
            your operations in the Kingdom of Bahrain or elsewhere. You are
            strongly advised to consult with a qualified legal professional to
            ensure that your final Privacy Policy meets all applicable legal and
            regulatory standards, including Bahrain’s Personal Data Protection
            Law (PDPL) and any other relevant legislation or guidelines.
          </Typography>
        </ListItem>
      </List>
    </Box>
  );
};

export default PrivacyPolicy;
