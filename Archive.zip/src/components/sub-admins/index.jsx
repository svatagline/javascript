import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Outlet, useParams } from "react-router-dom";

import {
  defaultSubAdminFilterValues,
  subAdminFilterFields,
} from "../../descriptions/subAdmins.descriptions";
import useDebounce from "../../hooks/useDebounce";
import useI18N from "../../hooks/useI18N";
import { Search } from "../../shared/icon";
import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import { MUIStyled } from "../../shared/MUIStyled";
import SABox from "../../shared/SABox";
import SACard from "../../shared/SACard";
import SAFilterMenu from "../../shared/SAFilterMenu";
import SAStack from "../../shared/SAStack";
import SATextField from "../../shared/SATextField";
import theme from "../../themes/theme";
import AddEditSubAdmin from "./AddEditSubAdmin";
import SubAdminTable from "./SubAdminsTable";

const SearchWrapper = MUIStyled(SAStack)({ maxWidth: 400, width: "100%" });

const SubAdmin = () => {
  const { username } = useParams();
  const { t } = useI18N();

  const [searchTerm, setSearchTerm] = useState("");
  const [anchorEl, setAnchorEl] = useState(null);
  const [submitFilterData, setSubmitFilterData] = useState({});
  const [filterData, setFilterData] = useState({
    ...defaultSubAdminFilterValues,
  });

  const debouncedSearch = useDebounce(searchTerm, 300);

  const { register, handleSubmit, formState, control, reset, watch, setValue } =
    useForm({
      mode: "onChange",
      defaultValues: filterData,
    });

  const open = Boolean(anchorEl);
  const watchFields = watch();

  useEffect(() => {
    if (open) {
      Object.keys(filterData).forEach((name) =>
        setValue(name, filterData[name]),
      );
    }
  }, [open]);

  const handleClick = (event) => setAnchorEl(event.currentTarget);

  const handleClose = () => setAnchorEl(null);

  const handleFilterSubmit = (formData) => {
    setSubmitFilterData(formData);
    handleClose();
  };

  const breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: "sub-admins" },
  ];

  const useFormControls = {
    register,
    handleSubmit,
    formState,
    control,
    reset,
    watchFields,
  };

  if (username) {
    return <Outlet />;
  }

  return (
    <>
      <SAStack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        mb={3}
      >
        <SAStack>
          <MUIBreadcrumbs breadcrumbsData={breadcrumbsData} />
        </SAStack>
      </SAStack>
      <SACard>
        <SAStack
          pb={2}
          mb={2}
          direction="row"
          justifyContent="space-between"
          borderBottom={`1px solid ${theme.palette.gray.main}50`}
          alignItems="center"
          flexWrap="wrap"
          gap={3}
        >
          <SearchWrapper>
            <SATextField
              placeholder={t("search-for-admins")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{ startAdornment: <Search /> }}
            />
          </SearchWrapper>
          <SABox sx={{ display: "flex", gap: "10px" }}>
            <SAFilterMenu
              t={t}
              anchorEl={anchorEl}
              open={open}
              handleClose={handleClose}
              onSubmit={handleFilterSubmit}
              handleClick={handleClick}
              useFormControls={useFormControls}
              setFilterData={setFilterData}
              setSubmitFilterData={setSubmitFilterData}
              defaultFilterValues={defaultSubAdminFilterValues}
              filterFields={subAdminFilterFields}
            />
            <AddEditSubAdmin primaryActionName={"add-sub-admin"} />
          </SABox>
        </SAStack>
        <SubAdminTable
          searchQuery={debouncedSearch}
          submitFilterData={submitFilterData}
        />
      </SACard>
    </>
  );
};

export default SubAdmin;
