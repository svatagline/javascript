import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

import { TABLE_RECORD_PER_PAGE } from "../../constants";
import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  loaderPath,
  subAdminTableColumns,
} from "../../descriptions/subAdmins.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import usePagination from "../../hooks/usePagination";
import { addSubAdmins, isRefreshList } from "../../redux/slices/users.slices";
import { Edit } from "../../shared/icon";
import SABasicTable from "../../shared/SABasicTable";
import SABox from "../../shared/SABox";
import SATruncateWithEllipsis from "../../shared/SATruncateWithEllipsis";
import SATypography from "../../shared/SATypography";
import { formatTimestamp, validTableValue } from "../../utils/functions";
import AddEditSubAdmin from "./AddEditSubAdmin";
import SuspendSubAdmin from "./SuspendSubAdmin";

const SubAdminTable = (props) => {
  const { searchQuery, submitFilterData } = props;

  const { t } = useI18N();
  const { api } = useAPI();

  const dispatch = useDispatch();

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.subAdminLoading],
  );
  const subAdminList = useSelector((state) => state?.users?.subAdmins) ?? {};
  const refreshList = useSelector((state) => state?.users?.refreshList);

  const { count, results: subAdminData } = subAdminList;

  const {
    totalPage,
    currentPage,
    setCurrentPage,
    itemPerPage,
    setItemPerPage,
  } = usePagination(count, TABLE_RECORD_PER_PAGE);

  const getSubAdminList = async ({
    page = 1,
    page_size = itemPerPage,
    fullname = "",
    submitFilterData = {},
  } = {}) => {
    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints?.subAdmin}`,
      needLoader: true,
      loader: loaderPath.subAdminLoading,
      showToastOnError: true,
      params: {
        page,
        page_size,
        fullname,
        ...submitFilterData,
      },
    });

    if (response?.status) {
      dispatch(addSubAdmins({ data: response?.data }));
    }
  };

  useEffect(() => {
    getSubAdminList({
      page: currentPage,
      page_size: itemPerPage,
      fullname: searchQuery,
      submitFilterData: submitFilterData,
    });
  }, [currentPage, itemPerPage, searchQuery, submitFilterData]);

  useEffect(() => {
    if (refreshList) {
      getSubAdminList({});
      dispatch(isRefreshList(false));
    }
  }, [refreshList]);

  const primaryActionStyle = {
    size: "small",
    variant: "outlined",
    sx: { "& svg": { ml: 1 } },
  };
  const paginationProps = {
    currentPage,
    page: totalPage,
    rowsPerPage: itemPerPage,
    setItemPerPage,
    setCurrentPage,
  };

  const renderCell = (columnKey, data, _, value) => {
    switch (columnKey) {
      case "full_name":
        return (
          <SATypography variant="body2">
            <SATruncateWithEllipsis
              maxLength={20}
              text={validTableValue(
                `${data?.first_name} ${data?.middle_name} ${data?.last_name}`,
              )}
            />
          </SATypography>
        );

      case "action":
        return (
          <SABox
            sx={{ display: "flex", gap: "15px", justifyContent: "center" }}
          >
            <AddEditSubAdmin
              primaryActionStyle={primaryActionStyle}
              primaryActionIcon={<Edit />}
              primaryActionName={"edit-sub-admin-action-name"}
              isEditAction={true}
              data={data}
            />
          </SABox>
        );

      case "email":
        return (
          <SATypography
            variant="body2"
            fontWeight={500}
            color="primary.main"
            sx={{
              padding: "4px 8px",
              borderRadius: "6px",
              backgroundColor: "#EEF2FF",
              display: "inline-block",
              fontSize: "0.875rem",
            }}
          >
            <SATruncateWithEllipsis
              text={validTableValue(value)}
              maxLength={20}
            />
          </SATypography>
        );

      case "role":
        return (
          <SATypography variant="body2">
            <SATruncateWithEllipsis
              maxLength={20}
              text={validTableValue(
                data?.user_roles &&
                  data?.user_roles.length > 0 &&
                  data?.user_roles
                    .map((roleObj) =>
                      t(`${roleObj?.role}`.replace("_", "-").toLowerCase()),
                    )
                    .join(" | "),
              )}
            />
          </SATypography>
        );

      case "user_type":
        return (
          <SATypography variant="body2">
            {t(`${validTableValue(value, true)}`.toLowerCase())}
          </SATypography>
        );

      case "account_status":
        return <SuspendSubAdmin data={data} />;

      case "last_login":
        return (
          <SATypography
            variant="body2"
            fontWeight={500}
            sx={{
              padding: "4px 8px",
              borderRadius: "6px",
              backgroundColor: "#F3F4F6",
              color: "#374151",
              display: "inline-block",
              fontSize: "0.875rem",
            }}
          >
            {data?.last_login ? formatTimestamp(data?.last_login) : "-"}
          </SATypography>
        );

      case "date_joined":
        return (
          <SATypography
            variant="body2"
            fontWeight={500}
            sx={{
              padding: "4px 8px",
              borderRadius: "6px",
              backgroundColor: "#F3F4F6",
              color: "#374151",
              display: "inline-block",
              fontSize: "0.875rem",
            }}
          >
            {value ? formatTimestamp(value) : "-"}
          </SATypography>
        );

      default:
        return (
          <SATypography variant="body2">
            {validTableValue(value, true)}
          </SATypography>
        );
    }
  };

  return (
    <>
      <SABasicTable
        {...{
          data: subAdminData || [],
          columns: subAdminTableColumns,
          renderCell,
          paginationProps,
          loading: loading,
          colSpan: 5,
        }}
      />
    </>
  );
};

export default SubAdminTable;
