import { useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  changeAccountStatusFormFields,
  loaderPath,
} from "../../descriptions/users.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import { isRefreshList } from "../../redux/slices/users.slices";
import MUIModal from "../../shared/MUIModal";
import { MUIStyled } from "../../shared/MUIStyled";
import SABox from "../../shared/SABox";
import SAButton from "../../shared/SAButton";
import SAForm from "../../shared/SAForm";
import SAFormFields from "../../shared/SAFormFields";
import SAStack from "../../shared/SAStack";
import { isSameObject } from "../../utils/functions";
import showToast from "../../utils/toast";

const StyledForm = MUIStyled(SAForm)(() => ({
  width: "100%",
  "& .MuiInputBase-input": {
    padding: 8,
  },
  "& .formFields": {
    maxHeight: "44vh",
    overflow: "auto",
  },
}));
const SuspendSubAdminContent = ({ handleClose, t, data, refresh }) => {
  const { account_status, suspend_reason, id } = data ?? {};
  const formDefaultValue = {
    account_status: "APPROVED",
    suspend_reason: suspend_reason,
  };

  const formFields = changeAccountStatusFormFields;
  const { register, handleSubmit, formState, control, reset } = useForm({
    mode: "onChange",
    defaultValues: formDefaultValue,
  });
  const dispatch = useDispatch();
  const loading = useSelector(
    (state) => state.loader?.[loaderPath.userSuspendLoading],
  );
  const { api } = useAPI();

  const onSubmit = async (formData) => {
    let isChangedInForm = !isSameObject(
      { account_status, suspend_reason },
      formData,
    );
    if (isChangedInForm) {
      const response = await api({
        method: httpMethods.patch,
        endPoint: `${apiEndpoints.suspend}${id}/status/`,
        data: formData,
        needLoader: true,
        loader: loaderPath.userSuspendLoading,
        showToastMessage: true,
      });
      if (response?.status) {
        dispatch(isRefreshList(true));
        reset(formDefaultValue);
        handleClose();
        refresh && refresh();
      }
    } else {
      showToast("Please edit the form", { type: "error" });
    }
  };

  return (
    <SABox p={2}>
      <StyledForm onSubmit={handleSubmit(onSubmit)}>
        <SABox className={"formFields"}>
          <SAFormFields
            spacing={2}
            {...{ fields: formFields, register, formState, control }}
          />
        </SABox>
        <SAStack direction="row" mt={3} justifyContent="center" gap={2}>
          <SAButton variant="outlined" color="primary" onClick={handleClose}>
            {t("cancel")}
          </SAButton>
          <SAButton
            variant="contained"
            color="primary"
            type="submit"
            loading={loading}
          >
            {t("submit")}
          </SAButton>
        </SAStack>
      </StyledForm>
    </SABox>
  );
};

const SuspendSubAdmin = ({ isEditAction, data, refresh }) => {
  const [addEditSubAdminModal, setAddEditSubAdminModal] = useState(false);
  const { account_status } = data ?? {};
  const handleClose = () => setAddEditSubAdminModal(false);
  const { t } = useI18N();

  return (
    <>
      <SAButton
        color="primary"
        onClick={() => setAddEditSubAdminModal(true)}
        size="small"
        variant="outlined"
        sx={{ "& svg": { ml: 1 } }}
      >
        {account_status}
      </SAButton>
      <MUIModal
        open={addEditSubAdminModal}
        handleClose={handleClose}
        title={t("change-account-status")}
        maxWidth="xs"
        content={
          <SuspendSubAdminContent
            handleClose={handleClose}
            t={t}
            isEditAction={isEditAction}
            data={data}
            refresh={refresh}
          />
        }
      />
    </>
  );
};
export default SuspendSubAdmin;
