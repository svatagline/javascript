import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import { loaderPath } from "../../descriptions/subAdmins.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import { isRefreshList } from "../../redux/slices/users.slices";
import { Delete } from "../../shared/icon";
import MUIModal from "../../shared/MUIModal";
import SABox from "../../shared/SABox";
import SAButton from "../../shared/SAButton";
import SATypography from "../../shared/SATypography";

const DeleteSubAdminContent = ({ handleClose, t, data }) => {
  const dispatch = useDispatch();
  const { api } = useAPI();

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.deleteSubAdminLoading],
  );

  const onSubmit = async () => {
    const response = await api({
      method: httpMethods.delete,
      endPoint: `${apiEndpoints.subAdmin}${data.id}/`,
      needLoader: true,
      loader: loaderPath.deleteSubAdminLoading,
      showToastMessage: true,
    });
    if (response?.status) {
      dispatch(isRefreshList(true));
      handleClose();
    }
  };

  return (
    <>
      <SABox mt={3} textAlign="center">
        <SABox sx={{ marginBottom: "24px" }}>
          <SATypography variant="h6" sx={{ padding: "0 20px" }}>
            Are You Sure You Want to Delete Record of {data?.username}?
          </SATypography>
        </SABox>
        <SAButton variant="text" color="primary" onClick={handleClose}>
          {t("cancel")}
        </SAButton>
        <SAButton
          sx={{ borderRadius: "8px" }}
          variant="contained"
          color="primary"
          type="submit"
          loading={loading}
          onClick={onSubmit}
        >
          {t("delete")}
        </SAButton>
      </SABox>
    </>
  );
};

const DeleteSubAdmin = ({ isEditAction, data }) => {
  const [deleteSubAdminModal, setDeleteSubAdminModal] = useState(false);
  const handleClose = () => setDeleteSubAdminModal(false);
  const { t } = useI18N();

  return (
    <>
      <SAButton
        color="primary"
        onClick={() => setDeleteSubAdminModal(true)}
        size="small"
        variant="outlined"
        sx={{ "& svg": { ml: 1 } }}
      >
        {t("delete-sub-admin-action-name")} <Delete />
      </SAButton>

      <MUIModal
        open={deleteSubAdminModal}
        handleClose={handleClose}
        fullWidth="sm"
        title={t("delete-sub-admin")}
        maxWidth={"450px"}
        content={
          <DeleteSubAdminContent
            handleClose={handleClose}
            t={t}
            isEditAction={isEditAction}
            data={data}
          />
        }
      />
    </>
  );
};
export default DeleteSubAdmin;
