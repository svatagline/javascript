import { useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  addSubAdminFormDefaultValues,
  addSubAdminFormFields,
  loaderPath,
} from "../../descriptions/subAdmins.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import { isRefreshList } from "../../redux/slices/users.slices";
import MUIModal from "../../shared/MUIModal";
import { MUIStyled } from "../../shared/MUIStyled";
import SABox from "../../shared/SABox";
import SAButton from "../../shared/SAButton";
import SAForm from "../../shared/SAForm";
import SAFormFields from "../../shared/SAFormFields";
import SAStack from "../../shared/SAStack";

const StyledForm = MUIStyled(SAForm)(() => ({
  padding: "10px",
  width: "100%",
  "& .MuiInputBase-input": { padding: 8 },
  "& .formFields": {
    maxHeight: "44vh",
    overflow: "auto",
    padding: "10px 12px",
  },
}));

const AddEditSubAdminContent = ({ handleClose, t, isEditAction, data }) => {
  const { api } = useAPI();
  const dispatch = useDispatch();
  const formDefaultValue = !isEditAction
    ? addSubAdminFormDefaultValues
    : {
        email: data?.email,
        role: data?.user_roles[0]?.["role"],
        first_name: data?.first_name,
        middle_name: data?.middle_name,
        last_name: data?.last_name,
      };

  const { register, handleSubmit, formState, control } = useForm({
    mode: "onChange",
    defaultValues: formDefaultValue,
  });

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.addSubAdminLoading],
  );

  const formFields = isEditAction
    ? addSubAdminFormFields
        .filter(({ name }) => name !== "password")
        .map((field) =>
          field.name === "email" ? { ...field, disabled: true } : field,
        )
    : addSubAdminFormFields;

  const onSubmit = async (formData) => {
    const response = await api({
      method: isEditAction ? httpMethods.patch : httpMethods.post,
      endPoint: isEditAction
        ? `${apiEndpoints.subAdmin}${data.id}/`
        : apiEndpoints.subAdmin,
      data: formData,
      needLoader: true,
      loader: loaderPath.addSubAdminLoading,
      showToastMessage: true,
    });
    if (response?.status) {
      dispatch(isRefreshList(true));
      handleClose();
    }
  };

  return (
    <StyledForm onSubmit={handleSubmit(onSubmit)}>
      <SABox className={"formFields"}>
        <SAFormFields
          spacing={2}
          {...{ fields: formFields, register, formState, control }}
        />
      </SABox>
      <SAStack mt={3} justifyContent="center" gap={1} direction="row">
        <SAButton variant="outlined" color="primary" onClick={handleClose}>
          {t("cancel")}
        </SAButton>
        <SAButton
          sx={{ borderRadius: "8px" }}
          variant="contained"
          color="primary"
          type="submit"
          loading={loading}
        >
          {t(isEditAction ? "update-sub-admin" : "add-sub-admin")}
        </SAButton>
      </SAStack>
    </StyledForm>
  );
};

const AddEditSubAdmin = ({
  primaryActionStyle,
  primaryActionIcon,
  primaryActionName,
  isEditAction,
  data,
}) => {
  const { t } = useI18N();
  const [addEditSubAdminModal, setAddEditSubAdminModal] = useState(false);

  const handleClose = () => setAddEditSubAdminModal(false);

  return (
    <>
      <SAButton
        color="primary"
        variant="contained"
        onClick={() => setAddEditSubAdminModal(true)}
        {...primaryActionStyle}
      >
        {t(primaryActionName)} {primaryActionIcon}
      </SAButton>
      <MUIModal
        open={addEditSubAdminModal}
        handleClose={handleClose}
        title={t(isEditAction ? "update-sub-admin" : "add-sub-admin")}
        content={
          <AddEditSubAdminContent
            handleClose={handleClose}
            t={t}
            isEditAction={isEditAction}
            data={data}
          />
        }
      />
    </>
  );
};

export default AddEditSubAdmin;
