import CallIcon from "@mui/icons-material/Call";
import EmailIcon from "@mui/icons-material/Email";
import { Card, Chip, Divider, List, ListItem } from "@mui/material";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import { loaderPath } from "../../descriptions/users.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import { MUIStyled } from "../../shared/MUIStyled";
import SAAvatar from "../../shared/SAAvatar";
import SABox from "../../shared/SABox";
import SADataLoading from "../../shared/SADataLoading";
import LazyImage from "../../shared/SAImageLoader";
import SAStack from "../../shared/SAStack";
import SATypography from "../../shared/SATypography";
import theme from "../../themes/theme";
import { validBooleanValue, validDetailsValue } from "../../utils/functions";

const StyledCard = MUIStyled(Card)(() => ({
  padding: 20,
  boxShadow: "0 0 20px rgba(0, 0, 0, 0.04)",
  borderRadius: 15,
  height: "100%",
}));

const StyledBox = MUIStyled(SABox)(() => ({
  width: "100%",
  display: "grid",
  gridTemplateColumns: "1fr 3fr",
  gap: "10px",
  [theme.breakpoints.down(1400)]: {
    gridTemplateColumns: "1fr 2fr",
  },
  [theme.breakpoints.down(960)]: {
    gridTemplateColumns: "1fr",
  },

  "& .MuiInputBase-input": {
    padding: 8,
  },
  "& .formFields": {
    maxHeight: "44vh",
    overflow: "auto",
    paddingRight: "12px",
  },
  "& .userDetailsContainer": {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: "10px",
    [theme.breakpoints.down(1100)]: {
      gridTemplateColumns: "1fr",
    },
  },
}));

const SubAdminDetails = () => {
  const [userData, setUserData] = useState({});
  const { t } = useI18N();
  const [userDataExist, setUserDataExist] = useState(false);
  const { api } = useAPI();
  const urlParams = useParams();
  const loading = useSelector(
    (state) => state.loader?.[loaderPath.userDetailsLoading],
  );

  useEffect(() => {
    getUsersDetails();
  }, [urlParams?.username]);

  const getUsersDetails = async () => {
    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints.subAdmin}${urlParams?.username}/`,
      needLoader: true,
      loader: loaderPath.userDetailsLoading,
      showToastOnError: true,
    });

    if (response?.status) {
      setUserData(response?.data);
      setUserDataExist(true);
    } else {
      setUserDataExist(false);
    }
  };

  const data = {
    // Boolean
    booleans: {
      is_staff: userData?.is_staff,
      is_active: userData?.is_active,
      is_superuser: userData?.is_superuser,
      face_verified: userData?.face_verified,
      document_verified: userData?.document_verified,
      phone_verified: userData?.phone_verified,
      email_verified: userData?.email_verified,
      individual_aml_verified: userData?.individual_aml_verified,
      business_aml_verified: userData?.business_aml_verified,
      due_diligence_verified: userData?.due_diligence_verified,
    },
    // Dates
    dates: {
      date_of_birth: userData?.date_of_birth,
      date_joined: validDetailsValue(userData?.date_joined, "date"),
      last_login: validDetailsValue(userData?.last_login, "date"),
    },
    // Personal information
    personalDetails: {
      profile_image: userData?.profile_image,
      first_name: userData?.first_name,
      middle_name: userData?.middle_name,
      last_name: userData?.last_name,
      username: userData?.username,
      email: userData?.email,
      phone_number: userData?.phone_number,
      phone_country_code: userData?.phone_country_code,
      gender: userData?.gender,
      user_type: t(`${userData?.user_type}`.toLowerCase()),
      account_status: userData?.account_status,
    },
    addresses: userData?.addresses?.length > 0 ? userData?.addresses : null,
    businesses: userData?.businesses?.length > 0 ? userData?.businesses : null,
    // Numbers
    id: userData?.id,
    organization_id: userData?.organization_id,
    // Other
    groups: userData?.groups?.length > 0 ? userData?.groups : null,

    user_permissions:
      userData?.user_permissions?.length > 0
        ? userData?.user_permissions
        : null,
  };
  const breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: "sub-admins", href: "/sub-admins" },
    { label: `${data?.personalDetails?.username}`, noTranslate: true },
  ];
  const personalDetailsConfig = [
    {
      key: "phone_number",
      label: "",
      icon: <CallIcon sx={{ fontSize: 15 }} />,
    },
    { key: "email", label: "", icon: <EmailIcon sx={{ fontSize: 15 }} /> },
  ];
  return (
    <>
      <SAStack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        mb={3}
      >
        <SAStack>
          <MUIBreadcrumbs breadcrumbsData={breadcrumbsData} />
        </SAStack>
      </SAStack>

      {loading || !userDataExist ? (
        <SADataLoading nodataExist={!userDataExist} loading={loading} />
      ) : (
        <StyledBox>
          <SABox className="profileDetail">
            <StyledCard>
              <SABox className="userProfileContainer">
                <SABox display="flex" flexDirection="column" gap={6}>
                  <SABox>
                    <LazyImage
                      alt={t("sub-admin")}
                      src="/images/avatars/1.png"
                      style={{ width: "100%" }}
                      enableGlassEffect
                    />

                    <SABox
                      mt={2}
                      flex={1}
                      sx={{
                        pt: 2,
                        borderTop: `1px solid ${theme.palette.gray.light}`,
                      }}
                    >
                      <SAStack
                        direction="row"
                        alignItems="center"
                        justifyContent="space-between"
                        gap="10px"
                        flexWrap="wrap"
                      >
                        <SATypography variant="h6">{`${validDetailsValue(data?.personalDetails.first_name)} ${validDetailsValue(data?.personalDetails.middle_name)} ${validDetailsValue(data?.personalDetails.last_name)}`}</SATypography>
                        <Chip
                          label={t(
                            `${data?.personalDetails?.account_status}`.toLowerCase(),
                          )}
                          variant="tonal"
                          color="warning"
                          size="small"
                        />
                      </SAStack>
                      {personalDetailsConfig.map((detail, index) => (
                        <SABox
                          key={index}
                          display="flex"
                          alignItems="center"
                          gap={2}
                          mt={2}
                        >
                          <SAAvatar
                            variant="rounded"
                            sx={{ height: 20, width: 20, bgcolor: "primary" }}
                          >
                            {detail.icon}
                          </SAAvatar>
                          <SABox>
                            <SATypography>
                              {detail.label}{" "}
                              {validDetailsValue(
                                data?.personalDetails?.[detail.key],
                              ) || "N/A"}
                            </SATypography>
                          </SABox>
                        </SABox>
                      ))}
                    </SABox>
                  </SABox>
                </SABox>
              </SABox>
            </StyledCard>
          </SABox>
          <SABox className="otherInformation">
            <StyledCard>
              <SABox className="userDetailsContainer">
                <SABox>
                  <SABox className={"detailList"}>
                    <SABox>
                      <SATypography variant="h5">
                        {t("personal-details")}
                      </SATypography>
                      <Divider sx={{ marginY: 2 }} />
                      <List>
                        {[
                          { key: "first_name", title: t("first-name") },
                          { key: "middle_name", title: t("middle-name") },
                          { key: "last_name", title: t("last-name") },
                          { key: "username", title: t("user-name") },
                          { key: "user_type", title: t("user-type") },
                          {
                            key: "phone_country_code",
                            title: t("phone-country-code"),
                          },
                          { key: "gender", title: t("gender") },
                        ].map((field) => (
                          <ListItem key={field} className="wrap-list">
                            <SATypography
                              color="text.primary"
                              fontWeight="medium"
                              className="no-word-break"
                            >
                              {`${field["title"]}:`}
                            </SATypography>
                            <SATypography ml={1}>
                              {validDetailsValue(
                                data?.personalDetails[field["key"]],
                              )}
                            </SATypography>
                          </ListItem>
                        ))}

                        {[
                          { key: "date_of_birth", title: t("date-of-birth") },
                          { key: "date_joined", title: t("date-joined") },
                          { key: "last_login", title: t("last-login") },
                        ].map((field) => (
                          <ListItem key={field} className="wrap-list">
                            <SATypography
                              color="text.primary"
                              fontWeight="medium"
                              className="no-word-break"
                            >
                              {`${field["title"]}:`}
                            </SATypography>
                            <SATypography ml={1}>
                              {data?.dates[field["key"]]}
                            </SATypography>
                          </ListItem>
                        ))}
                      </List>
                    </SABox>
                  </SABox>
                </SABox>
                <SABox>
                  <SABox className={"detailList"}>
                    <SATypography variant="h5">
                      {t("verification-details")}
                    </SATypography>
                    <Divider sx={{ marginY: 2 }} />
                    <List>
                      {[
                        { key: "is_staff", title: t("is-staff") },
                        { key: "is_active", title: t("is-active") },
                        { key: "is_superuser", title: t("is-superuser") },
                      ].map((field) => (
                        <ListItem key={field} className="wrap-list">
                          <SATypography
                            color="text.primary"
                            fontWeight="medium"
                            className="no-word-break"
                          >
                            {`${field["title"]}:`}
                          </SATypography>
                          <SATypography ml={1}>
                            {validBooleanValue(data?.booleans[field["key"]])}
                          </SATypography>
                        </ListItem>
                      ))}
                    </List>
                  </SABox>
                </SABox>
              </SABox>
            </StyledCard>
          </SABox>
        </StyledBox>
      )}
    </>
  );
};

export default SubAdminDetails;
