import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import { Collapse, List, ListItem, useMediaQuery } from "@mui/material";
import { Fragment, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";

import LogoSmall from "../../assets/images/small-logo.png";
import { ADMIN } from "../../constants";
import { adminSidebarMenu } from "../../descriptions/sidebar.descriptions";
import useI18N from "../../hooks/useI18N";
import { Logout, User } from "../../shared/icon";
import MUIModal from "../../shared/MUIModal";
import { MUIStyled } from "../../shared/MUIStyled";
import SABox from "../../shared/SABox";
import SAButton from "../../shared/SAButton";
import SAStack from "../../shared/SAStack";
import SATypography from "../../shared/SATypography";
import theme from "../../themes/theme";
import { logout } from "../../utils/functions";

const SidebarWrapper = MUIStyled(SAStack)(({ collapse, dir, theme }) => ({
  width: collapse ? 60 : 250,
  position: "fixed",
  left: dir === "rtl" ? "auto" : 0,
  right: dir === "rtl" ? 0 : "auto",
  top: 60,
  bottom: 0,
  zIndex: 9,
  backgroundColor: theme.palette.white.main,
  transition: "all 0.3s ease-in-out",
  [theme.breakpoints.down("md")]: {
    width: collapse ? 250 : 60,
  },
}));

const LogoWrapper = MUIStyled(SAStack)(({ collapse }) => ({
  display: collapse ? "block" : "none",
  padding: collapse ? 10 : 15,
  [theme.breakpoints.down("md")]: {
    display: collapse ? "none" : "block",
    padding: 10,
  },
  "& img": { display: "block" },
}));

const SmallLogo = MUIStyled(Link)(() => ({
  "& img": { display: "block", maxWidth: 40 },
}));

const UserInfo = MUIStyled(SAStack)(({ theme }) => ({
  padding: "10px",
  "& svg": {
    border: `1px solid ${theme.palette.gray.main}50`,
    padding: 7,
    borderRadius: 10,
    width: 40,
    height: 40,
  },
}));

const MainMenu = MUIStyled(List)(({ theme, collapse, dir }) => ({
  flex: 1,
  overflowY: "auto",
  "& .MuiListItem-root": {
    padding: "2px 0",
    "& a, & p": {
      textDecoration: "none",
      background: theme.palette.white.main,
      color: theme.palette.black.main,
      position: "relative",
      zIndex: 1,
      display: "flex",
      alignItems: "center",
      width: "100%",
      padding: "10px 12px",
      borderRight: dir === "rtl" ? 0 : `2px solid transparent`,
      borderLeft: dir === "rtl" ? `2px solid transparent` : 0,
      cursor: "pointer",
      justifyContent: collapse ? "center" : "flex-start",
      [theme.breakpoints.down("md")]: {
        justifyContent: collapse ? "flex-start" : "center",
      },
      "&.active": {
        borderColor: theme.palette.primary.main,
        color: theme.palette.primary.main,
        "& span": { fontWeight: "bold" },
      },
      "& svg": {
        flex: "none",
        marginRight: dir === "rtl" ? 0 : collapse ? 0 : 10,
        marginLeft: dir === "rtl" ? (collapse ? 0 : 10) : 0,
        [theme.breakpoints.down("md")]: {
          marginRight: dir === "rtl" ? 0 : collapse ? 10 : 0,
          marginLeft: dir === "rtl" ? (collapse ? 10 : 0) : 0,
        },
        "&:last-child": {
          marginLeft: dir === "rtl" ? 0 : "auto",
          marginRight: dir === "rtl" ? "auto" : 0,
        },
      },
      "& span": {
        fontSize: "0.95rem",
        lineHeight: "normal",
        display: collapse ? "none" : "inline",
        [theme.breakpoints.down("md")]: {
          display: collapse ? "inline" : "none",
        },
      },
    },
  },
  "& .MuiList-root": {
    "& .MuiListItem-root": {
      "&:before": {
        content: "''",
        position: "absolute",
        bottom: "50%",
        borderBottom: `1px solid ${theme.palette.gray.main}`,
        width: 15,
        top: -30,
        ...(dir === "rtl"
          ? {
              right: -10,
              borderRight: `1px solid ${theme.palette.gray.main}`,
              borderRadius: "0 0 10px 0",
            }
          : {
              left: -10,
              borderLeft: `1px solid ${theme.palette.gray.main}`,
              borderRadius: "0 0 0 10px",
            }),
      },
      "& a, & p": { padding: "10px 8px", margin: "0 4px" },
    },
  },
}));

const SubMenu = MUIStyled(List)(({ theme, dir }) => ({
  paddingLeft: dir === "rtl" ? 0 : 30,
  paddingRight: dir === "rtl" ? 30 : 0,
  paddingTop: 0,
  "& .MuiListItem-root": {
    padding: "2px 0",
    "& a": {
      textDecoration: "none",
      color: theme.palette.black.main,
      display: "flex",
      alignItems: "center",
      width: "100%",
      padding: "8px 12px",
      fontSize: "0.9rem",
      "&.active": { color: theme.palette.primary.main, fontWeight: "bold" },
    },
  },
}));

const LogoutConfirmation = ({ open, handleClose, onConfirm }) => {
  const { t } = useI18N();

  return (
    <MUIModal
      open={open}
      handleClose={handleClose}
      content={
        <SABox p={2}>
          <SATypography textAlign="center" variant="h6">
            {t("logout-confirmation-message")}
          </SATypography>
          <SAStack direction="row" spacing={2} justifyContent="center" mt={3}>
            <SAButton variant="outlined" color="primary" onClick={handleClose}>
              {t("no")}
            </SAButton>
            <SAButton variant="contained" color="primary" onClick={onConfirm}>
              {t("yes")}
            </SAButton>
          </SAStack>
        </SABox>
      }
      maxWidth={"450px"}
    />
  );
};

const Sidebar = ({ collapse }) => {
  const { t, dir } = useI18N();
  const location = useLocation();
  const navigate = useNavigate();
  const screenMd = useMediaQuery(theme.breakpoints.down("md"));

  const [collapseMenu, setCollapseMenu] = useState(false);
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  const sidebarMenu = adminSidebarMenu[ADMIN];

  const handleLogout = () => {
    setShowLogoutModal(true);
  };

  const confirmLogout = () => {
    navigate("/login");
    logout();
    setShowLogoutModal(false);
  };

  const handleCollapseMenu = (path) => {
    setCollapseMenu((prev) => !prev);
    // setCollapse(Boolean(screenMd));
    if (screenMd) {
      setCollapseMenu(false);
    }
    navigate(path);
  };

  // useEffect(() => {
  //   setCollapseMenu(screenMd === collapse);
  // }, [collapse, screenMd]);

  return (
    <>
      <SidebarWrapper collapse={collapse} dir={dir}>
        <LogoWrapper
          direction={collapse ? "column" : "row"}
          alignItems="center"
          justifyContent="space-between"
          collapse={collapse}
        >
          <SmallLogo to="/businesses">
            <img src={LogoSmall} alt="logo" />
          </SmallLogo>
        </LogoWrapper>
        <UserInfo direction="row" gap={1}>
          <User />
          <SAStack
            display={{
              md: collapse ? "none" : "block",
              xs: collapse ? "block" : "none",
            }}
          >
            <SATypography fontWeight="bold">{t("system-admin")}</SATypography>
            <SATypography variant="body2">{t("admin-portal")}</SATypography>
          </SAStack>
        </UserInfo>
        <MainMenu dir={dir} collapse={collapse}>
          {sidebarMenu?.map(({ label, path, icon, list }) => (
            <Fragment key={label}>
              <ListItem>
                {list ? (
                  <SATypography onClick={() => handleCollapseMenu(path)}>
                    {icon}{" "}
                    <SATypography component="span">{t(label)}</SATypography>
                    {collapseMenu ? (
                      <KeyboardArrowUpIcon />
                    ) : (
                      <KeyboardArrowDownIcon />
                    )}
                  </SATypography>
                ) : (
                  <Link
                    to={path}
                    className={
                      location.pathname?.includes(`${path}`.replaceAll("/", ""))
                        ? "active"
                        : ""
                    }
                  >
                    {icon}{" "}
                    <SATypography component="span">{t(label)}</SATypography>
                  </Link>
                )}
              </ListItem>
              {list && (
                <Collapse in={collapseMenu}>
                  <SubMenu dir={dir}>
                    {list?.map((subItem) => (
                      <ListItem key={subItem.label}>
                        <Link
                          to={subItem.path}
                          className={
                            location.pathname === subItem.path ? "active" : ""
                          }
                        >
                          <SATypography component="span">
                            {t(subItem.label)}
                          </SATypography>
                        </Link>
                      </ListItem>
                    ))}
                  </SubMenu>
                </Collapse>
              )}
            </Fragment>
          ))}
        </MainMenu>
        <SABox sx={{ p: 2 }}>
          <SAButton
            fullWidth
            color="primary"
            variant="text"
            onClick={handleLogout}
            sx={{ p: 1, minWidth: "auto" }}
          >
            <Logout />{" "}
            <SATypography
              fontWeight="bold"
              ml={dir === "rtl" ? 0 : 1}
              mr={dir === "rtl" ? 1 : 0}
              component="span"
              display={{
                md: collapse ? "none" : "block",
                xs: collapse ? "block" : "none",
              }}
            >
              {t("logout")}
            </SATypography>
          </SAButton>
        </SABox>
      </SidebarWrapper>

      <LogoutConfirmation
        open={showLogoutModal}
        handleClose={() => setShowLogoutModal(false)}
        onConfirm={confirmLogout}
      />
    </>
  );
};

export default Sidebar;
