import { useMediaQuery } from "@mui/material";
import { Suspense, useEffect, useState } from "react";
import { Outlet } from "react-router-dom";

import getSessionDetails from "../../api/session";
import useI18N from "../../hooks/useI18N";
import { MUIStyled } from "../../shared/MUIStyled";
import SABox from "../../shared/SABox";
import theme from "../../themes/theme";
import { getNotifications } from "../../utils/functions";
import Notifications from "../Notifications";
import SuspenseFallback from "../SuspenseFallback";
import Header from "./header/Header";
import Sidebar from "./Sidebar";

const Main = MUIStyled(SABox)(({ theme, collapse, dir }) => {
  const isRTL = dir === "rtl";
  return {
    overflowY: "auto",
    display: "flex",
    flexDirection: "column",
    backgroundColor: theme.palette.gray.light700,
    marginLeft: isRTL ? 0 : collapse ? 60 : 250,
    marginRight: isRTL ? (collapse ? 60 : 250) : 0,
    minHeight: "calc(100vh - 60px)",
    [theme.breakpoints.down("md")]: {
      marginLeft: isRTL ? 0 : 60,
      marginRight: isRTL ? 60 : 0,
    },
  };
});

const AppLayout = () => {
  const { dir } = useI18N();
  const screenMd = useMediaQuery(theme.breakpoints.down("md"));
  const [collapse, setCollapse] = useState(false);

  useEffect(() => {
    getNotifications();
    getSessionDetails();
  }, []);

  const toggleCollapse = () => {
    setCollapse((prev) => (screenMd ? false : !prev));
  };

  return (
    <>
      <Sidebar {...{ collapse, toggleCollapse, setCollapse }} />
      <Header {...{ collapse, toggleCollapse }} />
      <Main dir={dir} collapse={collapse} component="main">
        <Suspense fallback={<SuspenseFallback />}>
          <SABox
            sx={{
              padding: "24px",
              marginTop: "60px",
              display: "flex",
              flexDirection: "column",
              flexGrow: 1,
            }}
          >
            <Outlet />
          </SABox>
        </Suspense>
      </Main>
      <Notifications />
    </>
  );
};

export default AppLayout;
