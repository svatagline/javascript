import { Suspense } from "react";
import { Navigate, Outlet } from "react-router-dom";

import SuspenseFallback from "../SuspenseFallback";

const AuthLayout = () => {
  const token = localStorage.getItem("accessToken");

  if (token) return <Navigate to="/businesses" />;

  return (
    <Suspense fallback={<SuspenseFallback />}>
      <Outlet />
    </Suspense>
  );
};

export default AuthLayout;
