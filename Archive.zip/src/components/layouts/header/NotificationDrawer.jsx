import CloseIcon from "@mui/icons-material/Close";
import EastIcon from "@mui/icons-material/East";
import InfoOutlineIcon from "@mui/icons-material/InfoOutlined";
import NotificationsActiveIcon from "@mui/icons-material/NotificationsActive";
import WestIcon from "@mui/icons-material/West";
import { Avatar, IconButton, List, ListItem } from "@mui/material";
import { useCallback, useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import useI18N from "../../../hooks/useI18N";
import { Request, Transaction } from "../../../shared/icon";
import { MUIStyled } from "../../../shared/MUIStyled";
import SABox from "../../../shared/SABox";
import SALoader from "../../../shared/SALoader";
import SAStack from "../../../shared/SAStack";
import SATruncateWithEllipsis from "../../../shared/SATruncateWithEllipsis";
import SATypography from "../../../shared/SATypography";
import { formatTimestamp, getNotifications } from "../../../utils/functions";

const NotificationPanel = MUIStyled(SABox)({
  padding: 16,
  height: "100%",
  display: "flex",
  flexDirection: "column",
  overflow: "auto",
});

const NotificationList = MUIStyled(List)(({ theme }) => ({
  padding: 0,
  "& .MuiListItem-root": {
    marginTop: 18,
    borderRadius: 12,
    backgroundColor: theme.palette.background.paper,
    boxShadow: "0 6px 16px rgba(0,0,0,0.08)",
    display: "flex",
    alignItems: "flex-start",
    gap: 16,
    cursor: "pointer",
    position: "relative",
    padding: 20,
    transition: "all 0.3s ease",
    "&:hover": { background: "rgba(233, 233, 233, 0.05)" },
  },
}));

const CloseBtn = MUIStyled(IconButton)(({ theme, dir }) => ({
  position: "absolute",
  top: 12,
  [dir === "rtl" ? "left" : "right"]: 12,
  color: theme.palette.grey[400],
}));

const CloseArrowButton = MUIStyled(IconButton)(({ dir }) => ({
  position: "absolute",
  top: 12,
  [dir === "rtl" ? "left" : "right"]: 12,
}));

const notificationModuleMap = {
  PURCHASE_REQUEST_CREATED: "purchase-requests",
  PURCHASE_REQUEST_APPROVED: "purchase-requests",
  PURCHASE_REQUEST_REJECTED: "purchase-requests",
  PURCHASE_REQUEST_COMPLETED: "purchase-requests",
  SALE_REQUEST_CREATED: "purchase-requests",
  SALE_REQUEST_APPROVED: "purchase-requests",
  SALE_REQUEST_REJECTED: "purchase-requests",
  SALE_REQUEST_COMPLETED: "purchase-requests",
  PURCHASE_REQUEST_PAYMENT_TRANSFER: "transactions",
  PURCHASE_REQUEST_PAYMENT_RECEIVED: "transactions",
  PURCHASE_REQUEST_PAYMENT_FAILED: "transactions",
  WITHDRAW_REQUEST_APPROVED: "transactions",
  WITHDRAW_REQUEST_REJECTED: "transactions",
  WITHDRAW_REQUEST_CREATED: "transactions",
  DEPOSIT_REQUEST_APPROVED: "transactions",
  DEPOSIT_REQUEST_REJECTED: "transactions",
  DEPOSIT_REQUEST_CREATED: "transactions",
};

const moduleIconMap = {
  transactions: <Transaction />,
  "purchase-requests": <Request />,
};

const NotificationDrawer = ({ onClose }) => {
  const { t, dir } = useI18N();
  const navigate = useNavigate();
  const containerRef = useRef(null);
  const hasScrolledRef = useRef(null);

  const notificationsData = useSelector((state) => state.app?.notifications);

  const [page, setPage] = useState(1);
  const [next, setNext] = useState(notificationsData?.next);
  const [performanceLoader, setPerformanceLoader] = useState(false);
  const [notifications, setNotifications] = useState(
    notificationsData?.results || [],
  );

  const handleRemove = (e) => e.stopPropagation();

  const handleNotificationClick = ({ id, type }) => {
    const currentRoute = notificationModuleMap[type];

    if (!currentRoute) return;

    onClose();
    navigate(`/${currentRoute}/${id}`);
  };

  const handleScroll = useCallback(async () => {
    const container = containerRef.current;
    if (!container || performanceLoader) return;

    const { scrollTop, scrollHeight, clientHeight } = container;
    const isNearBottom = scrollTop + clientHeight >= scrollHeight - 10;

    if (isNearBottom && !hasScrolledRef.current) {
      hasScrolledRef.current = true;

      if (!next) return;

      const nextPage = page + 1;
      setPage(nextPage);

      setPerformanceLoader(true);
      const response = await getNotifications({
        page: nextPage,
        needLoader: true,
        storeInRedux: false,
      });

      if (response?.status === 200) {
        const { results, next } = response?.data?.data || {};
        setNext(next);
        setNotifications((prev) => [...prev, ...(results || [])]);
      }

      setPerformanceLoader(false);
    } else if (!isNearBottom) {
      hasScrolledRef.current = false;
    }
  }, [page, next, performanceLoader]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    if (performanceLoader) {
      requestAnimationFrame(() =>
        requestAnimationFrame(() =>
          container.scrollTo({
            top: container.scrollHeight,
            behavior: "smooth",
          }),
        ),
      );
    }
  }, [performanceLoader]);

  return (
    <NotificationPanel ref={containerRef} onScroll={handleScroll}>
      <SAStack direction="row" gap={2} alignItems="center">
        <NotificationsActiveIcon sx={{ color: "gray.light300" }} />
        <SATypography variant="h5" fontWeight="bold" color="gray.light300">
          {t("notifications")}
        </SATypography>
        <CloseArrowButton dir={dir} onClick={onClose}>
          {dir === "rtl" ? (
            <WestIcon fontSize="medium" />
          ) : (
            <EastIcon fontSize="medium" />
          )}
        </CloseArrowButton>
      </SAStack>
      <NotificationList dir={dir}>
        {notifications?.map((notification) => {
          const {
            id,
            title,
            message,
            object_id,
            created_at,
            notification_type,
          } = notification || {};
          return (
            <ListItem
              key={id}
              onClick={() =>
                handleNotificationClick({
                  id: object_id,
                  type: notification_type,
                })
              }
            >
              <Avatar
                variant="circular"
                sx={{ bgcolor: "#dfe9f8", width: 40, height: 40 }}
              >
                {moduleIconMap[notificationModuleMap[notification_type]] || (
                  <InfoOutlineIcon sx={{ color: "primary.main" }} />
                )}
              </Avatar>
              <SABox
                flex={1}
                sx={{ ...(dir === "rtl" ? { textAlign: "right" } : {}) }}
              >
                <SATypography
                  fontWeight="bold"
                  variant="subtitle1"
                  color="text.primary"
                >
                  {title}
                </SATypography>
                <SATypography
                  mt={0.5}
                  variant="body2"
                  color="gray.light300"
                  lineHeight={1.5}
                  fontWeight={500}
                >
                  <SATruncateWithEllipsis text={message} maxLength={80} />
                </SATypography>
                <SATypography
                  mt={1}
                  variant="caption"
                  color="black.light"
                  fontStyle="italic"
                >
                  {formatTimestamp(created_at)}
                </SATypography>
              </SABox>
              <CloseBtn onClick={(e) => handleRemove(e, id)} dir={dir}>
                <CloseIcon fontSize="small" sx={{ color: "black.light" }} />
              </CloseBtn>
            </ListItem>
          );
        })}
      </NotificationList>
      {performanceLoader && (
        <SABox display="flex" justifyContent="center" py={2} dir={dir}>
          <SALoader />
        </SABox>
      )}
    </NotificationPanel>
  );
};

export default NotificationDrawer;
