import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import { Badge, Drawer, IconButton } from "@mui/material";
import { useState } from "react";
import { Link } from "react-router-dom";

import Logo from "../../../assets/images/brand-logo.png";
import useI18N from "../../../hooks/useI18N";
import { Collapse } from "../../../shared/icon";
import LanguageSelect from "../../../shared/LanguageSelect";
import { MUIStyled } from "../../../shared/MUIStyled";
import SAStack from "../../../shared/SAStack";
import LivePrices from "./LivePrices";
import NotificationDrawer from "./NotificationDrawer";
const HeaderWrapper = MUIStyled(SAStack)(({ dir, theme }) => ({
  position: "fixed",
  left: 0,
  right: 0,
  top: 0,
  padding: dir === "rtl" ? "8px 10px 8px 20px" : "8px 20px 8px 10px",
  alignItems: "center",
  backgroundColor: theme.palette.white.main,
  zIndex: 9,
}));

const LiveNews = MUIStyled(SAStack)(() => ({
  flex: 1,
  overflow: "hidden",
  alignItems: "center",
}));

const News = MUIStyled(SAStack)(() => ({
  "& .swiper-wrapper": { transitionTimingFunction: "linear" },
}));

const LogoWrapper = MUIStyled(SAStack)(({ collapse, theme }) => ({
  minWidth: collapse ? 40 : 240,
  [theme.breakpoints.down("md")]: { minWidth: "auto" },
  "& a": {
    "& img": { display: "block" },
    [theme.breakpoints.down("md")]: { display: "none" },
  },
}));

const Header = ({ collapse, toggleCollapse }) => {
  const { t, dir } = useI18N();
  const [openDrawer, setOpenDrawer] = useState(false);

  const toggleDrawer = (newOpen) => () => setOpenDrawer(newOpen);

  return (
    <HeaderWrapper dir={dir} collapse={collapse} direction="row" gap={2}>
      <LogoWrapper
        collapse={collapse}
        alignItems="center"
        justifyContent="space-between"
        direction={collapse ? "column" : "row"}
      >
        {!collapse && (
          <Link to="/businesses">
            <img src={Logo} alt="logo" />
          </Link>
        )}
        <IconButton color="primary" onClick={toggleCollapse}>
          <Collapse />
        </IconButton>
      </LogoWrapper>
      <LiveNews direction="row">
        <News dir={dir} overflow="hidden" direction="row" flex={1}>
          <LivePrices {...{ t, dir }} />
        </News>
      </LiveNews>
      <LanguageSelect />
      <Badge onClick={toggleDrawer(true)} color="error">
        <NotificationsNoneIcon sx={{ "&:hover": { cursor: "pointer" } }} />
      </Badge>
      <Drawer
        open={openDrawer}
        onClose={toggleDrawer(false)}
        anchor={dir === "rtl" ? "left" : "right"}
        sx={{
          "& .MuiDrawer-paper": {
            width: "100%",
            maxWidth: 450,
            background: "#f9f9f9",
          },
        }}
      >
        <NotificationDrawer onClose={toggleDrawer(false)} />
      </Drawer>
    </HeaderWrapper>
  );
};

export default Header;
