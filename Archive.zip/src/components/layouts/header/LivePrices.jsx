import getSymbolFromCurrency from "currency-symbol-map";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { io } from "socket.io-client";
import { Autoplay } from "swiper/modules";
import { SwiperSlide } from "swiper/react";

import { setLoader } from "../../../redux/slices/loader.slices";
import { MUIStyled } from "../../../shared/MUIStyled";
import SAStack from "../../../shared/SAStack";
import SATypography from "../../../shared/SATypography";
import SwiperSlider from "../../../shared/SwiperSlider";

const PriceBar = MUIStyled(SAStack)(({ dir }) => ({
  "& .swiper-wrapper": { transitionTimingFunction: "linear" },
  "& .swiper": {
    "&:first-child": { display: dir === "rtl" ? "none" : "" },
    "&.swiper-rtl": { display: dir === "rtl" ? "" : "none" },
  },
}));

const LivePrices = ({ t, dir }) => {
  const dispatch = useDispatch();
  const [metals, setMetals] = useState({});

  const session = useSelector((state) => state.userProfile?.session);

  const bahrainDinarRate = session?.organization_currency?.find(
    ({ currency_code }) => currency_code === "BHD",
  )?.rate;

  useEffect(() => {
    const socket = io(process.env.REACT_APP_SOCKET_URL);
    socket.on("connect", () => dispatch(setLoader({ name: "live-price" })));
    socket.on("get_metals_live_price", (data) => {
      setMetals(data);
      dispatch(setLoader({ name: "live-price" }));
    });
    return () => socket.disconnect();
  }, []);

  const options = {
    autoplay: { delay: 0, pauseOnMouseEnter: true },
    speed: 2000,
    loop: true,
    spaceBetween: 10,
    slidesPerView: 6,
    modules: [Autoplay],
    breakpoints: {
      0: { slidesPerView: 1 },
      767: { slidesPerView: 1.5 },
      991: { slidesPerView: 2 },
      1199: { slidesPerView: 3 },
      1280: { slidesPerView: 3.5 },
      1480: { slidesPerView: 4.5 },
      1640: { slidesPerView: 6 },
    },
  };

  const renderPriceSlides = (priceType) => {
    return Object.entries(metals)?.map(([metal, details]) => {
      return (
        <SwiperSlide key={`${metal}-${priceType}`}>
          <SAStack
            px={2}
            py={1}
            mx="auto"
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            borderRadius={2}
            border="1px solid #d1d1e0"
          >
            <SATypography
              variant="body1"
              fontSize={14}
              fontWeight={550}
              color="#3d3d5e"
              sx={{ textTransform: "capitalize" }}
            >
              {t(metal)} {priceType?.replace("price_", "").toUpperCase()}
            </SATypography>
            <SATypography variant="body1" fontWeight={700} color="#027A48">
              {(details[priceType] * (bahrainDinarRate || 1)).toFixed(2)}{" "}
              {getSymbolFromCurrency(bahrainDinarRate ? "BHD" : "USD")}
            </SATypography>
          </SAStack>
        </SwiperSlide>
      );
    });
  };

  return (
    <PriceBar dir={dir} overflow="hidden" direction="row" flex={1}>
      <SwiperSlider {...options}>
        {Object.keys(metals)?.length > 0 && (
          <>
            {renderPriceSlides("price_24k")}
            {renderPriceSlides("price_22k")}
            {renderPriceSlides("price_20k")}
            {renderPriceSlides("price_18k")}
          </>
        )}
      </SwiperSlider>
      <SwiperSlider dir="rtl" {...options}>
        {Object.keys(metals)?.length > 0 && (
          <>
            {renderPriceSlides("price_24k")}
            {renderPriceSlides("price_22k")}
            {renderPriceSlides("price_20k")}
            {renderPriceSlides("price_18k")}
          </>
        )}
      </SwiperSlider>
    </PriceBar>
  );
};

export default LivePrices;
