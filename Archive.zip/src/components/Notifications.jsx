import CloseIcon from "@mui/icons-material/Close";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import { Fade, IconButton, Snackbar, Typography } from "@mui/material";
import { useEffect, useState } from "react";

import SABox from "../shared/SABox";
import SAStack from "../shared/SAStack";
import { getNotifications } from "../utils/functions";

const Notifications = () => {
  const [notification, setNotification] = useState(null);
  const [showNotification, setShowNotification] = useState(true);

  useEffect(() => {
    const notificationUrl = `${process.env.REACT_APP_WEB_SOCKET_URL}notifications/?token=${localStorage.getItem("accessToken")}`;
    const socket = new WebSocket(notificationUrl);

    socket.onopen = () => {};

    socket.onmessage = (event) => {
      setNotification(JSON.parse(event.data));
      setShowNotification(true);
      getNotifications();
    };

    socket.onerror = (error) => {
      // eslint-disable-next-line no-console
      console.error("WebSocket error:", error);
    };

    return () => socket.close();
  }, []);

  const handleClose = () => setShowNotification(false);

  if (!notification) return <></>;

  return (
    <Snackbar
      onClose={handleClose}
      open={showNotification}
      autoHideDuration={5000}
      anchorOrigin={{ vertical: "top", horizontal: "right" }}
      TransitionComponent={Fade}
    >
      <SABox
        sx={{
          background: "#fdfdfd",
          border: "1px solid #e0dacb",
          borderColor: "grey.300",
          borderRadius: "12px",
          boxShadow: "0px 8px 20px #78725e33",
          py: 2,
          px: 2.5,
          minWidth: 340,
          maxWidth: 400,
          display: "flex",
          flexDirection: "column",
          gap: 0.5,
        }}
      >
        <SABox display="flex" justifyContent="space-between" alignItems="start">
          <SAStack gap={0.5}>
            <SAStack direction="row" alignItems="center" gap={1}>
              <ErrorOutlineIcon sx={{ color: "#24344e" }} />
              <Typography
                fontWeight={600}
                variant="subtitle1"
                sx={{ color: "#24344e", fontSize: "1.125rem" }}
              >
                {notification?.data?.title}
              </Typography>
            </SAStack>
            <Typography
              variant="body2"
              sx={{ color: "primary.main", fontSize: "0.90rem", mt: 0.5 }}
            >
              {notification?.data?.body}
            </Typography>
          </SAStack>
          <IconButton
            onClick={handleClose}
            size="small"
            sx={{
              ml: 1,
              mt: "-4px",
              color: "#24344e",
              "&:hover": { color: "#374151" },
            }}
          >
            <CloseIcon fontSize="small" />
          </IconButton>
        </SABox>
      </SABox>
    </Snackbar>
  );
};

export default Notifications;
