import CheckIcon from "@mui/icons-material/Check";
import CloseIcon from "@mui/icons-material/Close";
import { useState } from "react";
import { useForm } from "react-hook-form";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  confirmationModalFields as fields,
  loaderPath,
} from "../../descriptions/bankTransfer.description";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import MUIModal from "../../shared/MUIModal";
import { MUIStyled } from "../../shared/MUIStyled";
import SABox from "../../shared/SABox";
import SAButton from "../../shared/SAButton";
import SAForm from "../../shared/SAForm";
import SAFormFields from "../../shared/SAFormFields";
import SAStack from "../../shared/SAStack";

const StyledForm = MUIStyled(SAForm)(() => ({
  width: "100%",
  "& .MuiInputBase-input": { padding: 8 },
  "& .formFields": { maxHeight: "44vh", overflow: "auto" },
}));

const RequestConfirmation = ({
  status,
  loading,
  requestId,
  onConfirmation,
}) => {
  const { t } = useI18N();
  const { api } = useAPI();

  const [confirmationModal, setConfirmationModal] = useState(false);
  const [confirmationAction, setConfirmationAction] = useState("");

  const { register, handleSubmit, formState, control, reset } = useForm({
    mode: "onChange",
    defaultValues: { remark: "" },
  });

  const onSubmit = async (formData) => {
    if (!requestId || !confirmationAction) return;

    const remark = formData?.remark?.trim();

    const response = await api({
      method: httpMethods.patch,
      endPoint: apiEndpoints.bankTransferRequestConfirmation(requestId),
      data: { status: confirmationAction, ...(remark ? { remark } : {}) },
      needLoader: true,
      loader: loaderPath.confirmBankTransferRequest,
      showToastMessage: true,
    });

    if (response?.status) {
      handleCloseModal();
      onConfirmation();
    }
  };

  const handleConfirmation = (action) => {
    setConfirmationModal(true);
    setConfirmationAction(action);
  };

  const handleCloseModal = () => {
    reset({ remark: "" });
    setConfirmationAction("");
    setConfirmationModal(false);
  };

  const buttonConfig = [
    {
      label: t("approve"),
      icon: <CheckIcon />,
      color: "success",
      action: "APPROVED",
      variant: "contained",
    },
    {
      label: t("reject"),
      icon: <CloseIcon />,
      color: "error",
      action: "REJECTED",
      variant: "outlined",
    },
  ];

  return (
    <>
      <SAStack gap={1} direction="row">
        {buttonConfig.map(({ label, icon, action, color, variant }) => (
          <SAButton
            key={action}
            size="small"
            color={color}
            variant={variant}
            disabled={status !== "PENDING"}
            onClick={() => handleConfirmation(action)}
            sx={{ "& svg": { mr: 1, height: 18, width: 18 } }}
          >
            {icon} {label}
          </SAButton>
        ))}
      </SAStack>
      <MUIModal
        open={confirmationModal}
        maxWidth="xs"
        handleClose={handleCloseModal}
        title={t("bank-transfer-confirmation")}
        titleSx={{ textAlign: "center" }}
        content={
          <SABox p={2}>
            <StyledForm onSubmit={handleSubmit(onSubmit)}>
              <SABox className="formFields">
                <SAFormFields
                  spacing={2}
                  {...{ control, register, formState, fields }}
                />
              </SABox>
              <SAStack direction="row" mt={3} justifyContent="center" gap={2}>
                <SAButton
                  variant="outlined"
                  color="primary"
                  onClick={handleCloseModal}
                >
                  {t("cancel")}
                </SAButton>
                <SAButton
                  type="submit"
                  color="primary"
                  variant="contained"
                  loading={loading}
                >
                  {t(confirmationAction === "APPROVED" ? "approve" : "reject")}
                </SAButton>
              </SAStack>
            </StyledForm>
          </SABox>
        }
      />
    </>
  );
};

export default RequestConfirmation;
