import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { Outlet, useParams } from "react-router-dom";

import { TABLE_RECORD_PER_PAGE } from "../../constants";
import {
  bankTransferFilterFields,
  defaultBankTransferFilterValues,
} from "../../descriptions/bankTransfer.description";
import useDebounce from "../../hooks/useDebounce";
import useI18N from "../../hooks/useI18N";
import usePagination from "../../hooks/usePagination";
import { Search } from "../../shared/icon";
import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import { MUIStyled } from "../../shared/MUIStyled";
import SACard from "../../shared/SACard";
import SAFilterMenu from "../../shared/SAFilterMenu";
import SAStack from "../../shared/SAStack";
import SATextField from "../../shared/SATextField";
import theme from "../../themes/theme";
import { compareAmounts, compareDates } from "../../utils/functions";
import showToast from "../../utils/toast";
import BankTransferTable from "./BankTransferTable";

const SearchWrapper = MUIStyled(SAStack)(() => ({
  maxWidth: 400,
  width: "100%",
}));

const BankTransfer = () => {
  const { t } = useI18N();
  const { bankTransferId } = useParams();

  const [anchorEl, setAnchorEl] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [submitFilterData, setSubmitFilterData] = useState({});
  const [filterData, setFilterData] = useState({
    ...defaultBankTransferFilterValues,
  });

  const bankTransferRequests = useSelector(
    (state) => state.bankTransferRequests?.bankTransferRequests,
  );

  const {
    totalPage,
    itemPerPage,
    currentPage,
    setItemPerPage,
    setCurrentPage,
  } = usePagination(bankTransferRequests?.count, TABLE_RECORD_PER_PAGE);

  const debouncedSearch = useDebounce(searchTerm, 300, () => setCurrentPage(1));

  const {
    register,
    handleSubmit,
    formState,
    control,
    reset,
    getValues,
    watch,
    setValue,
  } = useForm({
    mode: "onChange",
    defaultValues: filterData,
  });

  const open = Boolean(anchorEl);
  const watchFields = watch();

  const breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: "bank-transfer-requests" },
  ];

  const useFormControls = {
    reset,
    control,
    register,
    formState,
    getValues,
    watchFields,
    handleSubmit,
  };

  const paginationProps = {
    currentPage,
    setItemPerPage,
    setCurrentPage,
    page: totalPage,
    rowsPerPage: itemPerPage,
  };

  useEffect(() => {
    if (open) {
      Object.keys(filterData)?.forEach((i) => setValue(i, filterData[i]));
    }
  }, [open]);

  const handleClose = () => setAnchorEl(null);
  const handleClick = (e) => setAnchorEl(e.currentTarget);

  const handleFilterSubmit = (formData) => {
    try {
      const { min_amount, max_amount, start_date, end_date } = formData;

      compareAmounts({
        min_amount,
        max_amount,
        min_amount_field: "Min Amount",
        max_amount_field: "Max Amount",
        errorMessage: "min-amount-should-be-less-than-max-amount",
      });

      compareDates({
        start_date,
        end_date,
        start_date_field: "Start Date",
        end_date_field: "End Date",
        errorMessage: "start-date-should-be-less-than-end-date",
      });

      handleClose();
      setCurrentPage(1);
      setSubmitFilterData(formData);
    } catch (error) {
      showToast(error);
    }
  };

  if (bankTransferId) return <Outlet />;

  return (
    <>
      <SAStack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        mb={3}
      >
        <SAStack>
          <MUIBreadcrumbs breadcrumbsData={breadcrumbsData} />
        </SAStack>
      </SAStack>
      <SACard>
        <SAStack
          pb={2}
          mb={2}
          gap={3}
          direction="row"
          flexWrap="wrap"
          alignItems="center"
          justifyContent="space-between"
          borderBottom={`1px solid ${theme.palette.gray.main}50`}
        >
          <SearchWrapper>
            <SATextField
              placeholder={t("search-for-business-name")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{ startAdornment: <Search /> }}
            />
          </SearchWrapper>
          <SAFilterMenu
            t={t}
            open={open}
            anchorEl={anchorEl}
            handleClose={handleClose}
            onSubmit={handleFilterSubmit}
            handleClick={handleClick}
            setFilterData={setFilterData}
            useFormControls={useFormControls}
            filterFields={bankTransferFilterFields}
            setSubmitFilterData={setSubmitFilterData}
            defaultFilterValues={defaultBankTransferFilterValues}
          />
        </SAStack>
        <BankTransferTable
          searchQuery={debouncedSearch}
          paginationProps={paginationProps}
          submitFilterData={submitFilterData}
          bankTransferData={bankTransferRequests?.results || []}
        />
      </SACard>
    </>
  );
};

export default BankTransfer;
