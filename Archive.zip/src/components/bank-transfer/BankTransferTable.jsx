import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import { BUSINESS } from "../../constants";
import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  bankTransferTableColumns,
  loaderPath,
} from "../../descriptions/bankTransfer.description";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import {
  addBankTransferRequests,
  isRefreshList,
} from "../../redux/slices/bankTransferRequests.slices";
import { Eye } from "../../shared/icon";
import SABasicTable from "../../shared/SABasicTable";
import SAButton from "../../shared/SAButton";
import SAStatusBadge from "../../shared/SAStatusBadge";
import SATypography from "../../shared/SATypography";
import {
  convertDatesToTimestampsInObject,
  formatAmount,
  formatTimestamp,
  validTableValue,
} from "../../utils/functions";
import RequestConfirmation from "./RequestConfirmation";

const BankTransferTable = ({
  searchQuery,
  paginationProps,
  submitFilterData,
  bankTransferData,
}) => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const refreshList = useSelector(
    (state) => state.bankTransferRequests?.refreshList,
  );

  const loading = useSelector((state) => ({
    bankTransferRequests: state.loader?.[loaderPath.bankTransferRequests],
    confirmBankTransferRequest:
      state.loader?.[loaderPath.confirmBankTransferRequest],
  }));

  const { currentPage, rowsPerPage, setCurrentPage } = paginationProps;

  useEffect(() => {
    callBankTransferRequests();
  }, [currentPage, rowsPerPage, searchQuery, submitFilterData]);

  useEffect(() => {
    if (refreshList) {
      setCurrentPage(1);
      dispatch(isRefreshList(false));
      getBankTransferRequests({ page: 1, page_size: rowsPerPage });
    }
  }, [refreshList]);

  const handleNavigation = (ownerId, businessId) => {
    navigate(`/businesses/${businessId}`, { state: { ownerId } });
  };

  const getBankTransferRequests = async ({
    page,
    page_size,
    business_name = "",
    submitFilterData,
  } = {}) => {
    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints.getTransactions}`,
      needLoader: true,
      loader: loaderPath.bankTransferRequests,
      showToastOnError: true,
      params: {
        page,
        page_size,
        business_name,
        transfer_via: "ORGANIZATION_ADMIN",
        ...convertDatesToTimestampsInObject(submitFilterData, [
          "end_date",
          "start_date",
        ]),
      },
    });

    if (response?.status)
      dispatch(addBankTransferRequests({ data: response?.data }));
  };

  const handleView = (id) => navigate(`${id}`);

  const callBankTransferRequests = () => {
    getBankTransferRequests({
      page: currentPage,
      page_size: rowsPerPage,
      business_name: searchQuery,
      submitFilterData: submitFilterData,
    });
  };

  const renderCell = (columnKey, data, _, value) => {
    const { id, status, from_business } = data || {};
    const isFromBusiness = from_business?.owner?.user_type === BUSINESS;

    switch (columnKey) {
      case "request_type":
        return (
          <SAStatusBadge status={validTableValue(data?.transaction_type)} />
        );

      case "requested_from":
        return (
          <SATypography
            onClick={() =>
              handleNavigation(from_business?.owner?.id, from_business?.id)
            }
            sx={{
              textDecoration: "none",
              color: "grey.900",
              fontWeight: 500,
              display: "flex",
              alignItems: "center",
              gap: 0.5,
              "&:hover": {
                color: "primary.main",
                textDecoration: "underline",
                textUnderlineOffset: 2,
              },
            }}
          >
            <SATypography variant="body2" fontWeight={600}>
              {isFromBusiness
                ? validTableValue(from_business?.name, false)
                : validTableValue(from_business?.owner?.name, false)}
            </SATypography>
            <SATypography
              component="span"
              variant="caption"
              fontWeight={550}
              color="grey.600"
              sx={{ ml: 0.5 }}
            >
              {`(${t(from_business?.business_account_type)})`}
            </SATypography>
          </SATypography>
        );

      case "amount":
        return (
          <SATypography
            variant="body2"
            fontWeight={600}
            color={"#027A48"}
            sx={{
              padding: "6px 12px",
              borderRadius: "6px",
              display: "inline-block",
            }}
          >
            {`${formatAmount(value)}`}
          </SATypography>
        );

      case "status":
        return (
          <SAStatusBadge
            status={validTableValue(value === "FAILED" ? "REJECTED" : value)}
          />
        );

      case "created_at":
        return (
          <SATypography
            variant="body2"
            fontWeight={500}
            sx={{
              padding: "4px 8px",
              borderRadius: "6px",
              backgroundColor: "#F3F4F6",
              color: "#374151",
              display: "inline-block",
              fontSize: "0.875rem",
            }}
          >
            {value ? formatTimestamp(value) : "-"}
          </SATypography>
        );

      case "confirmation":
        return (
          <RequestConfirmation
            requestId={id}
            status={status}
            onConfirmation={callBankTransferRequests}
            loading={loading.confirmBankTransferRequest}
          />
        );

      case "action":
        return (
          <SAButton
            size="small"
            variant="outlined"
            onClick={() => handleView(id)}
            sx={{
              px: 2,
              textTransform: "none",
              borderRadius: 2,
              borderColor: "grey.400",
              color: "grey.700",
              "& svg": { ml: 1 },
              "&:hover": {
                backgroundColor: "grey.100",
                borderColor: "grey.600",
              },
            }}
          >
            {t("view")} <Eye />
          </SAButton>
        );

      default:
        return data[columnKey];
    }
  };

  return (
    <SABasicTable
      {...{
        renderCell,
        paginationProps,
        data: bankTransferData || [],
        columns: bankTransferTableColumns,
        loading: loading?.bankTransferRequests,
      }}
    />
  );
};

export default BankTransferTable;
