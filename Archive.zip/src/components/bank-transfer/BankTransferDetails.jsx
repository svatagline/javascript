import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";

import { BUSINESS } from "../../constants";
import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import { loaderPath } from "../../descriptions/bankTransfer.description";
import useAPI from "../../hooks/useAPI";
import { Amount, Date, Details, TransactionLight } from "../../shared/icon";
import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import SAShowDetails from "../../shared/SAShowDetails";
import SAStack from "../../shared/SAStack";
import SAStatusBadge from "../../shared/SAStatusBadge";
import SATruncateWithEllipsis from "../../shared/SATruncateWithEllipsis";
import SATypography from "../../shared/SATypography";
import { formatAmount, formatTimestamp } from "../../utils/functions";

const badgeVariant = {
  FAILED: "warning",
  PENDING: "primary",
  SUCCESS: "success",
};

const BankTransferDetails = () => {
  const { api } = useAPI();
  const navigate = useNavigate();
  const { bankTransferId } = useParams();

  const [bankTransferDetails, setBankTransferDetails] = useState({});
  const [isTransferDetailsExist, setIsTransferDetailsExist] = useState(false);

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.bankTransferDetails],
  );

  const breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: "bank-transfer-requests", href: "/bank-transfer-requests" },
    { label: bankTransferId, noTranslate: true },
  ];

  const isFromBusiness =
    bankTransferDetails?.from_business?.owner?.user_type === BUSINESS;

  useEffect(() => {
    getBankTransferDetails();
  }, [bankTransferId]);

  const getBankTransferDetails = async () => {
    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints.getTransaction}${bankTransferId}/`,
      needLoader: true,
      loader: loaderPath.bankTransferDetails,
      showToastOnError: true,
    });

    if (response?.status) setBankTransferDetails(response?.data);
    setIsTransferDetailsExist(!!response?.status);
  };

  const handleNavigation = (ownerId, businessId) => {
    navigate(`/businesses/${businessId}`, { state: { ownerId } });
  };

  const detailObject = {
    loading,
    dataExist: isTransferDetailsExist,
    images: bankTransferDetails?.attachments,
    mainDetail: {
      images: bankTransferDetails?.attachments,
      badge: {
        title:
          bankTransferDetails?.status?.toUpperCase() === "FAILED"
            ? "REJECTED"
            : bankTransferDetails?.status?.toUpperCase(),
        variant: badgeVariant[bankTransferDetails?.status],
      },
      data: [
        {
          label: "",
          key: "amount",
          icon: <Amount />,
          value: (
            <SATypography
              variant="body2"
              fontWeight={600}
              fontSize={16}
              color={"#027A48"}
            >
              {formatAmount(bankTransferDetails?.amount, false)}
            </SATypography>
          ),
          isSeparated: true,
        },
        {
          label: "",
          key: "transaction-type",
          icon: <TransactionLight {...{ fill: "white" }} />,
          value: (
            <SAStatusBadge status={bankTransferDetails?.transaction_type} />
          ),
          isSeparated: true,
        },
        {
          label: "",
          key: "created-at",
          icon: <Date {...{ fill: "white" }} />,
          value: (
            <SATypography
              variant="body2"
              fontWeight={500}
              sx={{
                padding: "4px 8px",
                borderRadius: "6px",
                backgroundColor: "#F3F4F6",
                color: "#374151",
                display: "inline-block",
                fontSize: "0.875rem",
              }}
            >
              {bankTransferDetails?.created_at
                ? formatTimestamp(bankTransferDetails?.created_at)
                : ""}
            </SATypography>
          ),
          isSeparated: true,
        },
        {
          key: "notes",
          value: (
            <SATruncateWithEllipsis
              maxLength={30}
              text={bankTransferDetails?.notes}
            />
          ),
          label: "",
          icon: <Details />,
          isSeparated: true,
        },
        {
          key: "admin-remark",
          value: (
            <SATruncateWithEllipsis
              maxLength={30}
              text={bankTransferDetails?.remark}
            />
          ),
          label: "",
          icon: <Details />,
          isSeparated: true,
        },
      ],
    },
    otherDetails: [
      {
        division: 1,
        list: [
          {
            title: "request-details",
            details: [
              {
                title: "name",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={600}
                    sx={{
                      cursor: "pointer",
                      textDecoration: "underline",
                      textUnderlineOffset: "3px",
                      "&:hover": { textDecoration: "none" },
                    }}
                    onClick={() =>
                      handleNavigation(
                        bankTransferDetails?.from_business?.owner?.id,
                        bankTransferDetails?.from_business?.id,
                      )
                    }
                  >
                    {isFromBusiness
                      ? bankTransferDetails?.from_business?.name
                      : bankTransferDetails?.from_business?.owner?.name}
                  </SATypography>
                ),
                isSeparated: true,
              },
              {
                title: "account-type",
                value: (
                  <SAStatusBadge
                    status={bankTransferDetails?.from_business?.business_account_type?.toUpperCase()}
                  />
                ),
                isSeparated: true,
              },
              {
                title: "owner-name",
                value: bankTransferDetails?.from_business?.owner?.name,
              },
              {
                title: "owner-email",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={500}
                    color="primary.main"
                    sx={{
                      padding: "4px 8px",
                      borderRadius: "6px",
                      backgroundColor: "#EEF2FF",
                      display: "inline-block",
                      fontSize: "0.875rem",
                    }}
                  >
                    {bankTransferDetails?.from_business?.owner?.email}
                  </SATypography>
                ),
                isSeparated: true,
              },
              {
                title: "phone-number",
                value: bankTransferDetails?.from_business?.owner?.phone_number,
              },
            ],
          },
        ],
      },
    ],
  };

  return (
    <>
      <SAStack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        mb={3}
      >
        <SAStack>
          <MUIBreadcrumbs breadcrumbsData={breadcrumbsData} />
        </SAStack>
      </SAStack>
      <SAShowDetails detailObject={detailObject} />
    </>
  );
};

export default BankTransferDetails;
