import useI18N from "../hooks/useI18N";
import SATypography from "../shared/SATypography";

const NotFound = () => {
  const { t } = useI18N();
  return <SATypography variant="h3">{t("not-found")}</SATypography>;
};

export default NotFound;
