import currencyCodes from "currency-codes";
import getSymbolFromCurrency from "currency-symbol-map";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import { TABLE_RECORD_PER_PAGE } from "../../constants";
import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  columns,
  loaderPath,
} from "../../descriptions/settings/generalSettings.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import usePagination from "../../hooks/usePagination";
import { addCurrencyData } from "../../redux/slices/settings.slices";
import { Edit2 } from "../../shared/icon";
import SABasicTable from "../../shared/SABasicTable";
import SAButton from "../../shared/SAButton";
import SAStack from "../../shared/SAStack";
import SATypography from "../../shared/SATypography";
import AddCurrency from "./AddCurrency";

const CurrencyTable = ({ addCurrency, setAddCurrency }) => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();

  const currencies = useSelector((state) => state.settings?.currencyData);
  const loading = useSelector((state) => state.loader?.[loaderPath.currency]);

  const { count, results: currencyData } = currencies;

  const {
    totalPage,
    itemPerPage,
    currentPage,
    setCurrentPage,
    setItemPerPage,
  } = usePagination(count, TABLE_RECORD_PER_PAGE);

  const [editCurrency, setEditCurrency] = useState(null);

  const getCurrencyData = async ({ page, page_size } = {}) => {
    const response = await api({
      method: httpMethods.get,
      endPoint: apiEndpoints?.organizationCurrency,
      needLoader: true,
      loader: loaderPath.currency,
      showToastOnError: true,
      params: { page, page_size },
    });

    if (response?.status) dispatch(addCurrencyData({ data: response?.data }));
  };

  useEffect(() => {
    getCurrencyData({ page: currentPage, page_size: itemPerPage });
  }, [itemPerPage, currentPage]);

  const handleEdit = (currencyData) => {
    setAddCurrency(true);
    setEditCurrency(currencyData);
  };

  const handleCurrencyAdded = () => {
    setAddCurrency(false);
    setEditCurrency(null);
    getCurrencyData({ page: currentPage, page_size: itemPerPage });
  };

  const renderCell = (columnKey, data) => {
    switch (columnKey) {
      case "currency":
        return (
          <SAStack direction="row" alignItems="center" spacing={1}>
            <SATypography
              variant="body2"
              sx={{
                px: 1,
                py: 0.25,
                borderRadius: 1,
                fontWeight: 500,
                fontSize: "1rem",
                bgcolor: "black.light",
                color: "primary.contrastText",
              }}
            >
              {getSymbolFromCurrency(data?.currency_code)}
            </SATypography>
            <SATypography fontSize={14} fontWeight={550}>
              {data?.currency_code}
            </SATypography>
            <SATypography fontSize={12} fontWeight={500}>
              {`(${currencyCodes.code(data?.currency_code)?.currency})`}
            </SATypography>
          </SAStack>
        );

      case "rate":
        return (
          <SATypography variant="body2" fontWeight={600} color="#027A48">
            {data?.rate}
          </SATypography>
        );

      case "actions":
        return (
          <SAButton
            size="small"
            sx={{ gap: 1 }}
            variant="outlined"
            onClick={() => handleEdit(data)}
          >
            <SATypography variant="body2" lineHeight="normal">
              {t("edit")}
            </SATypography>
            <Edit2 />
          </SAButton>
        );

      default:
        return data[columnKey];
    }
  };

  const paginationProps = {
    currentPage,
    setItemPerPage,
    setCurrentPage,
    page: totalPage,
    rowsPerPage: itemPerPage,
  };

  return (
    <SAStack mt={2} gap={2}>
      <SABasicTable
        {...{
          data: currencyData,
          columns,
          renderCell,
          paginationProps,
          loading,
        }}
      />
      {addCurrency && (
        <AddCurrency
          handleClose={() => {
            setAddCurrency(false);
            setEditCurrency(null);
          }}
          onSuccess={handleCurrencyAdded}
          isEdit={!!editCurrency}
          currencyData={editCurrency}
        />
      )}
    </SAStack>
  );
};

export default CurrencyTable;
