import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import { loaderPath } from "../../descriptions/settings.descriptions";
import {
  defaultValues,
  fields,
} from "../../descriptions/settings/taxSettings.description";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import { addGeneralData } from "../../redux/slices/settings.slices";
import SAButton from "../../shared/SAButton";
import SACard from "../../shared/SACard";
import SAForm from "../../shared/SAForm";
import SAFormFields from "../../shared/SAFormFields";
import SAStack from "../../shared/SAStack";
import SATypography from "../../shared/SATypography";

const TaxSettings = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();

  const [isLoading, setIsLoading] = useState(false);
  const { register, handleSubmit, formState, control, reset } = useForm({
    mode: "onChange",
    defaultValues,
  });

  const { isDirty } = formState;

  const setDataFromResponse = () => {
    reset({
      ...{
        taxes: organizationData?.taxes,
        platform_fee: organizationData?.platform_fee,
        vat: organizationData?.vat,
      },
    });
  };

  useEffect(() => {
    getOrganizationData();
  }, []);

  const organizationData = useSelector(
    (state) => state.settings?.organizationData,
  );

  const getOrganizationData = async () => {
    const response = await api({
      method: httpMethods.get,
      endPoint: apiEndpoints?.organization,
      needLoader: true,
      loader: loaderPath.organization,
      showToastOnError: true,
    });
    if (response?.status) dispatch(addGeneralData({ data: response?.data }));
  };

  useEffect(() => {
    if (organizationData) setDataFromResponse();
  }, [organizationData, reset]);

  const onSubmit = async (data) => {
    setIsLoading(true);
    const response = await api({
      method: httpMethods.patch,
      endPoint: apiEndpoints?.organization,
      needLoader: false,
      showToastMessage: true,
      data,
    });

    if (response?.status) getOrganizationData();
    setIsLoading(false);
  };

  const handleCancel = () => setDataFromResponse();

  return (
    <SAStack>
      <SAStack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        mb={3}
      >
        <SATypography variant="h6">{t("tax-settings")} </SATypography>
      </SAStack>
      <SACard>
        <SAForm onSubmit={handleSubmit(onSubmit)}>
          <SAFormFields
            spacing={2}
            {...{ fields, register, formState, control }}
          />
          <SAStack direction="row" justifyContent="flex-start" spacing={2}>
            <SAButton
              variant="contained"
              color="primary"
              type="submit"
              loading={isLoading}
              disabled={!isDirty || isLoading}
            >
              {t("save-details")}
            </SAButton>

            {isDirty && (
              <SAButton
                variant="outlined"
                color="primary"
                onClick={handleCancel}
              >
                {t("cancel")}
              </SAButton>
            )}
          </SAStack>
        </SAForm>
      </SACard>
    </SAStack>
  );
};

export default TaxSettings;
