import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";

import { httpMethods } from "../../../constants/api.constants";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import MUIModal from "../../../shared/MUIModal";
import SABox from "../../../shared/SABox";
import SAButton from "../../../shared/SAButton";
import SAForm from "../../../shared/SAForm";
import SAFormFields from "../../../shared/SAFormFields";

const AddEditModal = ({
  open,
  onClose,
  onSuccess,
  defaultValues,
  apiConfig,
}) => {
  const { t } = useI18N();
  const { api } = useAPI();
  const isEdit = Boolean(defaultValues?.id);

  const { register, handleSubmit, formState, control, reset } = useForm({
    mode: "onChange",
    defaultValues: { name: "", is_enabled: true },
  });

  useEffect(() => {
    if (open && defaultValues) {
      reset({
        name: defaultValues.name || "",
        is_enabled: defaultValues.is_enabled ?? true,
      });
    }
  }, [defaultValues, open, reset]);

  const loading = useSelector((state) => state.loader?.[apiConfig.loaderKey]);

  const onSubmit = async (formData) => {
    const response = await api({
      method: isEdit ? httpMethods.patch : httpMethods.post,
      endPoint: isEdit
        ? `${apiConfig.endPoint}${defaultValues.id}/`
        : apiConfig.endPoint,
      data: formData,
      needLoader: true,
      loader: apiConfig.loaderKey,
      showToastMessage: true,
    });

    if (response?.status) {
      onSuccess();
      onClose();
    }
  };

  return (
    <MUIModal
      open={open}
      maxWidth="xs"
      handleClose={onClose}
      title={t(apiConfig.titleKey)}
      content={
        <SABox
          py={4}
          px={{ xs: 2, md: 4 }}
          sx={{ backgroundColor: "#fff", borderRadius: 3, boxShadow: 1 }}
        >
          <SAForm onSubmit={handleSubmit(onSubmit)}>
            <SAFormFields
              spacing={3}
              {...{
                fields: apiConfig.fields,
                register,
                formState,
                control,
              }}
            />
            <SABox mt={4} textAlign="center">
              <SAButton
                type="submit"
                color="primary"
                variant="contained"
                loading={loading}
              >
                {t(apiConfig.submitLabelKey)}
              </SAButton>
            </SABox>
          </SAForm>
        </SABox>
      }
    />
  );
};

export default AddEditModal;
