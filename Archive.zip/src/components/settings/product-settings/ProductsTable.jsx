import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import { TABLE_RECORD_PER_PAGE } from "../../../constants";
import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  addProductTypeFields,
  loaderPath,
  productTypeTableColumns,
} from "../../../descriptions/settings.descriptions";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import usePagination from "../../../hooks/usePagination";
import { addProductType } from "../../../redux/slices/settings.slices";
import { Edit } from "../../../shared/icon";
import SABasicTable from "../../../shared/SABasicTable";
import SAButton from "../../../shared/SAButton";
import SACard from "../../../shared/SACard";
import SAStack from "../../../shared/SAStack";
import SAStatusBadge from "../../../shared/SAStatusBadge";
import SATypography from "../../../shared/SATypography";
import AddEditModal from "./AddEditModal";
import AddProductTypeModal from "./AddProductTypeModal";

const ProductsTable = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();

  const [addProductTypes, setAddProductTypes] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [edit, setEdit] = useState(false);

  const loading = useSelector((state) => ({
    getProductType: state.loader?.[loaderPath.getProductType],
    getProductTypeStatus: state.loader?.[loaderPath.getProductTypeStatus],
  }));
  const productTypesList = useSelector((state) => state.settings?.productsList);
  const { count, results: productTypesData } = productTypesList || {};

  const {
    totalPage,
    currentPage,
    itemPerPage,
    setCurrentPage,
    setItemPerPage,
  } = usePagination(count, TABLE_RECORD_PER_PAGE);

  useEffect(() => {
    callProductTypeAPI();
  }, [currentPage, itemPerPage]);

  const getProductTypeList = async ({ page, page_size } = {}) => {
    const response = await api({
      method: httpMethods.get,
      endPoint: apiEndpoints.getProductType,
      needLoader: true,
      loader: loaderPath.getProductType,
      params: { page, page_size },
      showToastOnError: true,
    });

    if (response?.status) {
      dispatch(addProductType({ data: response?.data }));
    }
  };

  const callProductTypeAPI = () => {
    getProductTypeList({ page: currentPage, page_size: itemPerPage });
  };

  const handleStatusChange = async (data) => {
    const { id, is_enabled } = data || {};
    if (!id) return;

    setSelectedProduct(data?.id);

    const response = await api({
      method: httpMethods.patch,
      endPoint: `${apiEndpoints.getProductType}${id}/`,
      data: { is_enabled: !is_enabled },
      needLoader: true,
      loader: loaderPath.getProductTypeStatus,
      showToastMessage: true,
    });

    if (response?.status) callProductTypeAPI();

    setSelectedProduct(null);
  };

  const onCloseModal = () => {
    setAddProductTypes(false);
    setEdit(false);
  };

  const paginationProps = {
    currentPage,
    setItemPerPage,
    setCurrentPage,
    page: totalPage,
    rowsPerPage: itemPerPage,
  };

  const handleEdit = (data) => {
    setSelectedProduct(data);
    setEdit(true);
  };

  const primaryActionStyle = {
    size: "small",
    variant: "outlined",
    sx: { "& svg": { ml: 1 } },
  };

  const renderCell = (columnKey, data) => {
    switch (columnKey) {
      case "name":
        return (
          <SATypography variant="body2" fontWeight={600}>
            {data?.name}
          </SATypography>
        );

      case "status":
        return (
          <SAStatusBadge status={data?.is_enabled ? "ENABLED" : "DISABLED"} />
        );

      case "action":
        return (
          <>
            <SAButton
              size="small"
              variant="outlined"
              onClick={() => handleStatusChange(data)}
              loading={
                selectedProduct === data?.id && loading.getProductTypeStatus
              }
            >
              {t(data?.is_enabled ? "disable" : "enable")}
            </SAButton>
          </>
        );

      case "edit":
        return (
          <SAButton
            size="small"
            variant="outlined"
            onClick={() => handleEdit(data)}
            {...primaryActionStyle}
          >
            {t("edit-button")}
            {<Edit />}
          </SAButton>
        );

      default:
        return data[columnKey];
    }
  };

  return (
    <>
      <SACard>
        <SAStack
          pb={2}
          mb={2}
          alignItems="center"
          direction="row-reverse"
          justifyContent="space-between"
          borderBottom="1px solid gray.main 50"
        >
          <SAButton
            color="primary"
            variant="contained"
            onClick={() => setAddProductTypes(true)}
          >
            {t("add-product-type")}
          </SAButton>

          <SATypography
            variant="body2"
            sx={{ fontWeight: "600", fontSize: "25px", marginLeft: "10px" }}
          >
            {t("product-type-title")}
          </SATypography>
        </SAStack>
        <SABasicTable
          {...{
            renderCell,
            paginationProps,
            data: productTypesData,
            loading: loading.getProductType,
            columns: productTypeTableColumns,
          }}
        />
      </SACard>
      <AddProductTypeModal
        open={addProductTypes}
        onClose={onCloseModal}
        onSuccess={callProductTypeAPI}
      />

      <AddEditModal
        open={edit}
        onClose={onCloseModal}
        onSuccess={callProductTypeAPI}
        defaultValues={selectedProduct}
        apiConfig={{
          endPoint: apiEndpoints.getProductType,
          loaderKey: loaderPath.addEditModal,
          titleKey: edit ? "edit-product-type-title" : "add-product-type-title",
          submitLabelKey: edit ? "save-changes" : "add-product-type",
          fields: addProductTypeFields,
        }}
      />
    </>
  );
};

export default ProductsTable;
