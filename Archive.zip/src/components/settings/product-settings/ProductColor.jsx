import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import { TABLE_RECORD_PER_PAGE } from "../../../constants";
import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  addProductColorFields,
  loaderPath,
  productColorTableColumns,
} from "../../../descriptions/settings.descriptions";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import usePagination from "../../../hooks/usePagination";
import { addProductColor } from "../../../redux/slices/settings.slices";
import { Edit } from "../../../shared/icon";
import SABasicTable from "../../../shared/SABasicTable";
import SAButton from "../../../shared/SAButton";
import SACard from "../../../shared/SACard";
import SAStack from "../../../shared/SAStack";
import SAStatusBadge from "../../../shared/SAStatusBadge";
import SATypography from "../../../shared/SATypography";
import AddEditModal from "./AddEditModal";
import AddProductColorModal from "./AddProductColorModal";

const ProductsColor = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();

  const [addProductColors, setAddProductColors] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [edit, setEdit] = useState(false);

  const loading = useSelector((state) => ({
    getProductColor: state.loader?.[loaderPath.getProductColor],
    getProductColorStatus: state.loader?.[loaderPath.getProductColorStatus],
  }));
  const productColorList = useSelector(
    (state) => state.settings?.productColorList,
  );
  const { count, results: productColorData } = productColorList || {};

  const {
    totalPage,
    currentPage,
    itemPerPage,
    setCurrentPage,
    setItemPerPage,
  } = usePagination(count, TABLE_RECORD_PER_PAGE);

  useEffect(() => {
    callProductTypeAPI();
  }, [currentPage, itemPerPage]);

  const getProductTypeList = async ({ page, page_size } = {}) => {
    const response = await api({
      method: httpMethods.get,
      endPoint: apiEndpoints.getProductColor,
      needLoader: true,
      loader: loaderPath.getProductColor,
      params: { page, page_size },
      showToastOnError: true,
    });

    if (response?.status) {
      dispatch(addProductColor({ data: response?.data }));
    }
  };

  const callProductTypeAPI = () => {
    getProductTypeList({ page: currentPage, page_size: itemPerPage });
  };

  const handleStatusChange = async (data) => {
    const { id, is_enabled } = data || {};
    if (!id) return;

    setSelectedProduct(data?.id);

    const response = await api({
      method: httpMethods.patch,
      endPoint: `${apiEndpoints.getProductColor}${id}/`,
      data: { is_enabled: !is_enabled },
      needLoader: true,
      loader: loaderPath.getProductColorStatus,
      showToastMessage: true,
    });

    if (response?.status) callProductTypeAPI();

    setSelectedProduct(null);
  };

  const onCloseModal = () => {
    setAddProductColors(false);
    setEdit(false);
  };

  const paginationProps = {
    currentPage,
    setItemPerPage,
    setCurrentPage,
    page: totalPage,
    rowsPerPage: itemPerPage,
  };

  const handleEdit = (data) => {
    setSelectedProduct(data);
    setEdit(true);
  };

  const primaryActionStyle = {
    size: "small",
    variant: "outlined",
    sx: { "& svg": { ml: 1 } },
  };

  const renderCell = (columnKey, data) => {
    switch (columnKey) {
      case "name":
        return (
          <SATypography variant="body2" fontWeight={600}>
            {data?.name}
          </SATypography>
        );

      case "status":
        return (
          <SAStatusBadge status={data?.is_enabled ? "ENABLED" : "DISABLED"} />
        );

      case "action":
        return (
          <SAButton
            size="small"
            variant="outlined"
            onClick={() => handleStatusChange(data)}
            loading={
              selectedProduct === data?.id && loading.getProductColorStatus
            }
          >
            {t(data?.is_enabled ? "disable" : "enable")}
          </SAButton>
        );

      case "edit":
        return (
          <SAButton
            size="small"
            variant="outlined"
            onClick={() => handleEdit(data)}
            {...primaryActionStyle}
          >
            {t("edit-button")}
            {<Edit />}
          </SAButton>
        );

      default:
        return data[columnKey];
    }
  };

  return (
    <>
      <SACard>
        <SAStack
          pb={2}
          mb={2}
          alignItems="center"
          direction="row-reverse"
          justifyContent="space-between"
          borderBottom="1px solid gray.main 50"
        >
          <SAButton
            color="primary"
            variant="contained"
            onClick={() => setAddProductColors(true)}
          >
            {t("add-product-color")}
          </SAButton>

          <SATypography
            variant="body2"
            sx={{ fontWeight: "600", fontSize: "25px", marginLeft: "10px" }}
          >
            {t("product-color-title")}
          </SATypography>
        </SAStack>
        <SABasicTable
          {...{
            renderCell,
            paginationProps,
            data: productColorData,
            loading: loading.getProductColor,
            columns: productColorTableColumns,
          }}
        />
      </SACard>
      <AddProductColorModal
        open={addProductColors}
        onClose={onCloseModal}
        onSuccess={callProductTypeAPI}
      />
      <AddEditModal
        open={edit}
        onClose={onCloseModal}
        onSuccess={callProductTypeAPI}
        defaultValues={selectedProduct}
        apiConfig={{
          endPoint: apiEndpoints.getProductColor,
          loaderKey: loaderPath.addEditModal,
          titleKey: edit
            ? "edit-product-color-title"
            : "add-product-color-title",
          submitLabelKey: edit ? "save-changes" : "add-product-color",
          fields: addProductColorFields,
        }}
      />
    </>
  );
};

export default ProductsColor;
