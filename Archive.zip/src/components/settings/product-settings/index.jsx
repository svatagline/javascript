import SABox from "../../../shared/SABox";
import SAStack from "../../../shared/SAStack";
import ProductsColor from "./ProductColor";
import ProductsTable from "./ProductsTable";

const ProductSettings = () => {
  return (
    <>
      <SAStack direction={{ xs: "column", lg: "row" }} gap={2}>
        <SABox sx={{ flex: 1 }}>
          <ProductsTable />
        </SABox>
        <SABox sx={{ flex: 1 }}>
          <ProductsColor />
        </SABox>
      </SAStack>
    </>
  );
};

export default ProductSettings;
