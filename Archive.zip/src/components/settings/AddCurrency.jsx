import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  addCurrencyDefaultValues,
  addCurrencyFields,
  loaderPath,
} from "../../descriptions/settings/generalSettings.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import MUIModal from "../../shared/MUIModal";
import SABox from "../../shared/SABox";
import SAButton from "../../shared/SAButton";
import SAForm from "../../shared/SAForm";
import SAFormFields from "../../shared/SAFormFields";
import SALoader from "../../shared/SALoader";

const Content = ({ handleClose, onSuccess, isEdit, currencyData }) => {
  const { t } = useI18N();
  const { api } = useAPI();

  const defaultValues = isEdit ? { ...currencyData } : addCurrencyDefaultValues;

  const { register, handleSubmit, formState, control } = useForm({
    mode: "onChange",
    defaultValues,
  });

  const loading = useSelector(
    (state) =>
      state.loader?.[loaderPath[isEdit ? "updateCurrency" : "addCurrency"]],
  );

  const onSubmit = async (data) => {
    const method = isEdit ? httpMethods.patch : httpMethods.post;
    const endPoint = isEdit
      ? `${apiEndpoints.organizationCurrency}${currencyData.id}/`
      : apiEndpoints.organizationCurrency;

    const response = await api({
      method,
      endPoint,
      data,
      needLoader: true,
      loader: isEdit ? loaderPath.updateCurrency : loaderPath.addCurrency,
      showToastMessage: true,
    });

    if (response?.status) {
      onSuccess();
      handleClose();
    }
  };

  return (
    <SAForm style={{ padding: "20px" }} onSubmit={handleSubmit(onSubmit)}>
      <SAFormFields
        spacing={2}
        {...{ fields: addCurrencyFields, register, formState, control }}
      />

      <SABox mt={3} textAlign="center">
        <SAButton
          sx={{ borderRadius: "8px", gap: 1 }}
          variant="contained"
          color="primary"
          type="submit"
          disabled={loading}
        >
          {isEdit ? t("update-currency") : t("add-currency")}
          {loading && <SALoader size={17} />}
        </SAButton>
      </SABox>
    </SAForm>
  );
};

const AddCurrency = ({
  handleClose,
  onSuccess,
  isEdit = false,
  currencyData = null,
}) => {
  const { t } = useI18N();
  return (
    <MUIModal
      open={true}
      handleClose={handleClose}
      title={isEdit ? t("update-currency") : t("add-currency")}
      maxWidth={"400px"}
      content={
        <Content
          handleClose={handleClose}
          onSuccess={onSuccess}
          isEdit={isEdit}
          currencyData={currencyData}
        />
      }
    />
  );
};

export default AddCurrency;
