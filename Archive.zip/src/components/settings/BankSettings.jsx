import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  defaultValues,
  fields,
  loaderPath,
} from "../../descriptions/settings/bankSettings.description";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import { addBankData } from "../../redux/slices/settings.slices";
import SAButton from "../../shared/SAButton";
import SACard from "../../shared/SACard";
import SAForm from "../../shared/SAForm";
import SAFormFields from "../../shared/SAFormFields";
import SAStack from "../../shared/SAStack";
import SATypography from "../../shared/SATypography";

const BankSettings = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();
  const { register, handleSubmit, formState, control, reset } = useForm({
    mode: "onChange",
    defaultValues,
  });

  const bankData = useSelector((state) => state.settings?.bankData);
  const loading = useSelector((state) => ({
    addBankSettings: state.loader?.[loaderPath.addBankSettings],
  }));

  useEffect(() => {
    getBankData();
  }, []);

  useEffect(() => {
    if (bankData) populateBankDetails();
  }, [bankData, reset]);

  const populateBankDetails = () => {
    const { account_name, bank_name, account_number, iban_code, swift_code } =
      bankData || {};
    reset({ account_name, bank_name, account_number, iban_code, swift_code });
  };

  const getBankData = async () => {
    const response = await api({
      method: httpMethods.get,
      endPoint: apiEndpoints.organizationBankAccount,
      needLoader: true,
      loader: loaderPath.bankSettings,
      showToastOnError: true,
    });
    if (response?.status) dispatch(addBankData({ data: response?.data }));
  };

  const onSubmit = async (formData) => {
    const response = await api({
      method: httpMethods.patch,
      endPoint: apiEndpoints.organizationBankAccount,
      data: formData,
      needLoader: true,
      loader: loaderPath.addBankSettings,
      showToastMessage: true,
    });
    if (response?.status) getBankData();
  };

  return (
    <SAStack>
      <SAStack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        mb={3}
      >
        <SATypography variant="h6">{t("bank-settings")} </SATypography>
      </SAStack>
      <SACard>
        <SAForm onSubmit={handleSubmit(onSubmit)}>
          <SAFormFields
            spacing={2}
            {...{ fields, register, formState, control }}
          />
          <SAStack direction="row" mt={3} textAlign="center" spacing={1}>
            <SAButton
              variant="contained"
              color="primary"
              type="submit"
              disabled={!formState.isDirty || loaderPath.addBankSettings}
              loading={loading.addBankSettings}
              sx={{ gap: 1 }}
            >
              {loaderPath.addBankSettings ? t("saving") : t("save-details")}
            </SAButton>
            {formState.isDirty && (
              <SAButton
                color="primary"
                variant="outlined"
                onClick={() => populateBankDetails()}
              >
                {t("cancel")}
              </SAButton>
            )}
          </SAStack>
        </SAForm>
      </SACard>
    </SAStack>
  );
};

export default BankSettings;
