import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  defaultValues,
  fields,
  loaderPath,
} from "../../descriptions/settings/generalSettings.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import { addGeneralData } from "../../redux/slices/settings.slices";
import MUIGrid from "../../shared/MUIGrid";
import SAButton from "../../shared/SAButton";
import SACard from "../../shared/SACard";
import SAForm from "../../shared/SAForm";
import SAFormFields from "../../shared/SAFormFields";
import SALoader from "../../shared/SALoader";
import SAStack from "../../shared/SAStack";
import SATypography from "../../shared/SATypography";
import CurrencyTable from "./CurrencyTable";

const GeneralSettings = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();

  const [isLoading, setIsLoading] = useState(false);
  const [addCurrency, setAddCurrency] = useState(false);
  const { register, handleSubmit, formState, control, reset } = useForm({
    mode: "onChange",
    defaultValues,
  });
  const organizationData = useSelector(
    (state) => state.settings?.organizationData,
  );
  const { isDirty } = formState;

  useEffect(() => {
    getOrganizationData();
  }, []);

  const setDataFromResponse = () => {
    reset({
      ...defaultValues,
      ...{
        name: organizationData.name,
        description: organizationData.description,
        country: organizationData.country,
        address: organizationData.address,
      },
    });
  };

  useEffect(() => {
    if (organizationData) setDataFromResponse();
  }, [organizationData, reset]);

  const getOrganizationData = async () => {
    const response = await api({
      method: httpMethods.get,
      endPoint: apiEndpoints?.organization,
      needLoader: true,
      loader: loaderPath.organization,
      showToastOnError: true,
    });

    if (response?.status) dispatch(addGeneralData({ data: response?.data }));
  };

  const onSubmit = async (data) => {
    setIsLoading(true);
    const response = await api({
      method: httpMethods.patch,
      endPoint: apiEndpoints?.organization,
      needLoader: false,
      showToastMessage: true,
      data,
    });

    if (response?.status) getOrganizationData();
    setIsLoading(false);
  };

  const handleCancel = () => {
    setDataFromResponse();
  };

  return (
    <SAStack>
      <SAStack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        mb={2}
      >
        <SATypography variant="h6">{t("general-settings")} </SATypography>
        <SAButton
          color="primary"
          onClick={() => setAddCurrency(true)}
          variant="contained"
        >
          {t("add-currency")}
        </SAButton>
      </SAStack>
      <MUIGrid container columnSpacing={3} gap={3}>
        <MUIGrid size={{ md: 5 }}>
          <SACard>
            <SAForm onSubmit={handleSubmit(onSubmit)}>
              <SAFormFields
                spacing={2}
                {...{ fields, register, formState, control }}
              />
              <SAStack direction="row" mt={3} textAlign="center" spacing={1}>
                <SAButton
                  variant="contained"
                  color="primary"
                  type="submit"
                  disabled={!isDirty || isLoading}
                  sx={{ flex: 1, gap: 1 }}
                >
                  {isLoading ? (
                    <>
                      {t("saving")}
                      <SALoader size={18} />
                    </>
                  ) : (
                    t("save-details")
                  )}
                </SAButton>
                {isDirty && (
                  <SAButton
                    variant="outlined"
                    color="primary"
                    onClick={handleCancel}
                    sx={{ flex: 1 }}
                  >
                    {t("cancel")}
                  </SAButton>
                )}
              </SAStack>
            </SAForm>
          </SACard>
        </MUIGrid>

        <MUIGrid size={{ md: 7 }}>
          <SACard>
            <CurrencyTable {...{ addCurrency, setAddCurrency }} />
          </SACard>
        </MUIGrid>
      </MUIGrid>
    </SAStack>
  );
};

export default GeneralSettings;
