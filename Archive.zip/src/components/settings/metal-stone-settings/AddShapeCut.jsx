import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";

import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  addShapeCutFields,
  loaderPath,
} from "../../../descriptions/settings.descriptions";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import MUIModal from "../../../shared/MUIModal";
import SABox from "../../../shared/SABox";
import SAButton from "../../../shared/SAButton";
import SAForm from "../../../shared/SAForm";
import SAFormFields from "../../../shared/SAFormFields";

const AddShapeCut = ({ open, onClose, onSuccess }) => {
  const { t } = useI18N();
  const { api } = useAPI();

  const { register, handleSubmit, formState, control } = useForm({
    mode: "onChange",
    defaultValues: { name: "" },
  });

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.addShapeCut],
  );

  const onSubmit = async (formData) => {
    const response = await api({
      method: httpMethods.post,
      endPoint: apiEndpoints.getStoneShapeCuts,
      data: formData,
      needLoader: true,
      loader: loaderPath.addShapeCut,
      showToastMessage: true,
    });

    if (response?.status) {
      onSuccess();
      onClose();
    }
  };

  return (
    <MUIModal
      open={open}
      maxWidth="xs"
      handleClose={onClose}
      title={t("add-shape-cut-title")}
      content={
        <SABox
          py={4}
          px={{ xs: 2, md: 4 }}
          sx={{ backgroundColor: "#fff", borderRadius: 3, boxShadow: 1 }}
        >
          <SAForm onSubmit={handleSubmit(onSubmit)}>
            <SAFormFields
              spacing={3}
              {...{ fields: addShapeCutFields, register, formState, control }}
            />
            <SABox mt={4} textAlign="center">
              <SAButton
                type="submit"
                color="primary"
                variant="contained"
                loading={loading}
              >
                {t("add-cut-shape")}
              </SAButton>
            </SABox>
          </SAForm>
        </SABox>
      }
    />
  );
};

export default AddShapeCut;
