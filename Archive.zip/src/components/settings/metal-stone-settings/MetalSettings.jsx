import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  loaderPath,
  metalTableColumns,
} from "../../../descriptions/settings.descriptions";
import useAPI from "../../../hooks/useAPI";
import { addMaterials } from "../../../redux/slices/settings.slices";
import SABox from "../../../shared/SABox";
import SACard from "../../../shared/SACard";
import SAStack from "../../../shared/SAStack";
import MetalCaratTypes from "./MetalCaratTypes";
import MetalsTable from "./MetalsTable";

const MetalSettings = () => {
  const { api } = useAPI();
  const dispatch = useDispatch();

  const materialsList = useSelector((state) => state.settings?.materialsList);

  const { results: materialsData } = materialsList;

  useEffect(() => {
    getMaterialsList();
  }, []);

  const getMaterialsList = async () => {
    const response = await api({
      method: httpMethods.get,
      endPoint: apiEndpoints?.materials,
      needLoader: true,
      loader: loaderPath.materials,
      showToastOnError: true,
      params: {
        material_type: "metal",
      },
    });
    if (response?.status) dispatch(addMaterials({ data: response?.data }));
  };

  const handleStatus = async (material) => {
    const newStatus = !material.is_enabled;
    const response = await api({
      method: httpMethods.patch,
      endPoint: `${apiEndpoints?.material}${material.id}`,
      data: { is_enabled: newStatus },
      needLoader: true,
      loader: loaderPath.materialStatus,
      showToastMessage: true,
    });
    if (response?.status) getMaterialsList();
  };

  return (
    <SAStack direction={{ xs: "column", lg: "row" }} gap={2}>
      <SABox sx={{ flex: { xs: "none", lg: 1.5 } }}>
        <SACard>
          <MetalsTable
            {...{
              materialsData,
              handleStatus,
              columns: metalTableColumns,
            }}
          />
        </SACard>
      </SABox>
      <SABox sx={{ flex: { xs: "none", lg: 1 } }}>
        <MetalCaratTypes />
      </SABox>
    </SAStack>
  );
};

export default MetalSettings;
