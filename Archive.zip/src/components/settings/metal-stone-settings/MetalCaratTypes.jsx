import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import { TABLE_RECORD_PER_PAGE } from "../../../constants";
import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  loaderPath,
  metalCaratTypeTableColumns,
} from "../../../descriptions/settings.descriptions";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import usePagination from "../../../hooks/usePagination";
import { addMetalCaratTypes } from "../../../redux/slices/settings.slices";
import SABasicTable from "../../../shared/SABasicTable";
import SAButton from "../../../shared/SAButton";
import SACard from "../../../shared/SACard";
import SAStack from "../../../shared/SAStack";
import SAStatusBadge from "../../../shared/SAStatusBadge";
import SATypography from "../../../shared/SATypography";
import AddCaratType from "./AddCaratType";

const MetalCaratTypes = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();

  const [addMetalCaratType, setAddMetalCaratType] = useState(false);
  const [selectedCaratType, setSelectedCaratType] = useState(null);

  const loading = useSelector((state) => ({
    metalCaratTypes: state.loader?.[loaderPath.metalCaratTypes],
    metalCaratTypeStatus: state.loader?.[loaderPath.metalCaratTypeStatus],
  }));
  const metalCaratTypesList = useSelector(
    (state) => state.settings?.metalCaratTypesList,
  );
  const { count, results: metalCaratTypesData } = metalCaratTypesList || {};

  const {
    totalPage,
    currentPage,
    itemPerPage,
    setCurrentPage,
    setItemPerPage,
  } = usePagination(count, TABLE_RECORD_PER_PAGE);

  useEffect(() => {
    callMetalCaratTypeAPI();
  }, [currentPage, itemPerPage]);

  const getMetalCaratTypeList = async ({ page, page_size } = {}) => {
    const response = await api({
      method: httpMethods.get,
      endPoint: apiEndpoints.getMetalCaratTypes,
      needLoader: true,
      loader: loaderPath.metalCaratTypes,
      params: { page, page_size },
      showToastOnError: true,
    });

    if (response?.status) {
      dispatch(addMetalCaratTypes({ data: response?.data }));
    }
  };

  const callMetalCaratTypeAPI = () => {
    getMetalCaratTypeList({ page: currentPage, page_size: itemPerPage });
  };

  const handleStatusChange = async (data) => {
    const { id, is_enabled } = data || {};
    if (!id) return;

    setSelectedCaratType(data?.id);

    const response = await api({
      method: httpMethods.patch,
      endPoint: `${apiEndpoints.getMetalCaratTypes}${id}/`,
      data: { is_enabled: !is_enabled },
      needLoader: true,
      loader: loaderPath.metalCaratTypeStatus,
      showToastMessage: true,
    });

    if (response?.status) callMetalCaratTypeAPI();

    setSelectedCaratType(null);
  };

  const onCloseModal = () => setAddMetalCaratType(false);

  const paginationProps = {
    currentPage,
    setItemPerPage,
    setCurrentPage,
    page: totalPage,
    rowsPerPage: itemPerPage,
  };

  const renderCell = (columnKey, data) => {
    switch (columnKey) {
      case "name":
        return (
          <SATypography variant="body2" fontWeight={600}>
            {data?.name}
          </SATypography>
        );

      case "purity":
        return (
          <SATypography variant="body2" fontWeight={600}>
            {data?.purity_percentage}
          </SATypography>
        );

      case "status":
        return (
          <SAStatusBadge status={data?.is_enabled ? "ENABLED" : "DISABLED"} />
        );

      case "action":
        return (
          <SAButton
            size="small"
            variant="outlined"
            onClick={() => handleStatusChange(data)}
            loading={
              selectedCaratType === data?.id && loading.metalCaratTypeStatus
            }
          >
            {t(data?.is_enabled ? "disable" : "enable")}
          </SAButton>
        );

      default:
        return data[columnKey];
    }
  };

  return (
    <>
      <SACard>
        <SAStack
          pb={2}
          mb={2}
          alignItems="center"
          direction="row-reverse"
          justifyContent="space-between"
          borderBottom="1px solid gray.main 50"
        >
          <SAButton
            color="primary"
            variant="contained"
            onClick={() => setAddMetalCaratType(true)}
          >
            {t("add-metal-carat-type")}
          </SAButton>
        </SAStack>
        <SABasicTable
          {...{
            renderCell,
            paginationProps,
            data: metalCaratTypesData,
            loading: loading.metalCaratTypes,
            columns: metalCaratTypeTableColumns,
          }}
        />
      </SACard>
      <AddCaratType
        open={addMetalCaratType}
        onClose={onCloseModal}
        onSuccess={callMetalCaratTypeAPI}
      />
    </>
  );
};

export default MetalCaratTypes;
