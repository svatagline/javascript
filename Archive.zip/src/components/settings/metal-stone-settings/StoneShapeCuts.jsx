import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import { TABLE_RECORD_PER_PAGE } from "../../../constants";
import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  loaderPath,
  shapeCutTableColumns,
} from "../../../descriptions/settings.descriptions";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import usePagination from "../../../hooks/usePagination";
import { addShapeCuts } from "../../../redux/slices/settings.slices";
import SABasicTable from "../../../shared/SABasicTable";
import SAButton from "../../../shared/SAButton";
import SACard from "../../../shared/SACard";
import SAStack from "../../../shared/SAStack";
import SAStatusBadge from "../../../shared/SAStatusBadge";
import SATypography from "../../../shared/SATypography";
import AddShapeCut from "./AddShapeCut";

const StoneShapeCuts = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();

  const [addShapeCut, setAddShapeCut] = useState(false);
  const [selectedShapeCut, setSelectedShapeCut] = useState(null);

  const loading = useSelector((state) => ({
    shapeCuts: state.loader?.[loaderPath.shapeCuts],
    shapeCutStatus: state.loader?.[loaderPath.shapeCutStatus],
  }));
  const shapeCutsList = useSelector((state) => state.settings?.shapeCutsList);
  const { count, results: shapeCutsData } = shapeCutsList || {};

  const {
    totalPage,
    currentPage,
    setCurrentPage,
    itemPerPage,
    setItemPerPage,
  } = usePagination(count, TABLE_RECORD_PER_PAGE);

  useEffect(() => {
    callShapeCutsAPI();
  }, [currentPage, itemPerPage]);

  const getShapeCutsList = async ({ page, page_size } = {}) => {
    const response = await api({
      method: httpMethods.get,
      endPoint: apiEndpoints.getStoneShapeCuts,
      needLoader: true,
      loader: loaderPath.shapeCuts,
      params: { page, page_size },
      showToastOnError: true,
    });

    if (response?.status) dispatch(addShapeCuts({ data: response?.data }));
  };

  const callShapeCutsAPI = () => {
    getShapeCutsList({ page: currentPage, page_size: itemPerPage });
  };

  const handleStatusChange = async (data) => {
    const { id, is_enabled } = data || {};
    if (!id) return;

    setSelectedShapeCut(data?.id);

    const response = await api({
      method: httpMethods.patch,
      endPoint: `${apiEndpoints.getStoneShapeCuts}${id}/`,
      data: { is_enabled: !is_enabled },
      needLoader: true,
      loader: loaderPath.shapeCutStatus,
      showToastMessage: true,
    });

    if (response?.status) callShapeCutsAPI();

    setSelectedShapeCut(null);
  };

  const onCloseModal = () => setAddShapeCut(false);

  const paginationProps = {
    currentPage,
    setItemPerPage,
    setCurrentPage,
    page: totalPage,
    rowsPerPage: itemPerPage,
  };

  const renderCell = (columnKey, data) => {
    switch (columnKey) {
      case "name":
        return (
          <SATypography variant="body2" fontWeight={600}>
            {data?.name}
          </SATypography>
        );

      case "status":
        return (
          <SAStatusBadge status={data?.is_enabled ? "ENABLED" : "DISABLED"} />
        );

      case "action":
        return (
          <SAButton
            size="small"
            variant="outlined"
            onClick={() => handleStatusChange(data)}
            loading={selectedShapeCut === data?.id && loading.shapeCutStatus}
          >
            {t(data?.is_enabled ? "disable" : "enable")}
          </SAButton>
        );

      default:
        return data[columnKey];
    }
  };

  return (
    <>
      <SACard>
        <SAStack
          pb={2}
          mb={2}
          alignItems="center"
          direction="row-reverse"
          justifyContent="space-between"
          borderBottom="1px solid gray.main 50"
        >
          <SAButton
            color="primary"
            variant="contained"
            onClick={() => setAddShapeCut(true)}
          >
            {t("add-cut-shape")}
          </SAButton>
        </SAStack>
        <SABasicTable
          {...{
            renderCell,
            paginationProps,
            data: shapeCutsData,
            loading: loading.shapeCuts,
            columns: shapeCutTableColumns,
          }}
        />
      </SACard>
      <AddShapeCut
        open={addShapeCut}
        onClose={onCloseModal}
        onSuccess={callShapeCutsAPI}
      />
    </>
  );
};

export default StoneShapeCuts;
