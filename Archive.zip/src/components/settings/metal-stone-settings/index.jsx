import useI18N from "../../../hooks/useI18N";
import MUITabs from "../../../shared/MUITabs";
import MetalSettings from "./MetalSettings";
import StoneSettings from "./StoneSettings";

const MetalStoneSettings = () => {
  const { t } = useI18N();

  return (
    <>
      <MUITabs
        tabs={[
          { label: t("metals"), content: <MetalSettings /> },
          { label: t("stones"), content: <StoneSettings /> },
        ]}
      />
    </>
  );
};

export default MetalStoneSettings;
