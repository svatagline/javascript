import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import { Typography } from "@mui/material";
import { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";

import { ORGANIZATION_CODE } from "../../../constants";
import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  addMaterialDefaultValues,
  addMaterialsFields,
  loaderPath,
} from "../../../descriptions/settings.descriptions";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import MUIModal from "../../../shared/MUIModal";
import { MUIStyled } from "../../../shared/MUIStyled";
import SABox from "../../../shared/SABox";
import SAButton from "../../../shared/SAButton";
import SAForm from "../../../shared/SAForm";
import SAFormFields from "../../../shared/SAFormFields";
import SATruncateWithEllipsis from "../../../shared/SATruncateWithEllipsis";
import showToast from "../../../utils/toast";

const IMAGE_CONFIG = {
  maxSize: 5 * 1024 * 1024,
  acceptedTypes: "image/*",
  dimensions: { maxHeight: "200px" },
};

const ImagePreviewContainer = MUIStyled(SABox)(({ theme }) => ({
  position: "relative",
  marginTop: theme.spacing(2),
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  padding: theme.spacing(2),
  border: "1px solid #e0e0e0",
  borderRadius: "12px",
  overflow: "hidden",
  backgroundColor: "#fafafa",
}));

const CrossButton = MUIStyled(SABox)({
  position: "absolute",
  top: "-5px",
  right: "10px",
  padding: "6px",
  borderRadius: "50%",
  fontSize: 26,
  "&:hover": { cursor: "pointer" },
});

const UploadArea = MUIStyled(SABox, {
  shouldForwardProp: (prop) => prop !== "inProgress",
})(({ theme, inProgress }) => ({
  padding: theme.spacing(2),
  marginTop: theme.spacing(3),
  borderRadius: "10px",
  textAlign: "center",
  border: "2px dashed #c4c4c4",
  backgroundColor: "#fafafa",
  cursor: inProgress ? "not-allowed" : "pointer",
  transition: "border 0.3s, background-color 0.3s",
  "&:hover": { borderColor: "#1E40AF", backgroundColor: "#f0f8ff" },
}));

const Content = ({ handleClose, onSuccess }) => {
  const { t } = useI18N();
  const { api } = useAPI();
  const imgRef = useRef();

  const [imagePreview, setImagePreview] = useState(null);
  const [imageError, setImageError] = useState(false);
  const [loadingAWS, setLoadingAWS] = useState(false);

  const defaultValues = addMaterialDefaultValues;

  const { register, handleSubmit, formState, control, setValue, watch } =
    useForm({ mode: "onChange", defaultValues });

  const loading = useSelector((state) => ({
    addMaterial: state.loader?.[loaderPath.addMaterial],
    uploadImage: state.loader?.[loaderPath.uploadImage],
  }));

  useEffect(() => {
    return () => {
      if (imagePreview?.startsWith("blob:")) URL.revokeObjectURL(imagePreview);
    };
  }, [imagePreview]);

  const validateImage = (file) => {
    if (!file) return false;

    const isImage = file.type.startsWith("image/");
    const isValidSize = file.size <= IMAGE_CONFIG.maxSize;

    if (!isImage) showToast("invalid-file-type-error");
    if (!isValidSize) showToast("file-size-exceeded-error");

    return isImage && isValidSize;
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];

    if (!validateImage(file)) {
      event.target.value = null;
      setValue("fileUpload", null);
      setImagePreview(null);
      return;
    }

    setImageError(false);
    setValue("fileUpload", file);
    setImagePreview(URL.createObjectURL(file));
  };

  const uploadImageToS3 = async (file, path) => {
    const payload = {
      bucket_name: process.env.REACT_APP_AWS_BUCKET,
      files: [{ name: path, content_type: file.type }],
    };

    const response = await api({
      method: httpMethods.post,
      endPoint: apiEndpoints.getS3PresignedURL,
      data: payload,
      needLoader: true,
      loader: loaderPath.uploadImage,
      showToastOnError: true,
    });

    if (response?.status) {
      const awsURL = response?.data?.[path];

      try {
        setLoadingAWS(true);
        await fetch(awsURL, { method: "PUT", body: file });
        return { status: true };
      } catch (error) {
        showToast();
        return { status: false, error };
      } finally {
        setLoadingAWS(false);
      }
    }
  };

  const onSubmit = async (formData) => {
    if (!formData.fileUpload) {
      setImageError(true);
      return;
    }
    setImageError(false);

    const dataToSend = { ...(formData || {}) };

    if (formData.fileUpload) {
      const fileExtension = formData.fileUpload.name.split(".").pop();
      const path = `organization-${ORGANIZATION_CODE}/materials/stones/${Date.now()}.${fileExtension}`;

      const uploadResponse = await uploadImageToS3(formData.fileUpload, path);
      if (!uploadResponse?.status) return;

      dataToSend.image = path;
    }

    delete dataToSend.fileUpload;

    const response = await api({
      method: httpMethods.post,
      endPoint: apiEndpoints.materials,
      data: dataToSend,
      needLoader: true,
      loader: loaderPath.addMaterial,
      showToastMessage: true,
    });

    if (response?.status) {
      onSuccess();
      handleClose();
    }
  };

  const handleRemoveImage = () => {
    setValue("fileUpload", null);
    setImagePreview(null);
  };

  const renderImagePreview = () =>
    imagePreview && (
      <ImagePreviewContainer>
        <CrossButton onClick={handleRemoveImage}>&times;</CrossButton>
        <img
          src={imagePreview}
          alt="Material Preview"
          style={{
            maxWidth: "100%",
            maxHeight: IMAGE_CONFIG.dimensions.maxHeight,
            objectFit: "contain",
            borderRadius: "8px",
          }}
        />
      </ImagePreviewContainer>
    );

  const renderUploadButton = () => {
    const inProgress = Object.values(loading).some(Boolean) || loadingAWS;

    return watch("fileUpload") && imagePreview ? null : (
      <UploadArea
        inProgress={inProgress}
        onClick={() => !inProgress && imgRef?.current?.click()}
      >
        <input
          type="file"
          ref={imgRef}
          id="material-image-upload"
          onChange={handleFileChange}
          accept={IMAGE_CONFIG.acceptedTypes}
          disabled={loading?.uploadImage}
          style={{ display: "none" }}
        />
        <CloudUploadIcon sx={{ fontSize: 34, color: "primary.dark100" }} />
        <Typography variant="body1" sx={{ fontWeight: 500 }}>
          {t("click-to-upload")}
        </Typography>
        <Typography variant="body2" color="gray.light300">
          <SATruncateWithEllipsis
            maxLength={30}
            text={watch("fileUpload")?.name || ""}
          />
        </Typography>
      </UploadArea>
    );
  };

  return (
    <SABox
      py={4}
      px={{ xs: 2, md: 4 }}
      sx={{ backgroundColor: "#fff", borderRadius: 3, boxShadow: 1 }}
    >
      <SAForm onSubmit={handleSubmit(onSubmit)}>
        <SAFormFields
          spacing={3}
          {...{ fields: addMaterialsFields, register, formState, control }}
        />
        {renderUploadButton()}
        {renderImagePreview()}
        {imageError && (
          <SABox color="error.main" mt={1} fontSize="14px" textAlign="center">
            {t("image-required-error")}
          </SABox>
        )}
        <SABox mt={4} textAlign="center">
          <SAButton
            type="submit"
            color="primary"
            variant="contained"
            loading={Object.values(loading).some(Boolean) || loadingAWS}
          >
            {t("add-material")}
          </SAButton>
        </SABox>
      </SAForm>
    </SABox>
  );
};

const AddMaterial = ({ handleClose, onSuccess }) => {
  const { t } = useI18N();
  return (
    <MUIModal
      open={true}
      handleClose={handleClose}
      title={t("add-material-title")}
      content={<Content {...{ handleClose, onSuccess }} />}
    />
  );
};

export default AddMaterial;
