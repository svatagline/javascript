import { useState } from "react";

import placeholderImage from "../../../assets/images/placeholder-image.jpg";
import useI18N from "../../../hooks/useI18N";
import SABasicTable from "../../../shared/SABasicTable";
import SABox from "../../../shared/SABox";
import SAButton from "../../../shared/SAButton";
import LazyImage from "../../../shared/SAImageLoader";
import SALoader from "../../../shared/SALoader";
import SAStack from "../../../shared/SAStack";
import SAStatusBadge from "../../../shared/SAStatusBadge";
import SATypography from "../../../shared/SATypography";

const StonesTable = ({
  loading,
  paginationProps,
  materialsData,
  handleStatus,
  columns = [],
}) => {
  const { t } = useI18N();
  const [loadingRecordId, setLoadingRecordId] = useState(null);

  const handleStatusClick = async (data) => {
    setLoadingRecordId(data.id);
    await handleStatus(data);
    setLoadingRecordId(null);
  };

  const renderCell = (columnKey, data) => {
    switch (columnKey) {
      case "name":
        return (
          <SAStack direction="row" alignItems="center" gap={1.5}>
            <SABox sx={{ width: "50px", height: "50px" }}>
              <LazyImage
                eyeIcon={false}
                src={data?.image?.url || placeholderImage}
                style={{
                  width: "50px",
                  height: "50px",
                  borderRadius: "50%",
                  objectFit: "contain",
                }}
              />
            </SABox>
            <SATypography variant="body2" fontWeight={600}>
              {data?.name}
            </SATypography>
          </SAStack>
        );

      case "materialType":
        return <SAStatusBadge status={data?.material_type?.toUpperCase()} />;

      case "status":
        return (
          <SAStatusBadge status={data?.is_enabled ? "ENABLED" : "DISABLED"} />
        );

      case "action":
        return (
          <SAButton
            size="small"
            variant="outlined"
            onClick={() => handleStatusClick(data)}
            sx={{ gap: 1 }}
          >
            {t(data?.is_enabled ? "disable" : "enable")}
            {loadingRecordId === data.id && <SALoader size={17} />}
          </SAButton>
        );

      default:
        return data[columnKey];
    }
  };

  return (
    <SABasicTable
      {...{
        data: materialsData,
        columns,
        renderCell,
        paginationProps,
        loading,
      }}
    />
  );
};

export default StonesTable;
