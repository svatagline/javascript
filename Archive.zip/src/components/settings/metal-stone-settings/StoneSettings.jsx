import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import { TABLE_RECORD_PER_PAGE } from "../../../constants";
import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  loaderPath,
  stoneTableColumns,
} from "../../../descriptions/settings.descriptions";
import useAPI from "../../../hooks/useAPI";
import useDebounce from "../../../hooks/useDebounce";
import useI18N from "../../../hooks/useI18N";
import usePagination from "../../../hooks/usePagination";
import { addMaterials } from "../../../redux/slices/settings.slices";
import { Search } from "../../../shared/icon";
import { MUIStyled } from "../../../shared/MUIStyled";
import SABox from "../../../shared/SABox";
import SAButton from "../../../shared/SAButton";
import SACard from "../../../shared/SACard";
import SAStack from "../../../shared/SAStack";
import SATextField from "../../../shared/SATextField";
import AddMaterial from "./AddMaterial";
import StoneShapeCuts from "./StoneShapeCuts";
import StonesTable from "./StonesTable";

const SearchWrapper = MUIStyled(SAStack)({ maxWidth: 400, width: "100%" });

const StoneSettings = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();

  const [addMaterial, setAddMaterial] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const debouncedSearch = useDebounce(searchTerm, 300);

  const loading = useSelector((state) => state.loader?.[loaderPath.materials]);
  const materialsList = useSelector((state) => state.settings?.materialsList);

  const { count, results: materialsData } = materialsList;

  const {
    totalPage,
    currentPage,
    setCurrentPage,
    itemPerPage,
    setItemPerPage,
  } = usePagination(count, TABLE_RECORD_PER_PAGE);

  useEffect(() => {
    callMaterialsAPI();
  }, [currentPage, itemPerPage, debouncedSearch]);

  const getMaterialsList = async ({ page, page_size, name = "" } = {}) => {
    const response = await api({
      method: httpMethods.get,
      endPoint: apiEndpoints?.materials,
      needLoader: true,
      loader: loaderPath.materials,
      showToastOnError: true,
      params: {
        page,
        page_size,
        ...(name ? { name } : {}),
        material_type: "stone",
      },
    });

    if (response?.status) dispatch(addMaterials({ data: response?.data }));
  };

  const callMaterialsAPI = () => {
    getMaterialsList({
      page: currentPage,
      page_size: itemPerPage,
      name: debouncedSearch,
    });
  };

  const handleStatus = async (material) => {
    const response = await api({
      method: httpMethods.patch,
      endPoint: `${apiEndpoints?.material}${material.id}`,
      data: { is_enabled: !material.is_enabled },
      needLoader: true,
      loader: loaderPath.materialStatus,
      showToastMessage: true,
    });

    if (response?.status) callMaterialsAPI();
  };

  const paginationProps = {
    currentPage,
    page: totalPage,
    rowsPerPage: itemPerPage,
    setItemPerPage,
    setCurrentPage,
  };

  return (
    <SAStack direction={{ xs: "column", lg: "row" }} gap={2}>
      <SABox sx={{ flex: { xs: "none", lg: 1.5 } }}>
        <SACard>
          <SAStack
            pb={2}
            mb={2}
            direction="row"
            justifyContent="space-between"
            borderBottom={`1px solid gray.main 50`}
            alignItems="center"
          >
            <SearchWrapper>
              <SATextField
                placeholder={t("search-stone-name")}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{ startAdornment: <Search /> }}
              />
            </SearchWrapper>
            <SAButton
              color="primary"
              onClick={() => setAddMaterial(true)}
              variant="contained"
            >
              {t("add-material")}
            </SAButton>
          </SAStack>
          <StonesTable
            {...{
              paginationProps,
              loading,
              materialsData,
              handleStatus,
              columns: stoneTableColumns,
            }}
          />
        </SACard>
        {addMaterial && (
          <AddMaterial
            onSuccess={callMaterialsAPI}
            handleClose={() => setAddMaterial(false)}
          />
        )}
      </SABox>
      <SABox sx={{ flex: { xs: "none", lg: 1 } }}>
        <StoneShapeCuts />
      </SABox>
    </SAStack>
  );
};

export default StoneSettings;
