import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import { BUSINESS } from "../../constants";
import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  loaderPath,
  transactionTableColumns,
} from "../../descriptions/transactions.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import {
  addTransaction,
  isRefreshList,
} from "../../redux/slices/transactions.slice";
import { Eye } from "../../shared/icon";
import SABasicTable from "../../shared/SABasicTable";
import SAButton from "../../shared/SAButton";
import SAStatusBadge from "../../shared/SAStatusBadge";
import SATruncateWithEllipsis from "../../shared/SATruncateWithEllipsis";
import SATypography from "../../shared/SATypography";
import {
  convertDatesToTimestampsInObject,
  formatAmount,
  formatTimestamp,
  validTableValue,
} from "../../utils/functions";

const TransactionTable = ({
  searchQuery,
  submitFilterData,
  totalPage,
  currentPage,
  setCurrentPage,
  itemPerPage,
  transactionsData,
  setItemPerPage,
}) => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();
  const navigation = useNavigate();

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.transactions],
  );

  const refreshList = useSelector((state) => state.transactions?.refreshList);

  const onHandleView = (id) => navigation(`${id}`);

  const handleNavigation = (ownerId, businessId) => {
    navigation(`/businesses/${businessId}`, { state: { ownerId } });
  };

  const getTransactionsList = async ({
    page,
    page_size,
    business_name = "",
    submitFilterData,
  } = {}) => {
    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints.getTransactions}`,
      needLoader: true,
      loader: loaderPath.transactions,
      showToastOnError: true,
      params: {
        page,
        page_size,
        business_name,
        ...convertDatesToTimestampsInObject(submitFilterData, [
          "end_date",
          "start_date",
        ]),
      },
    });

    if (response?.status) dispatch(addTransaction({ data: response?.data }));
  };

  const paginationProps = {
    currentPage,
    page: totalPage,
    rowsPerPage: itemPerPage,
    setItemPerPage,
    setCurrentPage,
  };

  useEffect(() => {
    getTransactionsList({
      page: currentPage,
      page_size: itemPerPage,
      business_name: searchQuery,
      submitFilterData: submitFilterData,
    });
  }, [currentPage, itemPerPage, searchQuery, submitFilterData]);

  useEffect(() => {
    if (refreshList) {
      setCurrentPage(1);
      getTransactionsList({ page: 1 });
      dispatch(isRefreshList(false));
    }
  }, [refreshList]);

  const renderCell = (columnKey, data, _, value) => {
    const { id, from_business, to_business } = data || {};
    const isFromBusiness = from_business?.owner?.user_type === BUSINESS;
    const isToBusiness = to_business?.owner?.user_type === BUSINESS;

    switch (columnKey) {
      case "action":
        return (
          <SAButton
            size="small"
            variant="outlined"
            onClick={() => onHandleView(id)}
            sx={{
              px: 2,
              textTransform: "none",
              borderRadius: 2,
              borderColor: "grey.400",
              color: "grey.700",
              gap: 0.5,
              "&:hover": {
                backgroundColor: "grey.100",
                borderColor: "grey.600",
              },
            }}
          >
            {t("view")} <Eye />
          </SAButton>
        );

      case "business_from":
        return (
          <SATypography
            onClick={() =>
              handleNavigation(from_business?.owner?.id, from_business?.id)
            }
            sx={{
              textDecoration: "none",
              color: "grey.900",
              fontWeight: 500,
              display: "flex",
              alignItems: "center",
              gap: 0.5,
              "&:hover": {
                color: "primary.main",
                textDecoration: "underline",
                textUnderlineOffset: 2,
              },
            }}
          >
            <SATypography variant="body2" fontWeight={600}>
              {isFromBusiness
                ? validTableValue(from_business?.name, false)
                : validTableValue(from_business?.owner?.name, false)}{" "}
              <SATypography
                component="span"
                variant="caption"
                fontWeight={550}
                color="grey.600"
                sx={{ ml: 0.5 }}
              >
                {`(${t(from_business?.business_account_type)})`}
              </SATypography>
            </SATypography>
          </SATypography>
        );

      case "business_to":
        return (
          <SATypography
            onClick={() =>
              handleNavigation(to_business?.owner?.id, to_business?.id)
            }
            sx={{
              textDecoration: "none",
              color: "grey.900",
              fontWeight: 500,
              display: "flex",
              alignItems: "center",
              gap: 0.5,
              "&:hover": {
                color: "primary.main",
                textDecoration: "underline",
                textUnderlineOffset: 2,
              },
            }}
          >
            <SATypography variant="body2" fontWeight={600}>
              {isToBusiness
                ? validTableValue(to_business?.name, false)
                : validTableValue(to_business?.owner?.name)}{" "}
              <SATypography
                component="span"
                variant="caption"
                fontWeight={550}
                color="grey.600"
                sx={{ ml: 0.5 }}
              >
                {`(${t(to_business?.business_account_type)})`}
              </SATypography>
            </SATypography>
          </SATypography>
        );

      case "amount":
        return (
          <SATypography
            variant="body2"
            fontWeight={600}
            color={"#027A48"}
            sx={{
              padding: "6px 12px",
              borderRadius: "6px",
              display: "inline-block",
            }}
          >
            {`${formatAmount(value)}`}
          </SATypography>
        );

      case "material_type":
        return data?.purchase_request?.precious_item?.material_type ? (
          <SAStatusBadge
            status={validTableValue(
              data?.purchase_request?.precious_item?.material_type?.toUpperCase(),
            )}
          />
        ) : (
          "-"
        );

      case "material_name":
        return (
          <SATypography variant="body2">
            <SATruncateWithEllipsis
              maxLength={21}
              text={validTableValue(
                data?.purchase_request?.precious_item?.name,
              )}
            />
          </SATypography>
        );

      case "created_at":
        return (
          <SATypography
            variant="body2"
            fontWeight={500}
            sx={{
              padding: "4px 8px",
              borderRadius: "6px",
              backgroundColor: "#F3F4F6",
              color: "#374151",
              display: "inline-block",
              fontSize: "0.875rem",
            }}
          >
            {value ? formatTimestamp(value) : "-"}
          </SATypography>
        );

      case "status":
        return <SAStatusBadge status={validTableValue(value, true)} />;

      case "transaction_type":
        return <SAStatusBadge status={validTableValue(value, true)} />;

      default:
        return (
          <SATypography variant="body2">{validTableValue(value)}</SATypography>
        );
    }
  };

  return (
    <>
      <SABasicTable
        {...{
          loading,
          data: transactionsData || [],
          columns: transactionTableColumns,
          renderCell,
          paginationProps,
          colSpan: 5,
        }}
      />
    </>
  );
};

export default TransactionTable;
