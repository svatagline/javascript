import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";

import { BUSINESS } from "../../constants";
import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import { loaderPath } from "../../descriptions/transactions.descriptions";
import useAPI from "../../hooks/useAPI";
import {
  Amount,
  Brand,
  Condition,
  Date,
  Details,
  Packaging,
  SerialNum,
  TransactionLight,
  Treatment,
  WeighingScale,
  Weight,
} from "../../shared/icon";
import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import SAShowDetails from "../../shared/SAShowDetails";
import SAStack from "../../shared/SAStack";
import SAStatusBadge from "../../shared/SAStatusBadge";
import SATruncateWithEllipsis from "../../shared/SATruncateWithEllipsis";
import SATypography from "../../shared/SATypography";
import {
  formatAmount,
  formatTimestamp,
  formatWeight,
  validDetailsValue,
  validTableValue,
} from "../../utils/functions";

const TransactionDetails = () => {
  const { api } = useAPI();
  const urlParams = useParams();
  const navigate = useNavigate();

  const [transactionData, setTransactionData] = useState({});
  const [transactionDataExist, setTransactionDataExist] = useState(false);
  const loading = useSelector(
    (state) => state.loader?.[loaderPath.transactionDetails],
  );

  const isFromBusiness =
    transactionData?.from_business?.owner?.user_type === BUSINESS;
  const isToBusiness =
    transactionData?.to_business?.owner?.user_type === BUSINESS;

  useEffect(() => {
    getTransactionDetails();
  }, [urlParams?.transactionId]);

  const getTransactionDetails = async () => {
    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints?.getTransaction}${urlParams?.transactionId}/`,
      needLoader: true,
      loader: loaderPath.transactionDetails,
      showToastOnError: true,
    });

    if (response?.status) {
      setTransactionData(response?.data);
      setTransactionDataExist(true);
    } else {
      setTransactionDataExist(false);
    }
  };

  const handleNavigation = (ownerId, businessId) => {
    navigate(`/businesses/${businessId}`, { state: { ownerId } });
  };

  const breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: "transactions", href: "/transactions" },
    { label: urlParams?.transactionId, noTranslate: true },
  ];

  const precious_item_data =
    transactionData?.purchase_request?.precious_item ?? {};

  let materialType = transactionData?.purchase_request?.precious_item
    ?.precious_stone_details
    ? "precious_stone_details"
    : transactionData?.purchase_request?.precious_item?.precious_metal_details
      ? "precious_metal_details"
      : "";

  const detailObject = {
    dataExist: transactionDataExist,
    loading: loading,
    imageSize: "sm",
    mainDetail: {
      images: precious_item_data?.precious_item_images,
      title: transactionData?.precious_item?.name,
      badge: { title: transactionData?.status?.toUpperCase() },
      data: [
        {
          key: "amount",
          value: (
            <SATypography
              variant="body2"
              fontWeight={600}
              fontSize={16}
              color={"#027A48"}
            >
              {formatAmount(transactionData?.amount, false)}
            </SATypography>
          ),
          label: "",
          icon: <Amount />,
          isSeparated: true,
        },
        {
          key: "transaction-type",
          value: (
            <SAStatusBadge
              status={validTableValue(transactionData?.transaction_type)}
            />
          ),
          label: "",
          icon: <TransactionLight {...{ fill: "white" }} />,
          isSeparated: true,
        },
        {
          key: "created-at",
          value: (
            <SATypography
              variant="body2"
              fontWeight={500}
              sx={{
                padding: "4px 8px",
                borderRadius: "6px",
                backgroundColor: "#F3F4F6",
                color: "#374151",
                display: "inline-block",
                fontSize: "0.875rem",
              }}
            >
              {transactionData?.created_at
                ? formatTimestamp(transactionData?.created_at)
                : ""}
            </SATypography>
          ),
          label: "",
          isSeparated: true,
          icon: <Date {...{ fill: "white" }} />,
        },
        {
          key: "notes",
          value: (
            <SATruncateWithEllipsis
              maxLength={30}
              text={transactionData?.notes}
            />
          ),
          label: "",
          icon: <Details />,
          isSeparated: true,
        },
        {
          key: "admin-remark",
          value: (
            <SATruncateWithEllipsis
              maxLength={30}
              text={transactionData?.remark}
            />
          ),
          label: "",
          icon: <Details />,
          isSeparated: true,
        },
        // Asset Details
        ...(transactionData?.purchase_request
          ? [
              {
                key: "material-name",
                value: precious_item_data?.name,
                label: "",
                icon: <Weight />,
              },
              {
                key: "material-type",
                value: (
                  <SAStatusBadge
                    status={validTableValue(
                      precious_item_data?.material_type?.toUpperCase(),
                    )}
                  />
                ),
                label: "",
                icon: <Weight />,
                isSeparated: true,
              },
              {
                key: "weight",
                value: (
                  <SATypography
                    variant="body2"
                    sx={{
                      fontWeight: 600,
                      color: "#1F2937",
                      backgroundColor: "#F3F4F6",
                      padding: "4px 8px",
                      borderRadius: "6px",
                      display: "inline-block",
                    }}
                  >
                    {formatWeight(precious_item_data?.[materialType]?.weight)}
                  </SATypography>
                ),
                label: "",
                icon: <WeighingScale />,
                isSeparated: true,
              },
              ...(precious_item_data?.[materialType]?.brand
                ? [
                    {
                      key: "brand",
                      value: precious_item_data?.[materialType]?.brand,
                      label: "",
                      icon: <Brand />,
                    },
                  ]
                : []),
              ...(precious_item_data?.[materialType]?.serial_number
                ? [
                    {
                      key: "serial-number",
                      value: precious_item_data?.[materialType]?.serial_number,
                      label: "",
                      icon: <SerialNum />,
                    },
                  ]
                : []),
              ...(precious_item_data?.[materialType]?.condition
                ? [
                    {
                      key: "condition",
                      value: precious_item_data?.[materialType]?.condition,
                      label: "",
                      icon: <Condition />,
                    },
                  ]
                : []),
              ...(precious_item_data?.[materialType]?.packaging
                ? [
                    {
                      key: "packaging",
                      value: precious_item_data?.[materialType]?.packaging,
                      label: "",
                      icon: <Packaging />,
                    },
                  ]
                : []),
              ...(precious_item_data?.[materialType]?.manufacture_date
                ? [
                    {
                      key: "manufacture-date",
                      value: validDetailsValue(
                        precious_item_data?.[materialType]?.manufacture_date,
                        "date",
                      ),
                      label: "",
                      icon: <Date fill="#ffffff" width="15px" height="15px" />,
                    },
                  ]
                : []),
              ...(precious_item_data?.[materialType]?.treatment
                ? [
                    {
                      key: "treatment",
                      value: precious_item_data?.[materialType]?.treatment,
                      label: "",
                      icon: <Treatment />,
                    },
                  ]
                : []),
            ]
          : []),
      ],
    },
    otherDetails: [
      {
        division: 2,
        list: [
          {
            title: "business-from",
            details: [
              {
                title: "name",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={600}
                    sx={{
                      cursor: "pointer",
                      textDecoration: "underline",
                      textUnderlineOffset: "3px",
                      "&:hover": { textDecoration: "none" },
                    }}
                    onClick={() =>
                      handleNavigation(
                        transactionData?.from_business?.owner?.id,
                        transactionData?.from_business?.id,
                      )
                    }
                  >
                    {isFromBusiness
                      ? transactionData?.from_business?.name
                      : transactionData?.from_business?.owner?.name}
                  </SATypography>
                ),
                isSeparated: true,
              },
              {
                title: "account-type",
                value: (
                  <SAStatusBadge
                    status={validTableValue(
                      transactionData?.from_business?.business_account_type,
                    )}
                  />
                ),
                isSeparated: true,
              },
              {
                value: transactionData?.from_business?.owner?.name,
                title: "owner-name",
              },
              {
                title: "owner-email",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={500}
                    color="primary.main"
                    sx={{
                      padding: "4px 8px",
                      borderRadius: "6px",
                      backgroundColor: "#EEF2FF",
                      display: "inline-block",
                      fontSize: "0.875rem",
                    }}
                  >
                    {transactionData?.from_business?.owner?.email}
                  </SATypography>
                ),
                isSeparated: true,
              },
              {
                value: transactionData?.from_business?.owner?.phone_number,
                title: "phone-number",
              },
            ],
          },
          {
            title: "business-to",
            details: [
              {
                title: "name",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={600}
                    sx={{
                      cursor: "pointer",
                      textDecoration: "underline",
                      textUnderlineOffset: "3px",
                      "&:hover": { textDecoration: "none" },
                    }}
                    onClick={() =>
                      handleNavigation(
                        transactionData?.to_business?.owner?.id,
                        transactionData?.to_business?.id,
                      )
                    }
                  >
                    {isToBusiness
                      ? transactionData?.to_business?.name
                      : transactionData?.to_business?.owner?.name}
                  </SATypography>
                ),
                isSeparated: true,
              },
              {
                title: "account-type",
                value: (
                  <SAStatusBadge
                    status={validTableValue(
                      transactionData?.to_business?.business_account_type,
                    )}
                  />
                ),
                isSeparated: true,
              },
              {
                value: transactionData?.to_business?.owner?.name,
                title: "owner-name",
              },
              {
                title: "owner-email",
                value: (
                  <SATypography
                    variant="body2"
                    fontWeight={500}
                    color="primary.main"
                    sx={{
                      padding: "4px 8px",
                      borderRadius: "6px",
                      backgroundColor: "#EEF2FF",
                      display: "inline-block",
                      fontSize: "0.875rem",
                    }}
                  >
                    {transactionData?.to_business?.owner?.email}
                  </SATypography>
                ),
                isSeparated: true,
              },
              {
                value: transactionData?.to_business?.owner?.phone_number,
                title: "phone-number",
              },
            ],
          },
        ],
      },
    ],
  };

  return (
    <>
      <SAStack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        mb={3}
      >
        <SAStack>
          <MUIBreadcrumbs breadcrumbsData={breadcrumbsData} />
        </SAStack>
      </SAStack>

      <SAShowDetails detailObject={detailObject} />
    </>
  );
};

export default TransactionDetails;
