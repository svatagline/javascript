import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { Outlet, useParams } from "react-router-dom";

import { TABLE_RECORD_PER_PAGE } from "../../constants";
import {
  defaultTransactionFilterValues,
  transactionFilterFields,
} from "../../descriptions/transactions.descriptions";
import useDebounce from "../../hooks/useDebounce";
import useI18N from "../../hooks/useI18N";
import usePagination from "../../hooks/usePagination";
import { Search } from "../../shared/icon";
import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import { MUIStyled } from "../../shared/MUIStyled";
import SACard from "../../shared/SACard";
import SAFilterMenu from "../../shared/SAFilterMenu";
import SAStack from "../../shared/SAStack";
import SATextField from "../../shared/SATextField";
import theme from "../../themes/theme";
import { compareAmounts, compareDates } from "../../utils/functions";
import showToast from "../../utils/toast";
import TransactionTable from "./TransactionTable";

const SearchWrapper = MUIStyled(SAStack)({ maxWidth: 400, width: "100%" });

const Transaction = () => {
  const { t } = useI18N();
  const { transactionId } = useParams();

  const [searchTerm, setSearchTerm] = useState("");
  const [submitFilterData, setSubmitFilterData] = useState({});
  const [filterData, setFilterData] = useState({
    ...defaultTransactionFilterValues,
  });

  const transactionList =
    useSelector((state) => state.transactions?.transactions) ?? [];
  const { count, results: transactionsData } = transactionList;

  const {
    totalPage,
    currentPage,
    setCurrentPage,
    itemPerPage,
    setItemPerPage,
  } = usePagination(count, TABLE_RECORD_PER_PAGE);

  const debouncedSearch = useDebounce(searchTerm, 300, () => {
    setCurrentPage(1);
  });

  const {
    register,
    handleSubmit,
    formState,
    control,
    reset,
    getValues,
    watch,
    setValue,
  } = useForm({
    mode: "onChange",
    defaultValues: filterData,
  });
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const watchFields = watch();

  useEffect(() => {
    if (open) {
      Object.keys(filterData).forEach((i) => {
        setValue(i, filterData[i]);
      });
    }
  }, [open]);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: "transactions" },
  ];

  const handleFilterSubmit = (formData) => {
    try {
      const { min_amount, max_amount, start_date, end_date } = formData;
      compareAmounts({
        min_amount,
        max_amount,
        min_amount_field: "Min Amount",
        max_amount_field: "Max Amount",
        errorMessage: "min-amount-should-be-less-than-max-amount",
      });
      compareDates({
        start_date,
        end_date,
        start_date_field: "Start Date",
        end_date_field: "End Date",
        errorMessage: "start-date-should-be-less-than-end-date",
      });
      setCurrentPage(1);
      setSubmitFilterData(formData);
      handleClose();
    } catch (error) {
      showToast(error);
    }
  };

  if (transactionId) return <Outlet />;

  const useFormControls = {
    register,
    handleSubmit,
    formState,
    control,
    reset,
    getValues,
    watchFields,
  };

  return (
    <>
      <SAStack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        mb={3}
      >
        <SAStack>
          <MUIBreadcrumbs breadcrumbsData={breadcrumbsData} />
        </SAStack>
      </SAStack>
      <SACard>
        <SAStack
          pb={2}
          mb={2}
          direction="row"
          justifyContent="space-between"
          borderBottom={`1px solid ${theme.palette.gray.main}50`}
          alignItems="center"
          flexWrap="wrap"
          gap={3}
        >
          <SearchWrapper>
            <SATextField
              placeholder={t("search-for-business-name")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{ startAdornment: <Search /> }}
            />
          </SearchWrapper>
          <SAFilterMenu
            t={t}
            anchorEl={anchorEl}
            open={open}
            handleClose={handleClose}
            onSubmit={handleFilterSubmit}
            slotProps={{ paper: { sx: { p: 2 } } }}
            handleClick={handleClick}
            useFormControls={useFormControls}
            setFilterData={setFilterData}
            setSubmitFilterData={setSubmitFilterData}
            defaultFilterValues={defaultTransactionFilterValues}
            filterFields={transactionFilterFields}
          />
        </SAStack>
        <TransactionTable
          searchQuery={debouncedSearch}
          submitFilterData={submitFilterData}
          totalPage={totalPage}
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          itemPerPage={itemPerPage}
          setItemPerPage={setItemPerPage}
          transactionsData={transactionsData}
        />
      </SACard>
    </>
  );
};

export default Transaction;
