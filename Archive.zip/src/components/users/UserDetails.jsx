import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useLocation, useParams } from "react-router-dom";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import { loaderPath } from "../../descriptions/users.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import { Email, Phone } from "../../shared/icon";
import MUIBreadcrumbs from "../../shared/MUIBreadcrumbs";
import SAShowDetails from "../../shared/SAShowDetails";
import SAStack from "../../shared/SAStack";
import { validDetailsValue } from "../../utils/functions";

const UserDetails = () => {
  const [userData, setUserData] = useState({});
  const { t } = useI18N();
  const [userDataExist, setUserDataExist] = useState(false);
  const [refreshDetails, setRefreshDetails] = useState(false);
  const { api } = useAPI();
  const urlParams = useParams();
  const location = useLocation();
  const loading = useSelector(
    (state) => state.loader?.[loaderPath.userDetailsLoading],
  );

  useEffect(() => {
    getUsersDetails();
  }, [urlParams?.username]);

  useEffect(() => {
    if (refreshDetails) {
      getUsersDetails();
    }
  }, [urlParams?.username, refreshDetails]);

  const getUsersDetails = async () => {
    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints?.getUsers}${urlParams?.username}/`,
      needLoader: true,
      loader: loaderPath.userDetailsLoading,
      showToastOnError: true,
    });

    if (response?.status) {
      setUserData(response?.data);
      setUserDataExist(true);
    } else {
      setUserDataExist(false);
    }
    setRefreshDetails(false);
  };

  let breadcrumbsData = [
    { label: "home", href: "/businesses" },
    { label: `${userData?.username}`, noTranslate: true },
  ];

  if (Array.isArray(location?.state?.breadcrumbsDataForChild)) {
    breadcrumbsData = [
      ...(location.state.breadcrumbsDataForChild ?? []), // Ensure it's an array
      ...(userData?.username
        ? [{ label: `${userData.username}`, noTranslate: true }]
        : []),
    ];
  }
  const detailObject = {
    dataExist: userDataExist,
    loading: loading,
    imageSize: "sm",
    mainDetail: {
      images: [{ url: userData?.profile_image }],
      title: `${userData?.first_name} ${userData?.middle_name} ${userData?.last_name}`,
      badge: {
        title: t(
          userData?.account_status == "APPROVED" ? "active" : "suspended",
        ),
        variant: userData.account_status == "APPROVED" ? "success" : "error",
      },
      data: [
        {
          key: "email",
          value: userData?.email,

          label: "",
          icon: <Email />,
        },
        {
          key: "phone-number",
          value: userData?.phone_number,

          label: "",
          icon: <Phone />,
        },
      ],
    },
    otherDetails: [
      {
        division: 2,
        list: [
          {
            title: "personal-details",
            details: [
              {
                value: userData?.username,
                title: "username",
              },
              {
                value: t(`${userData?.user_type}`.toLowerCase()),
                title: "user-type",
              },
              {
                value: userData?.phone_country_code,
                title: "phone-country-code",
              },
              {
                value: userData?.date_of_birth,
                title: "date-of-birth",
              },
              {
                value: validDetailsValue(userData?.date_joined, "date"),
                title: "date-joined",
              },
              {
                value: validDetailsValue(userData?.last_login, "date"),
                title: "last-login",
              },
            ],
          },
          {
            title: "verification-details",
            details: [
              {
                value: userData?.face_verified,
                title: "face-verified",
              },
              {
                value: userData?.document_verified,
                title: "document-verified",
              },
              {
                value: userData?.phone_verified,
                title: "phone-verified",
              },
              {
                value: userData?.email_verified,
                title: "email-verified",
              },
              {
                value: userData?.individual_aml_verified,
                title: "individual-aml-verified",
              },
              {
                value: userData?.business_aml_verified,
                title: "business-aml-verified",
              },
              {
                value: userData?.due_diligence_verified,
                title: "due-diligence-verified",
              },
            ],
          },
        ],
      },
    ],
  };
  return (
    <>
      <SAStack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        mb={3}
      >
        <SAStack>
          <MUIBreadcrumbs breadcrumbsData={breadcrumbsData} />
        </SAStack>
      </SAStack>
      <SAShowDetails detailObject={detailObject} />
    </>
  );
};

export default UserDetails;
