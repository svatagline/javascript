import { useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";

import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  changeAccountStatusFormFields,
  loaderPath,
} from "../../descriptions/users.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import { isRefreshList } from "../../redux/slices/users.slices";
import MUIModal from "../../shared/MUIModal";
import { MUIStyled } from "../../shared/MUIStyled";
import SABox from "../../shared/SABox";
import SAButton from "../../shared/SAButton";
import SAForm from "../../shared/SAForm";
import SAFormFields from "../../shared/SAFormFields";
import SAStack from "../../shared/SAStack";
import { isSameObject } from "../../utils/functions";
import showToast from "../../utils/toast";

const StyledForm = MUIStyled(SAForm)(() => ({
  width: "100%",
  "& .MuiInputBase-input": { padding: 8 },
  "& .formFields": { maxHeight: "44vh", overflow: "auto" },
}));

const SuspendUserContent = ({ handleClose, t, data, refresh, suspend }) => {
  const dispatch = useDispatch();
  const { account_status, suspend_reason, id } = data ?? {};

  const formDefaultValue = {
    account_status: suspend ? "SUSPEND" : "APPROVED",
    suspend_reason: suspend_reason,
  };

  const formFields = changeAccountStatusFormFields?.map((field) => ({
    ...field,
    formLabel: `${suspend ? "suspend" : "activate"}-reason`,
    placeholder: `${suspend ? "suspend" : "activate"}-reason-placeholder`,
    registerOptions: {
      ...field.registerOptions,
      required: {
        ...field.registerOptions.required,
        message: `${suspend ? "suspend" : "activate"}-reason-required-error`,
      },
    },
  }));

  const { register, handleSubmit, formState, control, reset } = useForm({
    mode: "onChange",
    defaultValues: formDefaultValue,
  });

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.userSuspendLoading],
  );
  const { api } = useAPI();

  const onSubmit = async (formData) => {
    const isChangedInForm = !isSameObject(
      { account_status, suspend_reason },
      formData,
    );
    if (isChangedInForm) {
      const response = await api({
        method: httpMethods.patch,
        endPoint: apiEndpoints.userSuspension(id),
        data: formData,
        needLoader: true,
        loader: loaderPath.userSuspendLoading,
        showToastMessage: true,
      });
      if (response?.status) {
        dispatch(isRefreshList(true));
        reset(formDefaultValue);
        handleClose();
        refresh && refresh();
      }
    } else {
      showToast("Please edit the form", { type: "error" });
    }
  };

  return (
    <SABox p={2}>
      <StyledForm onSubmit={handleSubmit(onSubmit)}>
        <SABox className={"formFields"}>
          <SAFormFields
            spacing={2}
            {...{ fields: formFields, register, formState, control }}
          />
        </SABox>
        <SAStack direction="row" mt={3} justifyContent="center" gap={2}>
          <SAButton variant="outlined" color="primary" onClick={handleClose}>
            {t("cancel")}
          </SAButton>
          <SAButton
            variant="contained"
            color="primary"
            type="submit"
            loading={loading}
          >
            {t(suspend ? "suspend" : "activate")}
          </SAButton>
        </SAStack>
      </StyledForm>
    </SABox>
  );
};

const SuspendUser = ({ isEditAction, data, refresh, isBusinessSuspended }) => {
  const { t } = useI18N();
  const [addEditSubAdminModal, setAddEditSubAdminModal] = useState(false);

  const { is_active, account_status } = data ?? {};

  const handleClose = () => setAddEditSubAdminModal(false);

  return (
    <>
      <SABox sx={{ width: "auto", display: "flex", justifyContent: "end" }}>
        <SAButton
          color="primary"
          onClick={() => setAddEditSubAdminModal(true)}
          size="small"
          variant="outlined"
          disabled={!!isBusinessSuspended || account_status === "DELETED"}
          sx={{ "& svg": { ml: 1 }, margin: "15px 10px" }}
        >
          {t(`${is_active ? "suspend" : "approve"}-user`)}
        </SAButton>
      </SABox>
      <MUIModal
        open={addEditSubAdminModal}
        handleClose={handleClose}
        title={t("change-account-status")}
        maxWidth="xs"
        content={
          <SuspendUserContent
            t={t}
            data={data}
            handleClose={handleClose}
            isEditAction={isEditAction}
            refresh={refresh}
            suspend={is_active}
            isBusinessSuspended={isBusinessSuspended}
          />
        }
      />
    </>
  );
};

export default SuspendUser;
