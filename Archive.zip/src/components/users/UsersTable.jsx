import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import { TABLE_RECORD_PER_PAGE } from "../../constants";
import { apiEndpoints, httpMethods } from "../../constants/api.constants";
import {
  loaderPath,
  userTableColumns,
} from "../../descriptions/users.descriptions";
import useAPI from "../../hooks/useAPI";
import useI18N from "../../hooks/useI18N";
import usePagination from "../../hooks/usePagination";
import { addUsers, isRefreshList } from "../../redux/slices/users.slices";
import { Eye } from "../../shared/icon";
import SABasicTable from "../../shared/SABasicTable";
import SABox from "../../shared/SABox";
import SAButton from "../../shared/SAButton";
import SATypography from "../../shared/SATypography";
import { excludeKeys, validTableValue } from "../../utils/functions";

const UsersTable = (props) => {
  const navigation = useNavigate();
  const { searchQuery, submitFilterData } = props;
  const { api } = useAPI();
  const dispatch = useDispatch();
  const loading = useSelector(
    (state) => state.loader?.[loaderPath.usersLoading],
  );
  const userList = useSelector((state) => state?.users?.users) ?? [];
  const refreshList = useSelector((state) => state?.users?.refreshList);
  const { count, results: usersData } = userList;
  const { t } = useI18N();

  const onHandleView = (data) => {
    navigation(`/users/${data?.id}`);
  };
  const {
    setTotalPage,
    currentPage,
    setCurrentPage,
    itemPerPage,
    setItemPerPage,
    onRowsPerPageChange,
  } = usePagination(count, TABLE_RECORD_PER_PAGE);

  const getUsersList = async ({
    page,
    page_size,
    fullname = "",
    submitFilterData,
  } = {}) => {
    const roleParams = submitFilterData?.role?.length
      ? `?${submitFilterData?.role.map((role) => `role=${role}`).join("&")}`
      : "";

    const response = await api({
      method: httpMethods.get,
      endPoint: `${apiEndpoints?.getUsers}${roleParams}`,
      needLoader: true,
      loader: loaderPath.usersLoading,
      showToastOnError: true,
      params: {
        page,
        page_size,
        fullname,
        ...excludeKeys(submitFilterData, ["role"]),
      },
    });

    if (response?.status) {
      dispatch(addUsers({ data: response?.data }));
      setTotalPage(response?.data?.totalPages || 1);
    }
  };

  const renderCell = (columnKey, data, _, value) => {
    switch (columnKey) {
      case "full_name":
        return (
          <SATypography variant="body2">
            {validTableValue(
              `${data?.first_name} ${data?.middle_name} ${data?.last_name}`,
            )}
          </SATypography>
        );

      case "action":
        return (
          <SABox sx={{ display: "flex", justifyContent: "center" }}>
            <SAButton
              size="small"
              variant="outlined"
              sx={{ "& svg": { ml: 1 } }}
              onClick={() => onHandleView(data)}
            >
              {t("view")} <Eye />
            </SAButton>
          </SABox>
        );
      default:
        return (
          <SATypography variant="body2">{validTableValue(value)}</SATypography>
        );
    }
  };
  const paginationProps = {
    count,
    page: currentPage,
    rowsPerPage: itemPerPage,
    onRowsPerPageChange,
    setTotalPage,
    setItemPerPage,
    setCurrentPage,
  };

  useEffect(() => {
    getUsersList({
      page: currentPage,
      page_size: itemPerPage,
      fullname: searchQuery,
      submitFilterData: submitFilterData,
    });
  }, [currentPage, itemPerPage, searchQuery, submitFilterData]);

  useEffect(() => {
    if (refreshList) {
      getUsersList({});
      dispatch(isRefreshList(false));
    }
  }, [refreshList]);
  return (
    <>
      <SABasicTable
        {...{
          data: usersData || [],
          columns: userTableColumns,
          renderCell,
          paginationProps,
          loading: loading,
          colSpan: 5,
        }}
      />
    </>
  );
};

export default UsersTable;
