import { Box, Stack, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";

import getSessionDetails from "../../../api/session";
import { INDIVIDUAL } from "../../../constants";
import { ORGANIZATION_CODE } from "../../../constants";
import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  defaultValues,
  fields,
  loaderPath,
} from "../../../descriptions/auth/generalDetail.description";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import { MUIStyled } from "../../../shared/MUIStyled";
import SAButton from "../../../shared/SAButton";
import SAForm from "../../../shared/SAForm";
import SAFormFields from "../../../shared/SAFormFields";
import { getFCMDetails, shuftiAPI } from "../../../utils/functions";
import showToast from "../../../utils/toast";
import AccountCreated from "./AccountCreated";

const GOLD_COLOR = "#C5A56F";

const ContentWrapper = MUIStyled(Box)(({ theme }) => ({
  padding: "16px 16px",
  maxWidth: 600,
  margin: "0 auto",
  [theme.breakpoints.up("sm")]: { padding: "16px 16px" },
}));

const StyledButton = MUIStyled(SAButton)({
  height: 48,
  borderRadius: 0,
  backgroundColor: GOLD_COLOR,
  color: "#fff",
  "&:hover": { backgroundColor: "#B39355" },
});

const StyledFormFields = MUIStyled(SAFormFields)(({ theme }) => ({
  "& .MuiFormControl-root": {
    marginBottom: "24px",
    "& .MuiOutlinedInput-root": {
      backgroundColor: "#fff",
      borderRadius: 0,
      "& fieldset": {
        borderColor: "#E0E0E0",
      },
      "&:hover fieldset": {
        borderColor: "#B0B0B0",
      },
      "&.Mui-focused fieldset": {
        borderColor: GOLD_COLOR,
      },
    },
    "& .MuiInputLabel-root.Mui-focused": {
      color: GOLD_COLOR,
    },
  },
  "& .form-label": {
    color: theme.palette.text.secondary,
    fontSize: "0.75rem",
    marginBottom: "4px",
    display: "block",
  },
  "& .helper-text": {
    color: theme.palette.text.secondary,
    fontSize: "0.75rem",
    marginTop: "4px",
  },
  "& .phone-input": {
    "& .special-label": {
      display: "none",
    },
    "& .form-control": {
      width: "100%",
      height: "40px",
      borderRadius: 0,
      border: "1px solid #E0E0E0",
      "&:hover": {
        borderColor: "#B0B0B0",
      },
      "&:focus": {
        borderColor: GOLD_COLOR,
        boxShadow: "none",
      },
    },
    "& .flag-dropdown": {
      borderRadius: 0,
      border: "1px solid #E0E0E0",
      borderRight: "none",
      backgroundColor: "#fff",
      "&:hover": {
        borderColor: "#B0B0B0",
      },
      "&.open": {
        borderColor: GOLD_COLOR,
      },
    },
  },
}));

const GeneralDetails = ({
  onNext,
  session,
  selectedRole,
  userType,
  goToFinalStep,
}) => {
  const { t } = useI18N();
  const { api } = useAPI();

  const [formDisabled, setFormDisabled] = useState(false);
  const [countryCode, setCountryCode] = useState(null);
  const [accountCreated, setAccountCreated] = useState(false);

  const { register, handleSubmit, formState, control, setValue } = useForm({
    defaultValues,
    mode: "onChange",
    disabled: formDisabled,
  });

  const isIndividual = userType === INDIVIDUAL;

  const loading = useSelector((state) => ({
    register: state.loader?.[loaderPath.register],
    shuftiVerification: state.loader?.[loaderPath.shuftiVerification],
  }));

  const updatedFields = isIndividual
    ? fields?.filter(({ name }) => name !== "business_name")
    : fields;

  const onChangeHandlers = {
    phone_number: (_, data) => setCountryCode(data?.dialCode),
  };

  useEffect(() => {
    if (session) {
      setFormDisabled(true);

      if (session.email && session.phone_number) {
        setAccountCreated(true);
        return;
      }

      fields.forEach(({ name }) => setValue(name, session?.[name]));
      if (!isIndividual) setValue("business_name", session?.business?.name);
    }
  }, [session]);

  const initiateShuftiVerification = async ({ id, email, phone_number }) => {
    const response = await shuftiAPI({
      data: {
        reference: `${id}&email_verification&${Date.now()}`,
        callback_url: process.env.REACT_APP_SHUFTI_CALLBACK_URL,
        redirect_url: `${process.env.REACT_APP_SHUFTI_REDIRECT_URL}registration`,
        email_verify: { email },
        phone: { phone_number },
      },
      needLoader: true,
      loader: loaderPath.shuftiVerification,
    });

    if (response?.status === 200) {
      window.location.href = response.data.verification_url;
    }
  };

  const onSubmit = async (formData) => {
    if (session) {
      initiateShuftiVerification({
        id: session?.id,
        email: session?.email,
        phone_number: session?.phone_number,
      });
      return;
    }

    const payload = {
      ...formData,
      user_type: userType,
      role: selectedRole?.role,
      phone_country_code: `+${countryCode}`,
      phone_number: `+${formData?.phone_number}`,
      fcm_details: await getFCMDetails(),
      language_code: localStorage.getItem("appLang"),
      organization_code: ORGANIZATION_CODE,
    };

    const response = await api({
      method: httpMethods.post,
      endPoint: apiEndpoints.register,
      data: { ...payload },
      needLoader: true,
      loader: loaderPath.register,
      showToastMessage: true,
    });

    if (response?.status) {
      const { access_token, refresh_token } = response.data;
      sessionStorage.setItem("accessToken", access_token);
      sessionStorage.setItem("refreshToken", refresh_token);

      const session = await getSessionDetails({ needLoader: false });

      if (session?.status === 200) {
        const { id, email, phone_number } = session?.data?.data || {};
        initiateShuftiVerification({ id, email, phone_number });
      } else {
        showToast();
      }
    }
  };

  if (accountCreated) {
    return (
      <AccountCreated
        onNext={onNext}
        session={session}
        handleSetupLate={goToFinalStep}
        loading={loading.shuftiVerification}
        shuftiVerification={initiateShuftiVerification}
      />
    );
  }

  return (
    <ContentWrapper>
      <Typography variant="h5" mb={1} fontWeight="bold" textAlign="center">
        {t("general-details")}
      </Typography>
      <Typography
        variant="body2"
        mb={3}
        textAlign="center"
        color="text.secondary"
      >
        {t("Let's start creating your account")}
      </Typography>

      <SAForm onSubmit={handleSubmit(onSubmit)}>
        <Stack spacing={2.5}>
          <StyledFormFields
            spacing={1}
            {...{
              fields: updatedFields,
              register,
              formState,
              control,
              onChangeHandlers,
            }}
          />

          <StyledButton
            fullWidth
            type="submit"
            variant="contained"
            loading={loading.shuftiVerification || loading.register}
          >
            {t("next")}
          </StyledButton>
        </Stack>
      </SAForm>
    </ContentWrapper>
  );
};

export default GeneralDetails;
