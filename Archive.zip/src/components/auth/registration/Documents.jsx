/* eslint-disable no-console */
import CancelIcon from "@mui/icons-material/Cancel";
import InfoIcon from "@mui/icons-material/Info";
import { Box, Typography } from "@mui/material";
import { useState } from "react";
import { useSelector } from "react-redux";

import getSessionDetails from "../../../api/session";
import { INDIVIDUAL, ORGANIZATION_CODE } from "../../../constants";
import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import { loaderPath } from "../../../descriptions/auth/documents.description";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import {
  AuthorizationLetter,
  CommercialRegistration,
  ID,
} from "../../../shared/icon";
import { MUIStyled } from "../../../shared/MUIStyled";
import SAButton from "../../../shared/SAButton";
import SALoader from "../../../shared/SALoader";
import SAStack from "../../../shared/SAStack";
import {
  getS3PresignedUrl,
  uploadToS3,
} from "../../../utils/aws-presigned-url";
import showToast from "../../../utils/toast";

const GOLD_COLOR = "#C5A56F";

const ContentWrapper = MUIStyled(Box)(({ theme }) => ({
  padding: "16px 16px",
  [theme.breakpoints.up("sm")]: { padding: "16px 16px" },
}));

const DocumentItem = MUIStyled(Box)(({ theme }) => ({
  width: "100%",
  display: "flex",
  alignItems: "center",
  padding: "16px",
  backgroundColor: "#fff",
  border: "1px solid #E0E0E0",
  marginBottom: "12px",
  cursor: "pointer",
  transition: "all 0.3s ease",
  "&:hover": { borderColor: "#B0B0B0" },
  "& .icon": {
    width: 40,
    height: 40,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F5F5F5",
    borderRadius: "50%",
    marginRight: "16px",
    "& svg": {
      width: 24,
      height: 24,
      color: GOLD_COLOR,
    },
  },
  "& .content": {
    flex: 1,
  },
  "& .download": {
    color: theme.palette.text.secondary,
  },
}));

const StyledButton = MUIStyled(SAButton)({
  marginTop: 36,
  height: 48,
  borderRadius: 0,
  backgroundColor: GOLD_COLOR,
  color: "#fff",
  "&:hover": { backgroundColor: "#B39355" },
});

const documentsList = [
  {
    icon: <CommercialRegistration />,
    name: "CR_CERTIFICATE",
    title: "commercial-registration",
    description: "commercial-registration-description",
  },
  {
    icon: <AuthorizationLetter />,
    name: "AUTHORIZATION_LETTER",
    title: "authorization-letter",
    description: "authorization-letter-description",
  },
  {
    icon: <ID />,
    name: "VAT_CERTIFICATE",
    title: "vat-certificate",
    description: "vat-certificate-description",
  },
];

const businessDocs = [
  "commercial-registration",
  "authorization-letter",
  "vat-certificate",
];

const Documents = ({
  onNext,
  session,
  userType,
  selectedRole,
  goToFinalStep,
}) => {
  const { t } = useI18N();
  const { api } = useAPI();
  const [uploadedDocuments, setUploadedDocuments] = useState({});
  const [loadingDocuments, setLoadingDocuments] = useState({});

  const isIndividual = selectedRole?.isIndividual && userType === INDIVIDUAL;

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.uploadAllDocuments],
  );

  const updatedDocumentsList = isIndividual
    ? documentsList.filter(({ name }) => !businessDocs.includes(name))
    : documentsList;

  const handleFileUpload = async (event, docType) => {
    event.stopPropagation();

    const file = event.target.files[0];
    if (!file) return;

    const allowedFileTypes = ["image/", "application/pdf", "text/plain"];
    if (!allowedFileTypes.some((type) => file.type.startsWith(type))) {
      showToast("invalid-doc-type-error");
      return;
    }

    const MAX_FILE_SIZE = 5 * 1024 * 1024;
    if (file.size > MAX_FILE_SIZE) {
      showToast("file-size-exceeded-error");
      return;
    }

    const businessID = session?.business?.id;
    const fileExtension = file.name.split(".").pop();
    const PATH = `organization-${ORGANIZATION_CODE}/business-${businessID}/documents/${Date.now()}.${fileExtension}`;

    setLoadingDocuments((prev) => ({ ...prev, [docType]: true }));

    setUploadedDocuments((prev) => ({
      ...prev,
      [docType]: { file, path: PATH, doc_type: docType },
    }));

    setLoadingDocuments((prev) => ({ ...prev, [docType]: false }));
  };

  const handleCancel = (e, docType) => {
    e.stopPropagation();
    setUploadedDocuments((prev) => {
      const updatedDocuments = { ...prev };
      delete updatedDocuments[docType];
      return updatedDocuments;
    });
  };

  const handleNext = async () => {
    const allDocsUploaded = updatedDocumentsList.every(
      ({ name }) => !!uploadedDocuments[name],
    );

    if (!allDocsUploaded) {
      showToast("please-upload-all-documents", { icon: <InfoIcon /> });
      return;
    }

    const payload = Object.values(uploadedDocuments)?.map(({ path, file }) => ({
      name: path,
      content_type: file.type,
    }));

    const presignedURLResponse = await getS3PresignedUrl({
      needLoader: true,
      data: payload,
    });

    if (presignedURLResponse?.status) {
      const presignedURLs = presignedURLResponse?.data;

      const uploadPromises = Object.values(uploadedDocuments)?.map(
        async ({ file, path }) => {
          const awsURL = presignedURLs[path];
          if (!awsURL) return null;

          const response = await uploadToS3({
            file,
            url: awsURL,
            needLoader: true,
          });

          return response;
        },
      );

      const uploadResults = await Promise.all(uploadPromises);
      const failedUploads = uploadResults.filter((result) => !result?.status);

      if (failedUploads.length > 0) {
        console.log("Some uploads failed:", failedUploads);
      }
    }

    const response = await api({
      method: httpMethods.post,
      endPoint: apiEndpoints.uploadBusinessDocs,
      data: { business_documents: Object.values(uploadedDocuments) },
      needLoader: true,
      loader: loaderPath.uploadAllDocuments,
      showToastMessage: true,
    });

    if (response?.status) {
      getSessionDetails({ needLoader: false });
      onNext();
    }
  };

  return (
    <ContentWrapper>
      <Typography variant="h5" mb={1} fontWeight="bold" textAlign="center">
        {t("identity-verification-check")}
      </Typography>
      <Typography
        variant="body2"
        mb={3}
        textAlign="center"
        color="text.secondary"
      >
        {t("documents-subtitle")}
      </Typography>

      <SAStack spacing={2}>
        {updatedDocumentsList.map((item, ind) => {
          const { title, name, description, icon } = item;
          return (
            <DocumentItem
              key={ind}
              onClick={() => document.getElementById(name).click()}
            >
              <Box className="icon">{icon}</Box>
              <Box className="content">
                <Typography variant="subtitle1" fontWeight="medium">
                  {t(title)}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {t(description)}
                </Typography>
              </Box>
              <Box className="download">
                {loadingDocuments[name] ? (
                  <SALoader size={18} />
                ) : uploadedDocuments[name] ? (
                  <CancelIcon onClick={(e) => handleCancel(e, name)} />
                ) : (
                  <img
                    src="/icons/download.svg"
                    alt="Download"
                    width={24}
                    height={24}
                  />
                )}
              </Box>
              <input
                id={name}
                type="file"
                style={{ display: "none" }}
                disabled={loadingDocuments[name]}
                accept="image/*,application/pdf"
                onChange={(e) => handleFileUpload(e, name)}
              />
            </DocumentItem>
          );
        })}
      </SAStack>
      <StyledButton
        variant="contained"
        fullWidth
        onClick={handleNext}
        loading={loading}
      >
        {t("Next")}
      </StyledButton>
      <SAButton variant="text" fullWidth onClick={goToFinalStep}>
        {t("set-up-later-button")}
      </SAButton>
    </ContentWrapper>
  );
};

export default Documents;
