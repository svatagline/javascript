import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";

import getSessionDetails from "../../../api/session";
import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  defaultValues,
  fields,
  loaderPath,
} from "../../../descriptions/auth/bankDetails.description";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import { MUIStyled } from "../../../shared/MUIStyled";
import SAButton from "../../../shared/SAButton";
import SAForm from "../../../shared/SAForm";
import SAFormFields from "../../../shared/SAFormFields";
import SAStack from "../../../shared/SAStack";
import SATypography from "../../../shared/SATypography";

const GOLD_COLOR = "#C5A56F";

const StyledButton = MUIStyled(SAButton)({
  height: 48,
  borderRadius: 0,
  backgroundColor: GOLD_COLOR,
  color: "#fff",
  "&:hover": { backgroundColor: "#B39355" },
});

const BankDetails = ({ session, onNext, goToFinalStep }) => {
  const { api } = useAPI();
  const { t } = useI18N();
  const { register, formState, control, handleSubmit, setValue } = useForm({
    mode: "onChange",
    defaultValues,
  });

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.bankAccount],
  );

  useEffect(() => {
    if (session) {
      fields.forEach(({ name }) =>
        setValue(name, session?.bank_details?.[name]),
      );
    }
  }, [session]);

  const onSubmit = async (formData) => {
    const response = await api({
      method: httpMethods.patch,
      endPoint: apiEndpoints.bankAccount,
      data: formData,
      needLoader: true,
      loader: loaderPath.bankAccount,
      showToastMessage: true,
    });
    if (response?.status) {
      getSessionDetails({ needLoader: false });
      onNext();
    }
  };

  return (
    <>
      <SATypography variant="h6" mb={4} fontWeight="bold" textAlign="center">
        {t("set-up-bank-details")}
      </SATypography>
      <SATypography variant="body1" mb={1} fontWeight="bold">
        {t("bank-details-title")}
      </SATypography>
      <SATypography variant="body2" mb={2}>
        {t("bank-details-subtitle")}
      </SATypography>
      <SAForm onSubmit={handleSubmit(onSubmit)}>
        <SAStack spacing={5}>
          <SAFormFields
            spacing={1.5}
            {...{ fields, register, formState, control }}
          />
          <StyledButton
            loading={loading}
            variant="contained"
            type="submit"
            fullWidth
            // onClick={onNext}
          >
            {t("next")}
          </StyledButton>
        </SAStack>
        <SAButton variant="text" fullWidth onClick={goToFinalStep}>
          {t("set-up-later-button")}
        </SAButton>
      </SAForm>
    </>
  );
};

export default BankDetails;
