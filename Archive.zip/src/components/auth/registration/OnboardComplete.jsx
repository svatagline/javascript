import { useNavigate } from "react-router-dom";

import useI18N from "../../../hooks/useI18N";
import { ApprovedDoc } from "../../../shared/icon";
import { MUIStyled } from "../../../shared/MUIStyled";
import SABox from "../../../shared/SABox";
import SAButton from "../../../shared/SAButton";
import SATypography from "../../../shared/SATypography";

const GOLD_COLOR = "#C5A56F";

const StyledButton = MUIStyled(SAButton)({
  height: 48,
  borderRadius: 0,
  backgroundColor: GOLD_COLOR,
  color: "#fff",
  "&:hover": { backgroundColor: "#B39355" },
});

const OnboardComplete = () => {
  const { t } = useI18N();
  const navigate = useNavigate();

  const handleLoginWithMobile = () => {
    ["accessToken", "refreshToken"].forEach((item) =>
      sessionStorage.removeItem(item),
    );
    localStorage.removeItem("setup_later");
    navigate("/login");
  };

  return (
    <>
      <SABox textAlign="center" mt={2} mb={4}>
        <SATypography variant="h4" mb={2} fontWeight="bold">
          {t("onboard-complete-title")}
        </SATypography>
        <SATypography variant="body1" mb={3}>
          {t("onboard-complete-subtitle")}
        </SATypography>
        <ApprovedDoc color={GOLD_COLOR} />
      </SABox>
      <SABox textAlign="center" mb={2}>
        <StyledButton
          fullWidth
          variant="contained"
          onClick={handleLoginWithMobile}
        >
          {t("log-in-with-account-button")}
        </StyledButton>
      </SABox>
    </>
  );
};

export default OnboardComplete;
