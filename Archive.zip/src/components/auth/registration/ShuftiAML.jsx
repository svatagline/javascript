import ShortcutIcon from "@mui/icons-material/Shortcut";
import {
  List,
  ListItem,
  ListItemAvatar,
  ListItemIcon,
  ListItemText,
} from "@mui/material";
import { useSelector } from "react-redux";

import { BUSINESS } from "../../../constants";
import { loaderPath } from "../../../descriptions/auth/shuftiAML.description";
import useI18N from "../../../hooks/useI18N";
import { CommercialRegistration } from "../../../shared/icon";
import { MUIStyled } from "../../../shared/MUIStyled";
import SAButton from "../../../shared/SAButton";
import SATypography from "../../../shared/SATypography";
import { shuftiAPI } from "../../../utils/functions";

const GOLD_COLOR = "#C5A56F";

const StyledButton = MUIStyled(SAButton)({
  marginTop: 36,
  height: 48,
  borderRadius: 0,
  backgroundColor: GOLD_COLOR,
  color: "#fff",
  "&:hover": { backgroundColor: "#B39355" },
});

const ShuftiAMLRedirect = MUIStyled(List)(({ theme }) => ({
  "& .MuiListItem-root": {
    borderBottom: `1px solid ${theme.palette.gray.main}40`,
    cursor: "pointer",
    position: "relative",
    "&:hover": {
      backgroundColor: `${theme.palette.gray.light}10`,
    },
    "& .MuiListItemAvatar-root": {
      height: 56,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: "100%",
      backgroundColor: `${theme.palette.gray.main}20`,
      marginRight: 20,
    },
    "& .MuiListItemIcon-root": {
      height: 56,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    },
  },
}));

const ShuftiAML = ({ session, goToFinalStep, selectedRole, userType }) => {
  const { t } = useI18N();
  const loading = useSelector((state) => state.loader?.[loaderPath.shuftiAML]);

  const handleNext = async () => {
    if (!session) return;

    const { id } = session;
    const isBusiness = !selectedRole?.isIndividual && userType === BUSINESS;

    const response = await shuftiAPI({
      data: {
        reference: `${id}&${isBusiness ? "business" : "individual"}_verification&${Date.now()}`,
        callback_url: process.env.REACT_APP_SHUFTI_CALLBACK_URL,
        redirect_url: `${process.env.REACT_APP_SHUFTI_REDIRECT_URL}registration`,
        show_consent: false,
        open_webview: false,
        face: {
          allow_offline: "1",
          allow_online: "1",
          verification_mode: "any",
          check_duplicate_request: "1",
        },
        document: {
          proof: "",
          additional_proof: "",
          supported_types: ["id_card", "driving_license", "passport"],
          name: {
            first_name: session.first_name,
            last_name: session.last_name,
          },
          allow_offline: "1",
          fetch_enhanced_data: "1",
          backside_proof_required: "0",
          show_ocr_form: "1",
        },
        background_checks: {
          name: {
            first_name: session.first_name,
            middle_name: session.middle_name,
            last_name: session.last_name,
          },
          filters: ["sanction", "fitness-probity", "warning", "pep"],
        },
        ...(isBusiness
          ? {
              aml_for_businesses: {
                business_name: session?.business?.name,
                filters: [
                  "sanction",
                  "warning",
                  "fitness-probity",
                  "pep",
                  "pep-class-1",
                  "pep-class-2",
                  "pep-class-3",
                  "pep-class-4",
                ],
              },
              questionnaire: {
                questionnaire_type: "post_kyc",
                uuid: ["oeHWL0"],
              },
            }
          : {}),
      },
      needLoader: true,
      loader: loaderPath.shuftiAML,
    });

    if (response?.status === 200) {
      const { verification_url } = response.data;
      window.location.href = verification_url;
    }

    // onNext();
  };

  return (
    <>
      <SATypography variant="h5" mb={1} fontWeight="bold" textAlign="center">
        {t("shufti-aml-check")}
      </SATypography>
      <SATypography
        variant="body2"
        mb={3}
        textAlign="center"
        color="text.secondary"
      >
        {t("id-verification-subtitle")}
      </SATypography>
      <ShuftiAMLRedirect onClick={handleNext}>
        <ListItem>
          <ListItemAvatar>
            <CommercialRegistration />
          </ListItemAvatar>
          <ListItemText
            primary={t("business-aml-verification")}
            secondary={t("business-aml-verification-description")}
          />
          <ListItemIcon>
            <ShortcutIcon />
          </ListItemIcon>
        </ListItem>
      </ShuftiAMLRedirect>
      <StyledButton
        fullWidth
        variant="contained"
        loading={loading}
        onClick={handleNext}
      >
        {t("next")}
      </StyledButton>
      <SAButton fullWidth variant="text" onClick={goToFinalStep}>
        {t("set-up-later-button")}
      </SAButton>
    </>
  );
};

export default ShuftiAML;
