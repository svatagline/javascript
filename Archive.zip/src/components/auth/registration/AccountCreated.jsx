import useI18N from "../../../hooks/useI18N";
import { AccountVerified, Checked } from "../../../shared/icon";
import { MUIStyled } from "../../../shared/MUIStyled";
import SABox from "../../../shared/SABox";
import SAButton from "../../../shared/SAButton";
import SAStack from "../../../shared/SAStack";
import SATypography from "../../../shared/SATypography";

const GOLD_COLOR = "#C5A56F";

const StyledButton = MUIStyled(SAButton)({
  height: 48,
  borderRadius: 0,
  backgroundColor: GOLD_COLOR,
  color: "#fff",
  "&:hover": { backgroundColor: "#B39355" },
});

const AccountCreated = ({
  onNext,
  session,
  loading,
  handleSetupLate,
  shuftiVerification,
}) => {
  const { t } = useI18N();

  const isShuftiVerified = session?.email_verified;

  const subTitle = isShuftiVerified
    ? "account-created-subtitle"
    : "verify-email-phone-subtitle";

  const buttonText = isShuftiVerified
    ? "set-up-account-button"
    : "verify-email-phone-button";

  const handleNext = () => {
    isShuftiVerified
      ? onNext()
      : shuftiVerification({
          id: session?.id,
          email: session?.email,
          phone_number: session?.phone_number,
        });
  };

  return (
    <>
      <SABox textAlign="center" mt={2} mb={4}>
        <SATypography variant="h5" mb={2} fontWeight="bold">
          {t("account-created-title")}
        </SATypography>
        <SATypography variant="body1" mb={3}>
          {t(subTitle)}
        </SATypography>
        {isShuftiVerified ? (
          <Checked color={GOLD_COLOR} />
        ) : (
          <AccountVerified color={GOLD_COLOR} />
        )}
      </SABox>
      <SAStack textAlign="center" gap={1} mb={2}>
        <StyledButton
          fullWidth
          variant="contained"
          onClick={handleNext}
          loading={loading}
        >
          {t(buttonText)}
        </StyledButton>
        <SAButton variant="text" fullWidth onClick={handleSetupLate}>
          {t("set-up-later-button")}
        </SAButton>
      </SAStack>
    </>
  );
};

export default AccountCreated;
