import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import { useDispatch, useSelector } from "react-redux";

import useI18N from "../../../hooks/useI18N";
import { setAppLanguage } from "../../../redux/slices/app.slices";
import { MUIStyled } from "../../../shared/MUIStyled";
import SAButton from "../../../shared/SAButton";
import SAStack from "../../../shared/SAStack";
import SATypography from "../../../shared/SATypography";

const GOLD_COLOR = "#C5A56F";

const StyledButton = MUIStyled(SAButton)(({ variant }) => ({
  height: 48,
  borderRadius: 0,
  color: GOLD_COLOR,
  ...(variant === "contained" && {
    backgroundColor: GOLD_COLOR,
    color: "#fff",
    "&:hover": { backgroundColor: "#B39355" },
  }),
  ...(variant === "outlined" && {
    borderColor: GOLD_COLOR,
    color: GOLD_COLOR,
    "&:hover": { borderColor: "#B39355", color: "#B39355" },
  }),
}));

const LanguageSelection = ({ onNext }) => {
  const { t } = useI18N();
  const dispatch = useDispatch();

  const language = useSelector((state) => state.app?.language);

  const handleChangeLanguage = (lang) => dispatch(setAppLanguage(lang));

  return (
    <>
      <SATypography variant="h5" mb={2} fontWeight="bold" textAlign="center">
        {t("language-selection-title")}
      </SATypography>
      <SATypography variant="body1" mb={3}>
        {t("language-selection-subtitle")}
      </SATypography>
      <SAStack direction="row" gap={4} mt={4} mb={4} dir="ltr">
        <StyledButton
          fullWidth
          variant={language === "en" ? "contained" : ""}
          onClick={() => handleChangeLanguage("en")}
        >
          English
        </StyledButton>
        <StyledButton
          fullWidth
          cvo
          variant={language === "ar" ? "contained" : ""}
          onClick={() => handleChangeLanguage("ar")}
        >
          العربية
        </StyledButton>
      </SAStack>
      <StyledButton fullWidth variant="outlined" onClick={onNext}>
        <ArrowForwardIcon />
      </StyledButton>
    </>
  );
};

export default LanguageSelection;
