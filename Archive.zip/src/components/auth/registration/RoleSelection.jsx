import InfoIcon from "@mui/icons-material/Info";
import {
  FormControlLabel,
  List,
  ListItem,
  Radio,
  RadioGroup,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import { useNavigate } from "react-router-dom";

import { BUSINESS, INDIVIDUAL } from "../../../constants";
import { userRoles } from "../../../descriptions/auth/registration.description";
import useI18N from "../../../hooks/useI18N";
import { MUIStyled } from "../../../shared/MUIStyled";
import SABox from "../../../shared/SABox";
import SAButton from "../../../shared/SAButton";
import SAStack from "../../../shared/SAStack";
import SATypography from "../../../shared/SATypography";
import showToast from "../../../utils/toast";

// Color constants
const GOLD_COLOR = "#C5A56F";

const ContentWrapper = MUIStyled(SABox)(({ theme }) => ({
  maxWidth: 600,
  padding: "24px 16px",
  margin: "0 auto",
  [theme.breakpoints.down("sm")]: { padding: "16px 12px" },
}));

const SelectedUser = MUIStyled(SAStack)(({ theme }) => ({
  padding: theme.spacing(2),
  border: `1px solid ${GOLD_COLOR}`,
  borderRadius: 0,
  textAlign: "center",
  marginBottom: theme.spacing(3),
  [theme.breakpoints.down("sm")]: {
    padding: theme.spacing(1.5),
    marginBottom: theme.spacing(2),
  },
  "& .MuiBox-root": {
    width: 60,
    height: 60,
    padding: theme.spacing(1.25),
    backgroundColor: "#eee",
    borderRadius: "100%",
    margin: "0 auto 16px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    [theme.breakpoints.down("sm")]: {
      width: 50,
      height: 50,
      marginBottom: theme.spacing(1.5),
    },
    "& svg": { color: GOLD_COLOR },
  },
  "& .MuiFormControlLabel-root": {
    "& .MuiRadio-root": {
      color: GOLD_COLOR,
      "&.Mui-checked": { color: GOLD_COLOR },
    },
  },
}));

const UsersList = MUIStyled(List)(({ theme }) => ({
  padding: 0,
  display: "grid",
  gap: theme.spacing(2),
  gridTemplateColumns: "repeat(3, 1fr)",
  marginBottom: theme.spacing(3),
  [theme.breakpoints.down("sm")]: {
    gap: theme.spacing(1.5),
    gridTemplateColumns: "repeat(3, 1fr)",
    marginBottom: theme.spacing(2),
  },
  "& .MuiListItem-root": {
    border: `1px solid ${theme.palette.grey[300]}`,
    padding: theme.spacing(2, 1.5),
    borderRadius: 0,
    textAlign: "center",
    display: "block",
    cursor: "pointer",
    transition: "all 0.3s ease",
    [theme.breakpoints.down("sm")]: { padding: theme.spacing(1.5, 1) },
    "&:hover": { borderColor: GOLD_COLOR },
    "& .MuiBox-root": {
      backgroundColor: "#eee",
      padding: theme.spacing(1.25),
      width: 50,
      height: 50,
      borderRadius: "100%",
      margin: "0 auto 12px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      [theme.breakpoints.down("sm")]: {
        width: 40,
        height: 40,
        marginBottom: theme.spacing(1),
      },
      "& svg": { color: GOLD_COLOR },
    },
  },
}));

const StyledButton = MUIStyled(SAButton)(({ theme, variant }) => ({
  height: 48,
  borderRadius: 0,
  [theme.breakpoints.down("sm")]: { height: 44 },
  ...(variant === "contained" && {
    color: "#fff",
    backgroundColor: GOLD_COLOR,
    "&:hover": { backgroundColor: "#B39355" },
  }),
  ...(variant === "outlined" && {
    color: GOLD_COLOR,
    borderColor: GOLD_COLOR,
    "&:hover": { borderColor: "#B39355", color: "#B39355" },
  }),
}));

const RoleSelection = ({
  onNext,
  userType,
  onPrevious,
  setUserType,
  selectedRole,
  setSelectedRole,
}) => {
  const { t } = useI18N();
  const theme = useTheme();
  const navigate = useNavigate();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const userTypeRadio = [
    { value: INDIVIDUAL, label: "individual" },
    { value: BUSINESS, label: "business" },
  ];

  const handleRadio = (e) => setUserType(e.target.value);

  const handleRoleSelect = (name) => {
    const role = name ? name.toLowerCase() : "refinery";
    setSelectedRole(userRoles[role]);
  };

  const handleNext = () => {
    if (!selectedRole) {
      showToast("please-select-role", { icon: <InfoIcon /> });
      return;
    }
    onNext();
  };

  return (
    <>
      <ContentWrapper>
        <SATypography
          variant="h5"
          mb={2}
          fontWeight="bold"
          textAlign="center"
          sx={{
            [theme.breakpoints.down("sm")]: { mb: 1.5, fontSize: "1.5rem" },
          }}
        >
          {t("How would you like to use Sooq Al Thahab Cloud?")}
        </SATypography>
        <SATypography
          mb={3}
          variant="body2"
          textAlign="center"
          color="text.secondary"
          sx={{
            [theme.breakpoints.down("sm")]: { mb: 2, fontSize: "0.875rem" },
          }}
        >
          {t(selectedRole?.title)}
        </SATypography>
        <SelectedUser>
          <SABox>{selectedRole?.icon}</SABox>
          <SATypography
            variant="h6"
            sx={{ [theme.breakpoints.down("sm")]: { fontSize: "1.1rem" } }}
          >
            {t(selectedRole?.name)}
          </SATypography>
          {selectedRole?.isIndividual && (
            <RadioGroup
              row
              value={userType}
              onChange={handleRadio}
              sx={{
                mt: 2,
                justifyContent: "center",
                [theme.breakpoints.down("sm")]: { mt: 1.5 },
              }}
            >
              {userTypeRadio.map(({ label, value }, ind) => (
                <FormControlLabel
                  key={ind}
                  value={value}
                  label={t(label)}
                  control={<Radio />}
                />
              ))}
            </RadioGroup>
          )}
        </SelectedUser>

        <UsersList>
          {Object.entries(userRoles).map(([key, user]) => {
            const { name, icon } = user;
            if (name === selectedRole?.name) return null;
            return (
              <ListItem key={key} onClick={() => handleRoleSelect(name)}>
                <SABox>{icon}</SABox>
                <SATypography
                  variant="body1"
                  sx={{
                    [theme.breakpoints.down("sm")]: { fontSize: "0.875rem" },
                  }}
                >
                  {t(name)}
                </SATypography>
              </ListItem>
            );
          })}
        </UsersList>

        <SAStack
          mt={4}
          gap={2}
          direction="row"
          sx={{ [theme.breakpoints.down("sm")]: { mt: 3, gap: 1.5 } }}
        >
          {!isMobile && (
            <StyledButton variant="outlined" fullWidth onClick={onPrevious}>
              {t("previous")}
            </StyledButton>
          )}
          <StyledButton variant="contained" fullWidth onClick={handleNext}>
            {t("next")}
          </StyledButton>
        </SAStack>
        <SATypography
          mt={4}
          variant="body2"
          textAlign="center"
          fontWeight="bold"
          color="text.secondary"
          sx={{
            [theme.breakpoints.down("sm")]: { mt: 3, fontSize: "0.875rem" },
          }}
        >
          Already have an account?{" "}
          <SATypography
            component="span"
            variant="body2"
            sx={{
              color: GOLD_COLOR,
              textDecoration: "underline",
              cursor: "pointer",
              "&:hover": { color: "#B39355" },
              [theme.breakpoints.down("sm")]: { fontSize: "0.875rem" },
            }}
            onClick={() => navigate("/login")}
          >
            Log In
          </SATypography>
        </SATypography>
      </ContentWrapper>
    </>
  );
};

export default RoleSelection;
