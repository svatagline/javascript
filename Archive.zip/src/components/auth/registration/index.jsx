import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useSearchParams } from "react-router-dom";

import getSessionDetails from "../../../api/session";
import Logo from "../../../assets/images/logo.png";
import { BUSINESS, INDIVIDUAL } from "../../../constants";
import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  loaderPath,
  userRoles,
} from "../../../descriptions/auth/registration.description";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import { addAppData, setAppLanguage } from "../../../redux/slices/app.slices";
import { MUIStyled } from "../../../shared/MUIStyled";
import SABox from "../../../shared/SABox";
import SALoader from "../../../shared/SALoader";
import SAStack from "../../../shared/SAStack";
import SATypography from "../../../shared/SATypography";
import theme from "../../../themes/theme";
import Address from "./Address";
import BankDetails from "./BankDetails";
import Documents from "./Documents";
import GeneralDetails from "./GeneralDetails";
import LanguageSelection from "./LanguageSelection";
import OnboardComplete from "./OnboardComplete";
import RoleSelection from "./RoleSelection";
import ShuftiAML from "./ShuftiAML";

const GOLD_COLOR = "#C5A56F";

const RegistrationWrapper = MUIStyled(SAStack)({
  padding: 15,
  minHeight: "100vh",
  backgroundColor: "#111",
});

const Stepper = MUIStyled(SAStack)(() => ({
  justifyContent: "center",
  "& span": { height: 6, borderRadius: 0 },
}));

const stepComponents = {
  languageSelection: LanguageSelection,
  roleSelection: RoleSelection,
  generalDetails: GeneralDetails,
  address: Address,
  bankDetails: BankDetails,
  documents: Documents,
  shuftiAML: ShuftiAML,
};

const excludedSteps = [0, 1];

const Registration = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const dispatch = useDispatch();
  const [searchParams] = useSearchParams();

  const [finalStep, setFinalStep] = useState(false);
  const [userType, setUserType] = useState(BUSINESS);
  const [selectedRole, setSelectedRole] = useState(userRoles.refinery);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  const session = useSelector((state) => state.userProfile?.session);
  const loading = useSelector((state) => ({
    session: state.loader?.session,
    getAddresses: state.loader?.[loaderPath.getAddresses],
  }));

  // Dynamically filter steps based on userType
  const steps = [
    "languageSelection",
    "roleSelection",
    "generalDetails",
    "address",
    "bankDetails",
    ...(userType === INDIVIDUAL ? [] : ["documents"]),
    "shuftiAML",
  ];

  const CurrentStepComponent = stepComponents[steps[currentStepIndex]];

  useEffect(() => {
    const fetchData = async () => {
      const [sessionResponse, addressesResponse] = await Promise.all([
        getSessionDetails(),
        getUserAddresses(),
      ]);

      if (
        sessionResponse?.data?.status_code === 200 &&
        addressesResponse?.status
      ) {
        const session = sessionResponse?.data?.data || {};

        setUserType(session.user_type);
        setSelectedRole(userRoles[session.role] || userRoles.refinery);
        determineCurrentStep({ session, addresses: addressesResponse?.data });
      }
    };

    const token = searchParams.get("t");
    if (token) sessionStorage.setItem("accessToken", token);

    if (localStorage.getItem("setup_later")) {
      setFinalStep(true);
    } else if (token || sessionStorage.getItem("accessToken")) {
      fetchData();
    }
  }, []);

  const determineCurrentStep = ({ session, addresses }) => {
    const {
      email,
      phone_number,
      bank_details,
      document_verified,
      email_verified,
      phone_verified,
      business,
      user_preferences,
      face_verified,
    } = session;

    dispatch(setAppLanguage(user_preferences?.language_code || "en"));

    if (!email && !phone_number) setCurrentStepIndex(1);
    else if (!email_verified || !phone_verified) setCurrentStepIndex(2);
    else if (!addresses?.count) setCurrentStepIndex(2);
    else if (!bank_details?.account_number) setCurrentStepIndex(4);
    else if (userType !== INDIVIDUAL && !business?.business_documents?.length) {
      setCurrentStepIndex(5);
    } else if (!document_verified || !face_verified)
      setCurrentStepIndex(userType === INDIVIDUAL ? 5 : 6);
    else setFinalStep(true);
  };

  const getUserAddresses = async () => {
    const response = await api({
      method: httpMethods.get,
      endPoint: apiEndpoints.getUserAddresses,
      needLoader: true,
      loader: loaderPath.getAddresses,
    });

    if (response?.status) {
      dispatch(addAppData({ name: "addresses", data: response.data }));
    }

    return response;
  };

  const handleNext = () => {
    if (currentStepIndex < steps.length - 1) {
      setCurrentStepIndex((prev) => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStepIndex > 0) setCurrentStepIndex((prev) => prev - 1);
  };

  const goToFinalStep = () => {
    setFinalStep(true);
    localStorage.setItem("setup_later", true);
  };

  return (
    <RegistrationWrapper alignItems="center" justifyContent="center">
      {loading.session || loading.getAddresses ? (
        <SABox>
          <SALoader size={50} color="#c9c9c9" secondaryColor="#444" />
        </SABox>
      ) : (
        <>
          <SABox mb={3} mt={{ xs: 2 }} textAlign="center">
            <img src={Logo} alt="sooq-althahab-logo" />
          </SABox>
          <SAStack
            width="100%"
            maxWidth={{ sm: 675, xs: "100%" }}
            p={{ sm: 4, xs: 2 }}
            backgroundColor={theme.palette.white.main}
          >
            {finalStep ? (
              <OnboardComplete />
            ) : (
              <>
                {excludedSteps.includes(currentStepIndex) ? null : (
                  <Stepper direction="row" spacing={1} dir="ltr">
                    {steps.map((name, index) =>
                      excludedSteps.includes(index) ? null : (
                        <SATypography
                          key={name}
                          component="span"
                          sx={{
                            width: currentStepIndex === index ? 36 : 6,
                            backgroundColor:
                              currentStepIndex === index
                                ? theme.palette.primary.main
                                : theme.palette.gray.light500,
                          }}
                        />
                      ),
                    )}
                  </Stepper>
                )}
                <CurrentStepComponent
                  {...{
                    userType,
                    setUserType,
                    selectedRole,
                    goToFinalStep,
                    setSelectedRole,
                    onNext: handleNext,
                    onPrevious: handlePrevious,
                    session: Object.keys(session)?.length ? session : null,
                  }}
                />
              </>
            )}
            {!excludedSteps.includes(currentStepIndex) && !finalStep ? (
              <SATypography
                variant="caption"
                textAlign="center"
                color="text.secondary"
              >
                {t("By registering, you accept our")}{" "}
                <SATypography
                  component="span"
                  variant="caption"
                  sx={{
                    color: GOLD_COLOR,
                    cursor: "pointer",
                    textDecoration: "underline",
                    "&:hover": { color: "#B39355" },
                  }}
                >
                  {t("Terms & Conditions")}
                </SATypography>{" "}
                {t("and")}{" "}
                <SATypography
                  component="span"
                  variant="caption"
                  sx={{
                    color: GOLD_COLOR,
                    cursor: "pointer",
                    textDecoration: "underline",
                    "&:hover": { color: "#B39355" },
                  }}
                >
                  {t("Privacy Policy")}
                </SATypography>
                .{" "}
                <SATypography
                  component="span"
                  variant="caption"
                  color="text.secondary"
                >
                  {t("Your data will be securely encrypted with TLS.")} 🔒
                </SATypography>
              </SATypography>
            ) : null}
          </SAStack>
        </>
      )}
    </RegistrationWrapper>
  );
};

export default Registration;
