import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";

import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  defaultValues,
  fields,
  loaderPath,
} from "../../../descriptions/auth/resetPassword.description";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import { MUIStyled } from "../../../shared/MUIStyled";
import SABox from "../../../shared/SABox";
import SAButton from "../../../shared/SAButton";
import SAForm from "../../../shared/SAForm";
import SAFormFields from "../../../shared/SAFormFields";
import SAStack from "../../../shared/SAStack";
import SATypography from "../../../shared/SATypography";
import theme from "../../../themes/theme";

const ResetPasswordWrapper = MUIStyled(SAStack)(({ theme }) => ({
  padding: 15,
  minHeight: "100vh",
  backgroundColor: theme.palette.primary.dark100,
}));

const ResetPassword = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const location = useLocation();
  const navigate = useNavigate();
  const { register, handleSubmit, formState, setError } = useForm({
    defaultValues,
    mode: "onChange",
  });

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.resetPassword],
  );

  useEffect(() => {
    if (!location?.state?.token) navigate("/forgot-password");
  }, []);

  const onSubmit = async (formData) => {
    if (formData?.password !== formData?.confirmPassword) {
      setError("confirmPassword", {
        type: "custom",
        message: t("password-not-match-error"),
      });
      return;
    }

    const response = await api({
      method: httpMethods.post,
      endPoint: apiEndpoints.resetPassword,
      data: { password: formData?.password },
      params: { token: location?.state?.token },
      needLoader: true,
      loader: loaderPath.resetPassword,
      showToastMessage: true,
    });

    if (response?.status) navigate("/login");
  };

  return (
    <ResetPasswordWrapper alignItems="center" justifyContent="center">
      <SAStack
        width="100%"
        maxWidth={545}
        borderRadius={3}
        p={{ lg: 8, sm: 4, xs: 2 }}
        backgroundColor={theme.palette.white.main}
      >
        <SATypography variant="h4" mb={1} fontWeight="bold">
          {t("reset-password")}
        </SATypography>{" "}
        <SATypography variant="p" mb={6}>
          {t("reset-password-description")}
        </SATypography>
        <SAForm onSubmit={handleSubmit(onSubmit)}>
          <SAStack spacing={4}>
            <SAFormFields spacing={2} {...{ fields, register, formState }} />
            <SABox textAlign="center">
              <SAButton
                type="submit"
                color="primary"
                variant="contained"
                loading={loading}
              >
                {t("update")}
              </SAButton>
            </SABox>
          </SAStack>
        </SAForm>
      </SAStack>
    </ResetPasswordWrapper>
  );
};

export default ResetPassword;
