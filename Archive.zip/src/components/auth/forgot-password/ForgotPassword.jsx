import KeyboardBackspaceIcon from "@mui/icons-material/KeyboardBackspace";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  defaultValues,
  fields,
  loaderPath,
} from "../../../descriptions/auth/forgotPassword.description";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import { MUIStyled } from "../../../shared/MUIStyled";
import SABox from "../../../shared/SABox";
import SAButton from "../../../shared/SAButton";
import SAForm from "../../../shared/SAForm";
import SAFormFields from "../../../shared/SAFormFields";
import SAStack from "../../../shared/SAStack";
import SATypography from "../../../shared/SATypography";
import theme from "../../../themes/theme";

const ForgotPasswordWrapper = MUIStyled(SAStack)(({ theme }) => ({
  padding: 15,
  minHeight: "100vh",
  backgroundColor: theme.palette.primary.dark100,
}));

const ForgotPassword = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const navigate = useNavigate();
  const { register, handleSubmit, formState } = useForm({
    mode: "onChange",
    defaultValues,
  });

  const loading = useSelector(
    (state) => state.loader?.[loaderPath.forgotPassword],
  );

  const onSubmit = async (formData) => {
    const response = await api({
      method: httpMethods.post,
      endPoint: apiEndpoints.sendForgotPasswordOTP,
      data: { ...formData },
      needLoader: true,
      loader: loaderPath.forgotPassword,
      showToastMessage: true,
    });
    if (response?.status) {
      const { token } = response?.data || {};
      navigate("/verify-otp", { state: { email: formData?.email, token } });
    }
  };

  return (
    <ForgotPasswordWrapper alignItems="center" justifyContent="center">
      <SAStack
        maxWidth={545}
        borderRadius={3}
        p={{ lg: 8, sm: 4, xs: 2 }}
        backgroundColor={theme.palette.white.main}
      >
        <SATypography variant="h4" mb={1} fontWeight="bold">
          {t("forgot-password")}
        </SATypography>
        <SATypography variant="p" mb={6}>
          {t("forgot-password-description")}
        </SATypography>
        <SAForm onSubmit={handleSubmit(onSubmit)}>
          <SAStack spacing={4}>
            <SAFormFields {...{ fields, register, formState }} />
            <SABox textAlign="center">
              <SAButton
                type="submit"
                color="primary"
                variant="contained"
                loading={loading}
              >
                {t("send-otp-button")}
              </SAButton>
            </SABox>
          </SAStack>
        </SAForm>
        <SAStack
          mt={3}
          gap={1}
          direction="row"
          alignItems="center"
          justifyContent="center"
          sx={{ cursor: "pointer" }}
          onClick={() => navigate("/login")}
        >
          <KeyboardBackspaceIcon /> {t("return-to-login")}
        </SAStack>
      </SAStack>
    </ForgotPasswordWrapper>
  );
};

export default ForgotPassword;
