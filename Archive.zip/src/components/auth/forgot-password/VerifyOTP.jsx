import KeyboardBackspaceIcon from "@mui/icons-material/KeyboardBackspace";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";

import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import { loaderPath } from "../../../descriptions/auth/forgotPassword.description";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import { MUIStyled } from "../../../shared/MUIStyled";
import SABox from "../../../shared/SABox";
import SAButton from "../../../shared/SAButton";
import SALoader from "../../../shared/SALoader";
import SAOTPInput from "../../../shared/SAOTPInput";
import SAStack from "../../../shared/SAStack";
import SATypography from "../../../shared/SATypography";
import theme from "../../../themes/theme";
import showToast from "../../../utils/toast";

const OTPVerifyWrapper = MUIStyled(SAStack)(({ theme }) => ({
  padding: 15,
  minHeight: "100vh",
  backgroundColor: theme.palette.primary.dark100,
}));

const VerifyOTP = () => {
  const { t } = useI18N();
  const { api } = useAPI();
  const navigate = useNavigate();
  const location = useLocation();

  const [tempToken, setTempToken] = useState(null);
  const [OTP, setOTP] = useState({ value: "", error: "" });

  const loading = useSelector((state) => ({
    verifyOTP: state.loader?.[loaderPath.verifyOTP],
    resendOTP: state.loader?.[loaderPath.resendOTP],
  }));

  useEffect(() => {
    const { email, token } = location?.state || {};
    if (!email || !token) navigate("/forgot-password");
  }, []);

  const handleOTPChange = (value) => setOTP({ value, error: "" });

  const handleOTPSubmit = async () => {
    if (!OTP.value || OTP.value.length < 6) {
      setOTP((prev) => ({ ...prev, error: true }));
      showToast("otp-required-error");
      return;
    }

    const response = await api({
      method: httpMethods.post,
      endPoint: apiEndpoints.verifyOTP,
      data: { otp: OTP.value },
      params: { token: tempToken || location?.state?.token },
      needLoader: true,
      loader: loaderPath.verifyOTP,
      showToastMessage: true,
    });

    if (response?.status) {
      navigate("/reset-password", {
        state: { token: tempToken || response?.data?.token },
      });
    }
  };

  const handleResendOTP = async () => {
    const response = await api({
      method: httpMethods.post,
      endPoint: apiEndpoints.sendForgotPasswordOTP,
      data: { email: location?.state?.email },
      needLoader: true,
      loader: loaderPath.resendOTP,
      showToastMessage: true,
    });

    if (response?.status) setTempToken(response?.data?.token);
  };

  return (
    <OTPVerifyWrapper alignItems="center" justifyContent="center">
      <SAStack
        width="100%"
        maxWidth={560}
        borderRadius={3}
        p={{ lg: 8, sm: 4, xs: 2 }}
        backgroundColor={theme.palette.white.main}
      >
        <SATypography variant="h4" mb={1} fontWeight="bold">
          {t("otp-verification")}
        </SATypography>
        <SATypography variant="p" mb={6}>
          {t("otp-verification-description")}
        </SATypography>
        <SAStack spacing={6}>
          <SAOTPInput
            numInputs={6}
            value={OTP.value}
            onChange={handleOTPChange}
            onEnterPress={handleOTPSubmit}
            inputStyle={OTP.error ? { borderColor: "red" } : {}}
          />
          <SABox textAlign="center">
            <SAButton
              color="primary"
              variant="contained"
              onClick={handleOTPSubmit}
              loading={loading.verifyOTP}
            >
              {t("continue")}
            </SAButton>
          </SABox>
        </SAStack>
        <SAStack
          mt={2}
          gap={1}
          direction="row"
          alignItems="center"
          justifyContent="center"
        >
          <SATypography variant="body2">
            {t("did-not-receive-otp")}{" "}
          </SATypography>
          <SAStack direction="row" alignItems="center" gap={1}>
            <span
              onClick={handleResendOTP}
              style={{ fontSize: 14, fontWeight: 600, cursor: "pointer" }}
            >
              {t("resend")}
            </span>
            {loading.resendOTP && <SALoader size={14} />}
          </SAStack>
        </SAStack>
        <SAStack
          mt={3}
          gap={1}
          direction="row"
          alignItems="center"
          justifyContent="center"
          sx={{ cursor: "pointer" }}
          onClick={() => navigate("/login")}
        >
          <KeyboardBackspaceIcon /> {t("return-to-login")}
        </SAStack>
      </SAStack>
    </OTPVerifyWrapper>
  );
};

export default VerifyOTP;
