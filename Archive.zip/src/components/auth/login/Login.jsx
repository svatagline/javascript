import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";

import { ADMIN_ROLES, ORGANIZATION_CODE } from "../../../constants";
import { apiEndpoints, httpMethods } from "../../../constants/api.constants";
import {
  defaultValues,
  fields,
  loaderPath,
} from "../../../descriptions/auth/login.descriptions";
import useAPI from "../../../hooks/useAPI";
import useI18N from "../../../hooks/useI18N";
import MUIGrid from "../../../shared/MUIGrid";
import { MUIStyled } from "../../../shared/MUIStyled";
import SABox from "../../../shared/SABox";
import SAButton from "../../../shared/SAButton";
import SAForm from "../../../shared/SAForm";
import SAFormFields from "../../../shared/SAFormFields";
import SAStack from "../../../shared/SAStack";
import SATypography from "../../../shared/SATypography";
import theme from "../../../themes/theme";
import { decodeToken, getFCMDetails } from "../../../utils/functions";
import showToast from "../../../utils/toast";

const LoginWrapper = MUIStyled(SAStack)({
  padding: 15,
  minHeight: "100vh",
  backgroundColor: "#222",
});

const Login = () => {
  const { api } = useAPI();
  const { t } = useI18N();
  const navigate = useNavigate();
  const { register, handleSubmit, formState } = useForm({
    mode: "onChange",
    defaultValues,
  });

  const loading = useSelector((state) => state.loader?.[loaderPath.login]);

  const onSubmit = async (formData) => {
    const payload = {
      ...formData,
      fcm_details: await getFCMDetails(),
      organization_code: ORGANIZATION_CODE,
    };

    const response = await api({
      method: httpMethods.post,
      endPoint: apiEndpoints.login,
      data: payload,
      needLoader: true,
      loader: loaderPath.login,
      showToastOnError: true,
    });

    if (response?.status) {
      const { token } = response.data;
      const { role } = decodeToken(token?.access_token);

      if (!Object.keys(ADMIN_ROLES).includes(role)) {
        showToast("not-admin-error");
        return;
      }

      localStorage.setItem("accessToken", token?.access_token);
      localStorage.setItem("refreshToken", token?.refresh_token);
      showToast("login-success", { type: "success" });
      navigate("/businesses");
    }
  };

  return (
    <LoginWrapper alignItems="center" justifyContent="center">
      <MUIGrid
        container
        alignItems="center"
        columnSpacing={{ lg: 10, md: 8, sm: 4, xs: 2 }}
      >
        <MUIGrid size={{ md: 5 }}>
          <SAStack
            backgroundColor={theme.palette.white.main}
            p={{ lg: 8, sm: 4, xs: 2 }}
            borderRadius={3}
            width="100%"
            maxWidth={525}
          >
            <SATypography variant="h4" mb={1} fontWeight="bold">
              {t("login")}
            </SATypography>
            <SATypography variant="p" mb={6}>
              {t("login-description")}
            </SATypography>
            <SAForm onSubmit={handleSubmit(onSubmit)}>
              <SAStack spacing={2}>
                <SAFormFields
                  spacing={2}
                  {...{ fields, register, formState }}
                />
                <SATypography
                  variant="body2"
                  textAlign="right"
                  mt={2}
                  sx={{
                    "& a": {
                      textDecoration: "none",
                      color: theme.palette.black.dark,
                    },
                  }}
                >
                  <Link to="/forgot-password">{t("forgot-password-link")}</Link>
                </SATypography>
                <SABox textAlign="center">
                  <SAButton
                    variant="contained"
                    color="primary"
                    type="submit"
                    loading={loading}
                  >
                    {t("login")}
                  </SAButton>
                </SABox>
              </SAStack>
            </SAForm>
          </SAStack>
        </MUIGrid>
        <MUIGrid size={{ md: 7 }} display={{ md: "block", xs: "none" }}>
          <SATypography variant="h2" color="white" fontWeight="bold" mb={2}>
            {t("login-page-title")}
          </SATypography>
          <SATypography color="white" variant="h6" fontWeight="400">
            {t("login-page-subtitle")}
          </SATypography>
        </MUIGrid>
      </MUIGrid>
    </LoginWrapper>
  );
};

export default Login;
