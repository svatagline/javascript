import { lazy } from "react";
import { Navigate } from "react-router-dom";

import ProtectedRoute from "../components/auth/ProtectedRoute";
import PublicRoute from "../components/auth/PublicRoute";
import AppLayout from "../components/layouts/AppLayout";
import AuthLayout from "../components/layouts/AuthLayout";
import ProductSettings from "../components/settings/product-settings";

const ForgotPassword = lazy(() => import("../pages/auth/ForgotPassword.pages"));
const Login = lazy(() => import("../pages/auth/Login.pages"));
const Registration = lazy(() => import("../pages/auth/Registration.pages"));
const ResetPassword = lazy(() => import("../pages/auth/ResetPassword.pages"));
const VerifyOTP = lazy(() => import("../pages/auth/VerifyOTP.pages"));
const Businesses = lazy(() => import("../pages/businesses/Businesses.pages"));
const BusinessesDetails = lazy(
  () => import("../pages/businesses/BusinessesDetails.pages"),
);
const PurchaseRequest = lazy(
  () => import("../pages/purchase-request/PurchaseRequest.pages"),
);
const PurchaseRequestDetails = lazy(
  () => import("../pages/purchase-request/PurchaseRequestDetails.pages"),
);
const GeneralSettings = lazy(
  () => import("../pages/settings/GeneralSettings.pages"),
);
const MetalStoneSettings = lazy(
  () => import("../pages/settings/MetalStoneSetting.pages"),
);
const TaxSettings = lazy(() => import("../pages/settings/TaxSettings.pages"));
const SubAdmins = lazy(() => import("../pages/sub-admins/SubAdmins.pages"));
const SubAdminDetails = lazy(
  () => import("../pages/sub-admins/SubAdminsDetails.pages"),
);
const Transaction = lazy(
  () => import("../pages/transaction/Transaction.pages"),
);
const BankTransfer = lazy(
  () => import("../pages/bank-transfer/BankTransfer.pages"),
);
const TransactionDetail = lazy(
  () => import("../pages/transaction/TransactionDetails.pages"),
);
const UserDetails = lazy(() => import("../pages/users/UserDetails.pages"));
const BankSettings = lazy(() => import("../pages/settings/BankSettings.page"));
const PrivacyPolicy = lazy(() => import("../pages/PrivacyPolicy.pages"));
const TermsAndConditions = lazy(
  () => import("../pages/TermsAndConditions.pages"),
);
const BankTransferDetails = lazy(
  () => import("../pages/bank-transfer/BankTransferDetails.pages"),
);
const MetalsStonesPools = lazy(
  () => import("../pages/metals-stones-pools/MetalsStonesPools.pages"),
);
const MetalsStonesPoolsDetails = lazy(
  () => import("../pages/metals-stones-pools/MetalsStonesPoolsDetails.pages"),
);
const MusharkaContracts = lazy(
  () => import("../pages/musharka-contracts/MusharkaContracts.pages"),
);
const NotFound = lazy(() => import("../pages/NotFound.pages"));

const publicRoutes = [
  {
    path: "/",
    element: <PublicRoute />,
    children: [
      {
        path: "/",
        element: <AuthLayout />,
        children: [
          { path: "login", element: <Login /> },
          { path: "forgot-password", element: <ForgotPassword /> },
          { path: "reset-password", element: <ResetPassword /> },
          { path: "verify-otp", element: <VerifyOTP /> },
        ],
      },
      { path: "registration", element: <Registration /> },
      { path: "privacy-policy", element: <PrivacyPolicy /> },
      { path: "terms-and-conditions", element: <TermsAndConditions /> },
      { path: "*", element: <NotFound /> },
    ],
  },
];

const privateRoutes = [
  {
    path: "/",
    element: <ProtectedRoute />,
    children: [
      {
        path: "/",
        element: <AppLayout />,
        children: [
          { index: true, element: <Navigate to="/businesses" /> },
          {
            path: "businesses",
            element: <Businesses />,
            children: [
              {
                path: ":businessName",
                element: <BusinessesDetails />,
                children: [{ path: ":username", element: <UserDetails /> }],
              },
            ],
          },
          {
            path: "sub-admins",
            element: <SubAdmins />,
            children: [{ path: ":username", element: <SubAdminDetails /> }],
          },
          {
            path: "transactions",
            element: <Transaction />,
            children: [
              { path: ":transactionId", element: <TransactionDetail /> },
            ],
          },
          {
            path: "purchase-requests",
            element: <PurchaseRequest />,
            children: [
              {
                path: ":purchaseRequestsId",
                element: <PurchaseRequestDetails />,
              },
            ],
          },
          {
            path: "bank-transfer-requests",
            element: <BankTransfer />,
            children: [
              { path: ":bankTransferId", element: <BankTransferDetails /> },
            ],
          },
          {
            path: "metals-stones-pools",
            element: <MetalsStonesPools />,
            children: [
              { path: ":poolId", element: <MetalsStonesPoolsDetails /> },
            ],
          },
          { path: "musharka-contracts", element: <MusharkaContracts /> },
          {
            path: "settings",
            children: [
              { index: true, element: <Navigate to="general-settings" /> },
              { path: "general-settings", element: <GeneralSettings /> },
              { path: "tax-settings", element: <TaxSettings /> },
              { path: "metal-stone-setting", element: <MetalStoneSettings /> },
              { path: "product-setting", element: <ProductSettings /> },
              { path: "bank-setting", element: <BankSettings /> },
            ],
          },
        ],
      },
    ],
  },
];

export const routes = [...publicRoutes, ...privateRoutes];
