import { FormControl } from "@mui/material";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";

import MUIFormLabel from "./MUIFormLabel";
import { MUIStyled } from "./MUIStyled";
import SATypography from "./SATypography";

const StyledDatePicker = MUIStyled(DatePicker)(() => ({
  width: "100%",
  "& .MuiInputBase-input": { padding: 8 },
}));

const MUIDatePicker = ({ ...props }) => {
  return (
    <>
      <FormControl
        fullWidth
        sx={{
          "& .MuiFormLabel-root": {
            fontSize: 14,
            fontWeight: 500,
            lineHeight: "1.5",
            marginBottom: 0.5,
            width: "fit-content",
          },
        }}
      >
        {props?.formLabel && (
          <MUIFormLabel>
            {props?.required && (
              <SATypography component="span" color="danger.main">
                *
              </SATypography>
            )}
            {props?.formLabel}
          </MUIFormLabel>
        )}
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <StyledDatePicker {...props} />
        </LocalizationProvider>
      </FormControl>
    </>
  );
};

export default MUIDatePicker;
