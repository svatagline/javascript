import AssuredWorkloadIcon from "@mui/icons-material/AssuredWorkload";
import BusinessCenterIcon from "@mui/icons-material/BusinessCenter";
import CheckOutlinedIcon from "@mui/icons-material/CheckOutlined";
import CloseIcon from "@mui/icons-material/Close";
import CreditScoreIcon from "@mui/icons-material/CreditScore";
import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";
import DiamondIcon from "@mui/icons-material/Diamond";
import EmojiEventsIcon from "@mui/icons-material/EmojiEvents";
import FactoryIcon from "@mui/icons-material/Factory";
import HighlightOffOutlinedIcon from "@mui/icons-material/HighlightOffOutlined";
import LowPriorityOutlinedIcon from "@mui/icons-material/LowPriorityOutlined";
import ModeStandbyIcon from "@mui/icons-material/ModeStandby";
import NotInterestedIcon from "@mui/icons-material/NotInterested";
import PowerSettingsNewIcon from "@mui/icons-material/PowerSettingsNew";
import PrecisionManufacturingIcon from "@mui/icons-material/PrecisionManufacturing";
import ReceiptIcon from "@mui/icons-material/Receipt";
import ReportGmailerrorredOutlinedIcon from "@mui/icons-material/ReportGmailerrorredOutlined";
import ReportProblemOutlinedIcon from "@mui/icons-material/ReportProblemOutlined";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import StorefrontIcon from "@mui/icons-material/Storefront";
import TaskAltIcon from "@mui/icons-material/TaskAlt";
import VerifiedOutlinedIcon from "@mui/icons-material/VerifiedOutlined";
import WatchLaterOutlinedIcon from "@mui/icons-material/WatchLaterOutlined";

import useI18N from "../hooks/useI18N";
import { MUIStyled } from "./MUIStyled";
import MUITooltip from "./MUITooltip";
import SAStack from "./SAStack";
import SATypography from "./SATypography";

const statusConfig = {
  PENDING: {
    label: "pending",
    color: "#D97706",
    background: "#FFFBEB",
    icon: <WatchLaterOutlinedIcon />,
  },
  SUCCESS: {
    label: "success",
    color: "#027A48",
    background: "#ECFDF3",
    icon: <CheckOutlinedIcon />,
  },
  FAILED: {
    label: "failed",
    color: "#B42318",
    background: "#FEF3F2",
    icon: <CloseIcon />,
  },
  APPROVED: {
    label: "approved",
    color: "#027A48",
    background: "#ECFDF3",
    icon: <CheckOutlinedIcon />,
  },
  REJECTED: {
    label: "rejected",
    color: "#B42318",
    background: "#FEF3F2",
    icon: <CloseIcon />,
  },
  COMPLETED: {
    label: "completed",
    color: "#055160",
    background: "#e3f6fa",
    icon: <TaskAltIcon />,
  },
  DEPOSIT: {
    label: "deposit",
    color: "#7c7c7c",
    background: "#F3F3F3",
    icon: <AssuredWorkloadIcon />,
  },
  WITHDRAWAL: {
    label: "withdrawal",
    color: "#a7784d",
    background: "#FDEDE4",
    icon: <CreditScoreIcon />,
  },
  PAYMENT: {
    label: "payment",
    color: "#ab8a21",
    background: "#FAF3DC",
    icon: <ReceiptIcon />,
  },
  PURCHASE: {
    label: "purchase",
    color: "#1E40AF",
    background: "#e8f2fe",
    icon: <ShoppingCartIcon />,
  },
  SALE: {
    label: "sale",
    color: "#9A3412",
    background: "#fff3e8",
    icon: <StorefrontIcon />,
  },
  METAL: {
    label: "metal",
    color: "#a58144",
    background: "#FAF3E0",
    icon: <EmojiEventsIcon />,
  },
  STONE: {
    label: "stone",
    color: "#505dce",
    background: "#eaefff",
    icon: <DiamondIcon />,
  },
  INVESTOR: {
    label: "INVESTOR",
    color: "#b6973e",
    background: "#faf4dd",
    icon: <BusinessCenterIcon />,
  },
  SELLER: {
    label: "SELLER",
    color: "#c18169",
    background: "#fcf0eb",
    icon: <FactoryIcon />,
  },
  JEWELER: {
    label: "DESIGNER",
    color: "#6c92af",
    background: "#eef3f8",
    icon: <DiamondIcon />,
  },
  MANUFACTURER: {
    label: "MANUFACTURER",
    color: "#4aa88a",
    background: "#eaf7f3",
    icon: <PrecisionManufacturingIcon />,
  },
  SUSPENDED: {
    label: "suspended",
    color: "#B42318",
    background: "#FEF3F2",
    icon: <NotInterestedIcon />,
  },
  ACTIVATED: {
    label: "activated",
    color: "#027A48",
    background: "#ECFDF3",
    icon: <VerifiedOutlinedIcon />,
  },
  ENABLED: {
    label: "enabled",
    color: "#027A48",
    background: "#ECFDF3",
    icon: <PowerSettingsNewIcon />,
  },
  DISABLED: {
    label: "disabled",
    color: "#B42318",
    background: "#FEF3F2",
    icon: <NotInterestedIcon />,
  },
  DELETED: {
    label: "deleted",
    color: "#B42318",
    background: "#FEF3F2",
    icon: <DeleteOutlinedIcon />,
  },
  OPEN: {
    label: "open",
    color: "#027A48",
    background: "#ECFDF3",
    icon: <ModeStandbyIcon />,
  },
  CLOSED: {
    label: "closed",
    color: "#B42318",
    background: "#FEF3F2",
    icon: <HighlightOffOutlinedIcon />,
  },
  HIGH: {
    label: "high",
    color: "#B42318",
    background: "#FEF3F2",
    icon: <ReportGmailerrorredOutlinedIcon />,
  },
  MEDIUM: {
    label: "medium",
    color: "#D97706",
    background: "#FFFBEB",
    icon: <ReportProblemOutlinedIcon />,
  },
  LOW: {
    label: "low",
    color: "#027A48",
    background: "#ECFDF3",
    icon: <LowPriorityOutlinedIcon />,
  },
};

const StyledBadge = MUIStyled(SAStack)(({ color, background, tooltip }) => ({
  gap: 4,
  color,
  borderRadius: 16,
  backgroundColor: background,
  padding: "2px 8px",
  width: "fit-content",
  textTransform: "capitalize",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  flexDirection: "row",
  "& svg": { height: 16, width: 16 },
  ...(tooltip
    ? {
        cursor: "pointer",
        textDecoration: "underline dashed",
        textUnderlineOffset: 3,
        "&:hover": { textDecoration: "none" },
      }
    : {}),
}));

const SAStatusBadge = ({ status, tooltip = false, title = "" }) => {
  const { t } = useI18N();
  const { icon, color, background, label } = statusConfig[status] || {};

  const Badge = (
    <StyledBadge {...{ color, background, tooltip }}>
      {icon}
      <SATypography fontSize="14px" fontWeight={500}>
        {t(label)}
      </SATypography>
    </StyledBadge>
  );

  return tooltip ? (
    <MUITooltip title={title || t(status)}>{Badge}</MUITooltip>
  ) : (
    Badge
  );
};

export default SAStatusBadge;
