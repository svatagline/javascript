import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableSortLabel,
} from "@mui/material";

import useI18N from "../hooks/useI18N";
import { SortIcon } from "./icon";
import MUIPagination from "./MUIPagination";
import { MUIStyled } from "./MUIStyled";
import SABasicTableSkeleton from "./SABasicTableSkeleton";
import SABox from "./SABox";
import SATypography from "./SATypography";

const StyledTableContainer = MUIStyled(TableContainer)(
  ({ loading, theme }) => ({
    border: `1px solid ${theme.palette.gray.light500}`,
    borderRadius: 10,
    position: "relative",
    "& .MuiTable-root": {
      "& .MuiTableHead-root": {
        "& .MuiTableRow-root": {
          "& .MuiTableCell-root": {
            "& .MuiButtonBase-root": { gap: 10 },
            backgroundColor: theme.palette.gray.light700,
          },
        },
      },
      "& .MuiTableBody-root": {
        "& .MuiTableRow-root": { "& .MuiTableCell-root": { fontSize: 14 } },
        "& .tableCommonRow": { filter: loading ? "blur(2px)" : "" },
      },
    },
    "& .paginationBox": {
      bottom: 0,
      position: "sticky",
      backgroundColor: theme.palette.white.main,
    },
    "& .MuiTableContainer-root": { position: loading ? "relative" : "static" },
    "& .tableLoaderBox": {
      top: "50%",
      left: "50%",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      position: "absolute",
      transform: "translate(-50%, -50%)",
    },
    "& .TableBox": { overflow: "auto", maxHeight: "calc(100vh - 275px)" },
    "& .noDataFound": {
      position: "relative",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      minHeight: "30vh",
    },
  }),
);

const freezeProperty = {
  userSelect: "none",
  pointerEvents: "none",
  position: "relative",
};

const SABasicTable = ({
  loading,
  data,
  columns,
  renderCell,
  paginationProps,
  onSort = () => {},
}) => {
  const { t, dir } = useI18N();

  const TableValue = ({ column, row, rowIndex }) => {
    return renderCell
      ? renderCell(
          column.key,
          row,
          rowIndex,
          ["string", "number", "boolean"].includes(typeof row?.[column?.key])
            ? row?.[column?.key]
            : "-",
        )
      : row[column.key];
  };
  return (
    <>
      <StyledTableContainer
        loading={loading}
        sx={{ ...(loading ? freezeProperty : {}) }}
      >
        <SABox className="TableBox">
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                {columns?.map(({ key, label, align, sorting, sortType }) => (
                  <TableCell
                    key={key}
                    align={align || (dir === "rtl" ? "right" : "left")}
                  >
                    {sorting ? (
                      <TableSortLabel
                        onClick={() => onSort({ key, sortType })}
                        IconComponent={() => (
                          <span style={{ minWidth: "50px", display: "flex" }}>
                            <SortIcon sortType={sortType} />
                          </span>
                        )}
                      >
                        {t(label)}
                      </TableSortLabel>
                    ) : (
                      t(label)
                    )}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {data?.length && !loading ? (
                data?.map((row, rowIndex) => (
                  <TableRow key={row.id || rowIndex} className="tableCommonRow">
                    {columns?.map((column) => (
                      <TableCell
                        key={column.key}
                        align={
                          column.align || (dir === "rtl" ? "right" : "left")
                        }
                      >
                        {TableValue({ column, row, rowIndex })}
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : loading ? (
                <SABasicTableSkeleton columns={columns} />
              ) : (
                <TableRow>
                  <TableCell colSpan={columns?.length}>
                    <SATypography variant="h4" className="noDataFound">
                      {t("no-data-found")}
                    </SATypography>
                  </TableCell>{" "}
                </TableRow>
              )}
            </TableBody>
          </Table>
        </SABox>
        {paginationProps ? (
          <SABox className="paginationBox">
            <MUIPagination {...{ ...paginationProps }} />
          </SABox>
        ) : (
          ""
        )}
      </StyledTableContainer>
    </>
  );
};

export default SABasicTable;
