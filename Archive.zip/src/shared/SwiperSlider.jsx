import "swiper/css";

import { Swiper } from "swiper/react";

const SwiperSlider = ({ children, ...props }) => {
  return <Swiper {...props}>{children}</Swiper>;
};

export default SwiperSlider;
