import Popover from "@mui/material/Popover";
import Typography from "@mui/material/Typography";
import React, { useState } from "react";

const SAPopover = ({ children, content, onHover = true }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [isImageLoaded, setIsImageLoaded] = useState(false);

  const handleOpen = (event) => {
    if (isImageLoaded) {
      setAnchorEl(event.currentTarget);
    }
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);

  return (
    <div
      {...(onHover
        ? { onMouseEnter: handleOpen, onMouseLeave: handleClose }
        : { onClick: handleOpen })}
    >
      {children &&
        React.cloneElement(children, {
          onLoad: () => setIsImageLoaded(true),
          onError: () => setIsImageLoaded(false),
        })}
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{ vertical: "center", horizontal: "center" }}
        transformOrigin={{ vertical: "center", horizontal: "center" }}
        PaperProps={{
          onMouseEnter: handleOpen,
          onMouseLeave: handleClose,
        }}
      >
        <Typography sx={{ p: 2 }}>{content}</Typography>
      </Popover>
    </div>
  );
};

export default SAPopover;
