import { ChevronLeft, ChevronRight } from "@mui/icons-material";
import CloseIcon from "@mui/icons-material/Close";
import { IconButton, Modal } from "@mui/material";
import { useRef, useState } from "react";

import { MUIStyled } from "./MUIStyled";
import SABox from "./SABox";

const PreviewImageContainer = MUIStyled(SABox)(() => ({
  position: "fixed",
  top: 0,
  left: 0,
  width: "100vw",
  height: "100vh",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  backgroundColor: "rgba(0, 0, 0, 0.50)",
  zIndex: 10000,
  overflow: "hidden",
}));

const StyledIconButton = MUIStyled(IconButton)(() => ({
  position: "absolute",
  top: 20,
  right: 20,
  color: "#fff",
  backgroundColor: "rgba(0,0,0,0.4)",
  "&:hover": { backgroundColor: "rgba(0,0,0,0.6)" },
  zIndex: 2,
}));

const NavButton = MUIStyled(IconButton)(() => ({
  position: "absolute",
  top: "50%",
  color: "#fff",
  transform: "translateY(-50%)",
  backgroundColor: "rgba(0,0,0,0.4)",
  "&:hover": { backgroundColor: "rgba(0,0,0,0.6)" },
  zIndex: 2,
}));

const SAImagePreviewer = ({
  src,
  open,
  onClose,
  onNext,
  onPrevious,
  alt = "image",
  slider = false,
  shouldMagnify = true,
}) => {
  const imageRef = useRef(null);
  const [magnified, setMagnified] = useState(false);
  const [origin, setOrigin] = useState("center center");

  const handleImageClick = (e) => {
    e.stopPropagation();

    if (!shouldMagnify) return;

    if (!magnified && imageRef.current) {
      const rect = imageRef.current.getBoundingClientRect();
      const xPercent = ((e.clientX - rect.left) / rect.width) * 100;
      const yPercent = ((e.clientY - rect.top) / rect.height) * 100;
      setOrigin(`${xPercent}% ${yPercent}%`);
    }

    setMagnified((prev) => !prev);
  };

  const handleNext = (e) => {
    e.stopPropagation();
    setMagnified(false);
    if (onNext) onNext();
  };

  const handlePrevious = (e) => {
    e.stopPropagation();
    setMagnified(false);
    if (onPrevious) onPrevious();
  };

  const handleClose = () => {
    onClose();
    setMagnified(false);
  };

  return (
    <Modal open={open} onClick={handleClose}>
      <PreviewImageContainer onClick={handleClose}>
        <StyledIconButton onClick={onClose}>
          <CloseIcon />
        </StyledIconButton>
        {slider && (
          <>
            <NavButton onClick={handlePrevious} sx={{ left: 20 }}>
              <ChevronLeft />
            </NavButton>
            <NavButton onClick={handleNext} sx={{ right: 20 }}>
              <ChevronRight />
            </NavButton>
          </>
        )}
        <img
          ref={imageRef}
          src={src}
          alt={alt}
          onClick={handleImageClick}
          style={{
            maxWidth: "90vw",
            maxHeight: "90vh",
            objectFit: "contain",
            borderRadius: "4px",
            boxShadow: "0 0 30px rgba(255,255,255,0.1)",
            ...(shouldMagnify
              ? {
                  transformOrigin: origin,
                  cursor: magnified ? "zoom-out" : "zoom-in",
                  transform: magnified ? "scale(2)" : "scale(1)",
                  transition: "transform 0.1s ease",
                }
              : {}),
          }}
        />
      </PreviewImageContainer>
    </Modal>
  );
};

export default SAImagePreviewer;
