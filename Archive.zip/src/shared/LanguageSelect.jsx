import LanguageIcon from "@mui/icons-material/Language";
import { Icon, Stack } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";

import { setAppLanguage } from "../redux/slices/app.slices";
import theme from "../themes/theme";
import MUISelect from "./MUISelect";

const LanguageSelect = () => {
  const dispatch = useDispatch();
  const language = useSelector((state) => state.app?.language);

  const handleChange = (e) => dispatch(setAppLanguage(e.target.value));

  return (
    <Stack direction="row" alignItems="center" spacing={1}>
      <MUISelect
        value={language}
        onChange={handleChange}
        options={[
          { label: "English", value: "en" },
          { label: "العربية", value: "ar" },
        ]}
        startAdornment={
          <Icon sx={{ color: theme.palette.black.dark }}>
            <LanguageIcon />
          </Icon>
        }
      />
    </Stack>
  );
};

export default LanguageSelect;
