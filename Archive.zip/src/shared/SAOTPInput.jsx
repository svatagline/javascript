import OTPInput from "react-otp-input";

import theme from "../themes/theme";
import SABox from "./SABox";

const SAOTPInput = ({
  value,
  onChange,
  inputStyle,
  numInputs = 4,
  renderSeparator,
  onEnterPress = () => {},
}) => {
  return (
    <SABox display="flex" alignItems="center" gap={2}>
      <OTPInput
        containerStyle={{ width: "100%", justifyContent: "space-between" }}
        {...{
          value,
          onChange,
          numInputs,
          inputStyle,
          renderSeparator,
          renderInput: (props) => (
            <input
              {...props}
              style={{
                width: "3.5rem",
                height: "3.5rem",
                margin: "0 0.5rem",
                fontSize: "1.5rem",
                textAlign: "center",
                borderRadius: "6px",
                border: `1.5px solid ${theme.palette.black.light}`,
                ...inputStyle,
              }}
              onKeyUp={(e) => e.key === "Enter" && onEnterPress(e)}
            />
          ),
        }}
      />
    </SABox>
  );
};

export default SAOTPInput;
