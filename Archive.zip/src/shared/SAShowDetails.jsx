import { Card, Divider, List, ListItem } from "@mui/material";

import useI18N from "../hooks/useI18N";
import theme from "../themes/theme";
import { validDetailsValue } from "../utils/functions";
import { MUIStyled } from "./MUIStyled";
import SAAvatar from "./SAAvatar";
import SABox from "./SABox";
import SADataLoading from "./SADataLoading";
import SAImageSlider from "./SAImageSlider";
import SAStack from "./SAStack";
import SAStatusBadge from "./SAStatusBadge";
import SATruncateWithEllipsis from "./SATruncateWithEllipsis";
import SATypography from "./SATypography";

const StyledCard = MUIStyled(Card)(() => ({
  padding: 20,
  boxShadow: "0 0 20px rgba(0, 0, 0, 0.04)",
  borderRadius: 15,
  height: "100%",
}));

const StyledBox = MUIStyled(SABox)(() => ({
  width: "100%",
  display: "grid",
  gap: "20px",
  gridTemplateColumns: "1fr 3fr",
  [theme.breakpoints.down(1400)]: { gridTemplateColumns: "1fr 2fr" },
  [theme.breakpoints.down(1100)]: { gridTemplateColumns: "1fr" },
  "& .MuiInputBase-input": { padding: 8 },
  "& .formFields": {
    maxHeight: "44vh",
    overflow: "auto",
    paddingRight: "12px",
  },
  "& .mainDetailLabelValue": { display: "flex" },
  "& .detailsContainer": {
    gap: "5vh",
    display: "grid",
    [theme.breakpoints.down(1300)]: { gridTemplateColumns: "1fr" },
  },
}));

const StyledList = MUIStyled(List)(() => ({
  gap: "12px",
  display: "grid",
  gridTemplateColumns: "1fr",
  "& .MuiListItem-root": {
    display: "grid",
    gridTemplateColumns: "220px 1fr",
    alignItems: "center",
    gap: "16px",
    backgroundColor: theme.palette.background.paper,
    borderRadius: "8px",
    padding: "10px 14px",
    boxShadow: "0px 1px 4px rgba(0, 0, 0, 0.04)",
    transition: "background 0.3s ease",
    "&:nth-of-type(even)": { backgroundColor: theme.palette.action.hover },
    [theme.breakpoints.down("xl")]: { gridTemplateColumns: "150px 1fr" },
    "& .MuiTypography-root": { overflowWrap: "anywhere" },
  },
}));

const SAShowDetails = ({ detailObject }) => {
  const { t } = useI18N();

  return (
    <>
      {detailObject?.loading || !detailObject?.dataExist ? (
        <SADataLoading
          nodataExist={!detailObject?.dataExist}
          loading={detailObject?.loading}
        />
      ) : (
        <StyledBox>
          <SABox className="profileDetail">
            <StyledCard>
              <SABox className="userProfileContainer">
                <SABox display="flex" flexDirection="column" gap={6}>
                  <SABox>
                    <SABox sx={{ padding: "8px" }}>
                      <SAImageSlider
                        images={detailObject?.mainDetail?.images?.map(
                          (img) =>
                            img?.url?.url ||
                            img?.url?.file ||
                            img?.attachment?.url,
                        )}
                      />
                    </SABox>
                    <SABox
                      flex={1}
                      sx={{
                        pt: 2,
                        borderTop: `1px solid ${theme.palette.gray.light}`,
                      }}
                    >
                      <SAStack
                        direction="row"
                        alignItems="center"
                        justifyContent="space-between"
                        gap="10px"
                        flexWrap="wrap"
                      >
                        <SATypography variant="h6" fontWeight={550}>
                          <SATruncateWithEllipsis
                            maxLength={25}
                            showDash={false}
                            text={detailObject?.mainDetail?.title}
                          />
                        </SATypography>
                        <SAStatusBadge
                          status={detailObject?.mainDetail?.badge?.title}
                          tooltip={detailObject?.mainDetail?.badge?.tooltip}
                          title={detailObject?.mainDetail?.badge?.tooltipText}
                        />
                      </SAStack>
                      {detailObject?.mainDetail?.data
                        ? detailObject?.mainDetail?.data?.map(
                            (detail, index) => (
                              <SABox
                                mt={2}
                                key={index}
                                sx={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 2,
                                  padding: "4px 8px",
                                  backgroundColor: "#F9FAFB",
                                  borderRadius: "8px",
                                }}
                              >
                                <SAAvatar
                                  variant="rounded"
                                  sx={{
                                    width: "28px",
                                    height: "28px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    bgcolor: "black.light",
                                    "& svg": { width: "18px", height: "18px" },
                                  }}
                                >
                                  {detail?.icon}
                                </SAAvatar>
                                <SABox
                                  sx={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 0.5,
                                    flex: 1,
                                  }}
                                >
                                  <SATypography
                                    variant="body2"
                                    sx={{
                                      color: "#6B7280",
                                      fontSize: "0.875rem",
                                      fontWeight: 500,
                                      minWidth: "120px",
                                    }}
                                  >
                                    {`${t(detail?.key)}:`}
                                  </SATypography>
                                  <SATypography
                                    sx={{
                                      color: "#111827",
                                      fontSize: "0.875rem",
                                      fontWeight: 500,
                                    }}
                                  >
                                    {detail?.isSeparated
                                      ? detail?.value
                                      : validDetailsValue(detail?.value) ||
                                        "N/A"}
                                  </SATypography>
                                </SABox>
                              </SABox>
                            ),
                          )
                        : ""}
                    </SABox>
                  </SABox>
                </SABox>
              </SABox>
            </StyledCard>
          </SABox>
          <SABox className="otherInformation">
            <StyledCard>
              {detailObject?.otherDetails
                ? detailObject?.otherDetails.map(
                    (
                      { widget, list, division = 1, data_type = "list" },
                      index,
                    ) => {
                      return (
                        <SABox
                          className="detailsContainer"
                          sx={{ gridTemplateColumns: "1fr ".repeat(division) }}
                          key={index}
                        >
                          {data_type === "widget" ? (
                            <SABox className={"detailList"}>
                              <SATypography variant="h6">
                                {t(widget?.title)}
                              </SATypography>
                              <Divider sx={{ marginY: 2 }} />
                              {widget.element}
                            </SABox>
                          ) : data_type === "list" ? (
                            <>
                              {list.map((detail, ind) => {
                                return (
                                  <SABox className={"detailList"} key={ind}>
                                    <SATypography variant="h6">
                                      {t(detail?.title)}
                                    </SATypography>
                                    <Divider sx={{ marginY: 2 }} />
                                    <StyledList>
                                      {detail?.details
                                        ? detail?.details.map(
                                            (
                                              { value, title, isSeparated },
                                              ind,
                                            ) => (
                                              <ListItem
                                                key={ind}
                                                className="wrap-list"
                                              >
                                                <SATypography
                                                  fontSize={15}
                                                  fontWeight="medium"
                                                  color="text.primary"
                                                  className="no-word-break"
                                                >
                                                  {`${t(title)}:`}
                                                </SATypography>
                                                {isSeparated ? (
                                                  <SABox ml={1}>{value}</SABox>
                                                ) : (
                                                  <SATypography
                                                    ml={1}
                                                    fontSize={15}
                                                  >
                                                    {validDetailsValue(value)}
                                                  </SATypography>
                                                )}
                                              </ListItem>
                                            ),
                                          )
                                        : ""}
                                    </StyledList>
                                  </SABox>
                                );
                              })}
                            </>
                          ) : (
                            ""
                          )}
                        </SABox>
                      );
                    },
                  )
                : ""}
            </StyledCard>
          </SABox>
        </StyledBox>
      )}
    </>
  );
};

export default SAShowDetails;
