import { Button } from "@mui/material";

import useI18N from "../hooks/useI18N";
import { MUIStyled } from "./MUIStyled";
import SALoader from "./SALoader";

const StyledButton = MUIStyled(Button)(({ theme, dir }) => ({
  padding: "7px 20px",
  fontSize: 16,
  minWidth: 100,
  fontWeight: 600,
  borderRadius: 8,
  lineHeight: "normal",
  textTransform: "capitalize",
  "&.MuiButton-contained": {
    border: `1px solid transparent`,
    "&:hover": { color: theme.palette.white.main },
  },
  "&.MuiButton-textError": {
    border: "none",
    fontWeight: "400",
    "&:hover": { backgroundColor: "transparent" },
  },
  "&.MuiButton-textPrimary": {
    border: "none",
    fontWeight: "400",
    "&:hover": { backgroundColor: "transparent" },
  },
  "&.MuiButton-sizeSmall": { padding: "6px 12px", fontSize: 14, minWidth: 60 },
  "& .MuiButton-icon": {
    marginRight: dir === "rtl" ? 10 : 0,
    marginLeft: dir === "rtl" ? 0 : 10,
  },
}));

const SAButton = ({ children, disabled, loading, ...rest }) => {
  const { dir } = useI18N();
  return (
    <StyledButton
      dir={dir}
      disableElevation
      disabled={disabled || loading}
      endIcon={loading ? <SALoader size={18} /> : null}
      {...rest}
    >
      {children}
    </StyledButton>
  );
};

export default SAButton;
