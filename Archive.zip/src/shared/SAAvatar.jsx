import Avatar from "@mui/material/Avatar";
import { styled } from "@mui/material/styles";

const StyledAvatar = styled(Avatar)(() => {});

const SAAvatar = (props) => {
  return <StyledAvatar {...props} />;
};

export default SAAvatar;
