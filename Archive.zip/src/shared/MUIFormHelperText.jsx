import { FormHelperText } from "@mui/material";

import useI18N from "../hooks/useI18N";

const MUIFormHelperText = ({ error = true, children }) => {
  const { dir } = useI18N();

  return (
    <FormHelperText
      error={error}
      sx={{ margin: 0, dir, textAlign: "inherit" }}
      dir={dir}
    >
      {children}
    </FormHelperText>
  );
};

export default MUIFormHelperText;
