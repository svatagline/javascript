import { Breadcrumbs, Typography } from "@mui/material";
import { Link } from "react-router-dom";

import useI18N from "../hooks/useI18N";
import { MUIStyled } from "./MUIStyled";

const StyledBreadcrumbs = MUIStyled(Breadcrumbs)(({ theme }) => ({
  "& .MuiBreadcrumbs-li": {
    "& a": {
      textDecoration: "none",
      color: theme.palette.text.secondary,
      transition: "color 0.2s ease",
      "&:hover": { color: theme.palette.primary.main },
    },
  },
}));

const MUIBreadcrumbs = ({ breadcrumbsData = [], ...props }) => {
  const { t } = useI18N();

  return (
    breadcrumbsData.length > 0 && (
      <StyledBreadcrumbs separator="›" aria-label="breadcrumb" {...props}>
        {breadcrumbsData.map((item, index) => {
          const isLast = index === breadcrumbsData.length - 1;
          const label = item?.noTranslate ? item.label : t(item.label);

          return item.href && !isLast ? (
            <Link key={index} to={item.href}>
              {label}
            </Link>
          ) : (
            <Typography
              key={index}
              className="capitalize-first-letter"
              fontWeight={isLast ? 550 : "normal"}
              color={isLast ? "primary.main" : "text.secondary"}
            >
              {label}
            </Typography>
          );
        })}
      </StyledBreadcrumbs>
    )
  );
};

export default MUIBreadcrumbs;
