import MUITooltip from "./MUITooltip";

const SATruncateWithEllipsis = ({
  text,
  maxLength,
  placement = "top",
  showDash = true,
  ...rest
}) => {
  if (text?.length <= maxLength) {
    return text;
  } else {
    const truncatedText = text?.slice(0, maxLength - 3);
    return (
      <MUITooltip title={text} arrow placement={placement} {...rest}>
        {text ? `${truncatedText}...` : showDash ? "-" : ""}
      </MUITooltip>
    );
  }
};

export default SATruncateWithEllipsis;
