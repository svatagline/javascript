import VisibilityIcon from "@mui/icons-material/Visibility";
import { Skeleton } from "@mui/material";
import Fade from "@mui/material/Fade";
import { useEffect, useRef, useState } from "react";

import { MUIStyled } from "./MUIStyled";
import SABox from "./SABox";
import SAImagePreviewer from "./SAImagePreviewer";

const ImageContainer = MUIStyled(SABox)(({ width }) => ({
  width,
  borderRadius: 8,
  aspectRatio: "1",
  cursor: "pointer",
  overflow: "hidden",
  position: "relative",
}));

const ViewImagePreview = MUIStyled(SABox)(({ hovered }) => ({
  position: "absolute",
  top: 0,
  left: 0,
  width: "100%",
  height: "100%",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  opacity: hovered ? 1 : 0,
  pointerEvents: "none",
  borderRadius: 8,
  transition: "opacity 0.3s ease",
  backgroundColor: hovered ? "rgba(34, 33, 33, 0.14)" : "transparent",
  zIndex: 2,
}));

const ImageLoaderWrapper = MUIStyled(SABox)(() => ({
  top: 0,
  left: 0,
  zIndex: 2,
  width: "100%",
  height: "100%",
  borderRadius: 8,
  display: "flex",
  position: "absolute",
  alignItems: "center",
  justifyContent: "center",
  backgroundColor: "#f4f4f4",
}));

const LazyImage = ({
  src,
  style,
  className,
  onImageClick,
  alt = "img",
  width = "100%",
  eyeIcon = true,
  previewImage = true,
} = {}) => {
  const imgRef = useRef(null);

  const [error, setError] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!src) setError(true);
  }, [src]);

  const handlePreview = () => {
    if (previewImage && !error) setPreviewOpen(true);
    if (onImageClick && !error) onImageClick();
  };

  return (
    <>
      <ImageContainer
        {...{
          width,
          className,
          sx: { ...style },
          onClick: handlePreview,
          ...(eyeIcon
            ? {
                onMouseEnter: () => setHovered(true),
                onMouseLeave: () => setHovered(false),
              }
            : {}),
        }}
      >
        <Fade in={loading && !error}>
          <ImageLoaderWrapper>
            <Skeleton
              width="100%"
              height="100%"
              animation="pulse"
              variant="rectangular"
            />
          </ImageLoaderWrapper>
        </Fade>
        {!error && (
          <img
            src={src}
            alt={alt}
            ref={imgRef}
            loading="lazy"
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              borderRadius: "8px",
              display: "block",
            }}
            onError={() => setError(true)}
            onLoad={() => setLoading(false)}
          />
        )}
        {error && (
          <SABox
            sx={{
              top: 0,
              left: 0,
              zIndex: 2,
              width: "100%",
              height: "100%",
              backgroundColor: "##f6f6f6",
              display: "flex",
              position: "absolute",
              justifyContent: "center",
              alignItems: "center",
              borderRadius: 2,
            }}
          >
            <span
              style={{ color: "#555", fontSize: "16px", fontWeight: "bold" }}
            >
              {alt}
            </span>
          </SABox>
        )}
        {!loading && (
          <ViewImagePreview {...{ hovered }}>
            <VisibilityIcon sx={{ color: "#fff", fontSize: 40 }} />
          </ViewImagePreview>
        )}
      </ImageContainer>
      {previewImage && (
        <SAImagePreviewer
          {...{
            src,
            alt,
            slider: false,
            open: previewOpen,
            onClose: () => setPreviewOpen(false),
          }}
        />
      )}
    </>
  );
};
export default LazyImage;
