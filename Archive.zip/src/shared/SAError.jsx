import useI18N from "../hooks/useI18N";
import SATypography from "./SATypography";

const SAError = ({ children, ...props }) => {
  const { t } = useI18N();
  return (
    <SATypography
      color="indianred"
      component="span"
      sx={{ "&.MuiTypography-root": { mt: 1 } }}
      {...props}
    >
      {t(children)}
    </SATypography>
  );
};

export default SAError;
