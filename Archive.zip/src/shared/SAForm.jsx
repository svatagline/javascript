const SAForm = ({ children, ...props }) => {
  return <form {...props}>{children}</form>;
};

export default SAForm;
