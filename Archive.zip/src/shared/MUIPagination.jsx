import { Pagination, TablePagination as PaginationRows } from "@mui/material";

import { ROW_PER_PAGE_OPTIONS } from "../constants";
import useI18N from "../hooks/useI18N";
import { MUIStyled } from "./MUIStyled";
import SAStack from "./SAStack";
const MUIPagination = ({ ...props }) => {
  const {
    page,
    count,
    rowsPerPage = 10,
    currentPage,
    setItemPerPage,
    setCurrentPage,
  } = props;

  const { t } = useI18N();
  const onChangeRowsPerPage = ({ target: { value } }) => {
    setItemPerPage(value);
    setCurrentPage(1);
  };

  const StyledTablePagination = MUIStyled(SAStack)(() => ({
    "& .MuiTablePagination-displayedRows": {
      display: "none",
    },
    "& .MuiTablePagination-actions": {
      display: "none",
    },
    "& .MuiToolbar-regular": {
      paddingLeft: 0,
    },
  }));

  return (
    <StyledTablePagination
      direction="row"
      justifyContent="space-between"
      alignItems="center"
      px={2}
    >
      <PaginationRows
        component="div"
        count={count}
        page={page}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={onChangeRowsPerPage}
        rowsPerPageOptions={ROW_PER_PAGE_OPTIONS}
        labelRowsPerPage={t("rows-per-page")}
      />
      <Pagination
        page={currentPage}
        count={page}
        onChange={(e, page) => setCurrentPage(page)}
      />
    </StyledTablePagination>
  );
};

export default MUIPagination;
