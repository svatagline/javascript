import { Tooltip } from "@mui/material";

const MUITooltip = ({ children, ...props }) => {
  return (
    <Tooltip
      arrow
      placement={props?.placement || "top"}
      componentsProps={{
        tooltip: {
          sx: {
            fontSize: "12px",
            color: "white.main",
            backgroundColor: "black.main",
            "& .MuiTooltip-arrow": { color: "black.main" },
          },
        },
      }}
      {...props}
    >
      {children}
    </Tooltip>
  );
};

export default MUITooltip;
