import { MenuItem } from "@mui/material";

const MUIMenuItem = ({ children, ...props }) => {
  return <MenuItem {...props}>{children}</MenuItem>;
};

export default MUIMenuItem;
