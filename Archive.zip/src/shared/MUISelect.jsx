import { FormControl, MenuItem, Select } from "@mui/material";

import useI18N from "../hooks/useI18N";
import theme from "../themes/theme";
import { ArrowDown } from "./icon";
import MUIFormHelperText from "./MUIFormHelperText";
import MUIFormLabel from "./MUIFormLabel";
import { MUIStyled } from "./MUIStyled";
import SATypography from "./SATypography";

const StyledSelect = MUIStyled(Select)(() => ({
  padding: "0 10px",
  "& .MuiSelect-select": {
    padding: "8px !important",
    "& + input + svg": { flex: "0 0 10px" },
  },
  "&.Mui-focused": { "& .MuiOutlinedInput-notchedOutline": { borderWidth: 1 } },
}));

const MUISelect = ({ options, value, onChange, placeholder, ...props }) => {
  const { t, dir } = useI18N();
  return (
    <>
      <FormControl
        fullWidth
        sx={{
          "& .MuiFormLabel-root": {
            fontSize: 14,
            fontWeight: 500,
            lineHeight: "1.5",
            marginBottom: 0.5,
            width: "fit-content",
          },
        }}
      >
        {props?.formLabel && (
          <MUIFormLabel>
            {props?.required && (
              <SATypography component="span" color="danger.main">
                *
              </SATypography>
            )}
            {props?.formLabel}
          </MUIFormLabel>
        )}
        <StyledSelect
          {...props}
          displayEmpty
          value={value || ""}
          onChange={onChange}
          IconComponent={ArrowDown}
          dir={dir}
          MenuProps={{
            PaperProps: {
              sx: {
                border: `1px solid ${theme.palette.gray.main}50`,
                marginTop: 1,
                borderRadius: 2,
                boxShadow:
                  "0 4px 6px -1px rgb(0 0 0 / .1), 0 2px 4px -2px rgb(0 0 0 / .1)",
              },
            },
          }}
        >
          {placeholder && (
            <MenuItem value="" sx={{ color: "gray.main" }}>
              {placeholder}
            </MenuItem>
          )}
          {options?.map(({ value, label }) => (
            <MenuItem key={value} value={value}>
              {t(label)}
            </MenuItem>
          ))}
        </StyledSelect>
        {props?.error && <MUIFormHelperText>{props?.error}</MUIFormHelperText>}
      </FormControl>
    </>
  );
};

export default MUISelect;
