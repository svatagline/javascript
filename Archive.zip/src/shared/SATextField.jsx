import { FormControl, TextField } from "@mui/material";

import useI18N from "../hooks/useI18N";
import MUIFormHelperText from "./MUIFormHelperText";
import MUIFormLabel from "./MUIFormLabel";
import { MUIStyled } from "./MUIStyled";

const StyledTextField = MUIStyled(TextField)(({ dir }) => ({
  "& .MuiInputBase-input": { padding: "8px 12px" },
  "& .MuiOutlinedInput-root": {
    height: "40px",
    borderRadius: 0,
    backgroundColor: "#fff",
    "& fieldset": { borderColor: "#D2D5DA" },
    "&:hover fieldset": { borderColor: "#B0B0B0" },
    "&.Mui-focused fieldset": { borderColor: "#C5A56F" },
    "&.MuiInputBase-adornedStart:not(.MuiInputBase-adornedEnd)": {
      paddingRight: dir === "rtl" ? 14 : 0,
      paddingLeft: dir === "rtl" ? 0 : 14,
    },
    "&.MuiInputBase-adornedEnd:not(.MuiInputBase-adornedStart)": {
      paddingRight: dir === "rtl" ? 0 : 14,
      paddingLeft: dir === "rtl" ? 14 : 0,
    },
  },
}));

const SATextField = ({ formLabel, helperText, error, ...rest }) => {
  const { t, dir } = useI18N();

  return (
    <FormControl fullWidth>
      {formLabel && <MUIFormLabel>{formLabel}</MUIFormLabel>}
      <StyledTextField {...rest} dir={dir} />
      {(error || helperText) && (
        <MUIFormHelperText error={!!error}>
          {error ? t(error) : t(helperText)}
        </MUIFormHelperText>
      )}
    </FormControl>
  );
};

export default SATextField;
