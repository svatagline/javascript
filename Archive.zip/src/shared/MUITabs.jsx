import { Tab, Tabs } from "@mui/material";
import React from "react";

import useI18N from "../hooks/useI18N";
import { MUIStyled } from "./MUIStyled";
import SABox from "./SABox";
import SAStack from "./SAStack";

function CustomTabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <SABox
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
      mt={2}
      height="calc(100% - 60px)"
    >
      {value === index && <>{children}</>}
    </SABox>
  );
}

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

const StyledTabs = MUIStyled(Tabs)(({ theme }) => ({
  overflow: "visible",
  "& .MuiTabs-scroller": {
    overflow: "visible",
  },
  "& .MuiTabs-flexContainer": {
    borderRadius: 8,
    display: "inline-flex",
    gap: 10,
    backgroundColor: `${theme.palette.white.main}`,
    boxShadow: "0 0 20px rgba(0, 0, 0, 0.04)",
    padding: 5,
    "&.MuiTabs-list": {
      "& .MuiTab-root": {
        textTransform: "capitalize",
        fontSize: 16,
        color: theme.palette.black.main,
        padding: "10px 20px",
        minHeight: "auto",
        borderRadius: 8,
        position: "relative",
        zIndex: 1,
        "&.Mui-selected": {
          color: theme.palette.white.main,
        },
      },
    },
  },
  "& .MuiTabs-indicator": {
    backgroundColor: theme.palette.primary.main,
    borderRadius: 8,
    height: 40,
    bottom: 5,
  },
}));

const MUITabs = ({ beforeComponent, tabs, afterComponent }) => {
  const { dir } = useI18N();
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <>
      <SAStack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
      >
        {beforeComponent}
        <StyledTabs
          variant="scrollable"
          scrollButtons="auto"
          value={value}
          dir={dir}
          onChange={handleChange}
        >
          {tabs?.map((tab, index) => (
            <Tab key={index} label={tab.label} {...a11yProps(index)} />
          ))}
        </StyledTabs>
        {afterComponent}
      </SAStack>
      {tabs?.map((tab, index) => (
        <CustomTabPanel key={index} value={value} index={index}>
          {tab.content}
        </CustomTabPanel>
      ))}
    </>
  );
};

export default MUITabs;
