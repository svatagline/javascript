import { Box } from "@mui/material";

const SABox = ({ children, ...props }) => {
  return <Box {...props}>{children}</Box>;
};

export default SABox;
