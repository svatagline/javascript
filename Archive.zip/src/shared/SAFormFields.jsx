import "react-phone-input-2/lib/style.css";

import VisibilityOffOutlinedIcon from "@mui/icons-material/VisibilityOffOutlined";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import {
  Autocomplete,
  FormControl,
  FormControlLabel,
  Grid2,
  Radio,
  RadioGroup,
  TextField,
} from "@mui/material";
import { useState } from "react";
import { Controller } from "react-hook-form";
import PhoneInput from "react-phone-input-2";

import useI18N from "../hooks/useI18N";
import theme from "../themes/theme";
import MUIFormHelperText from "./MUIFormHelperText";
import MUIFormLabel from "./MUIFormLabel";
import MUISelect from "./MUISelect";
import { MUIStyled } from "./MUIStyled";
import SATextField from "./SATextField";

/**
 * @param {object} onChangeHandlers - Custom onChange handler for individual fields (based on name)
 */

const StyledAutocomplete = MUIStyled(Autocomplete)(({ dir }) => {
  const isRTL = dir === "rtl";
  return {
    "& .MuiInputBase-root": {
      padding: isRTL
        ? "8px 8px 8px 56px !important"
        : "8px 56px 8px 8px !important",
      "& .MuiInputBase-input": { "&.MuiAutocomplete-input": { padding: 0 } },
      "& .MuiButtonBase-root": { flexDirection: isRTL ? "row-reverse" : "" },
      "& .MuiAutocomplete-endAdornment": {
        right: isRTL ? "auto" : 9,
        left: isRTL ? 9 : "auto",
      },
    },
  };
});

const StyledPhoneInput = MUIStyled(PhoneInput)(({ dir }) => {
  const isRTL = dir === "rtl";
  return {
    "&.react-tel-input": {
      "& .form-control": {
        width: "100%",
        height: "40px",
        borderRadius: 0,
        paddingLeft: isRTL ? 10 : 48,
        paddingRight: isRTL ? 48 : 0,
        textAlign: isRTL ? "right" : "left",
      },
      "& .flag-dropdown": {
        background: "transparent",
        border: "1px solid #E0E0E0",
        borderRight: "none",
        borderRadius: 0,
        "&:hover": { borderColor: "#B0B0B0" },
        "&.open": { background: "transparent", borderColor: "#C5A56F" },
        "& .selected-flag": {
          padding: isRTL ? "0 8px 0 8px" : "0 0 0 8px",
          backgroundColor: "transparent",
          "&:hover, &:focus": { backgroundColor: "transparent" },
          "& .arrow": { left: isRTL ? "auto" : 20, right: isRTL ? 20 : "auto" },
        },
      },
    },
  };
});

const SAFormFields = ({
  fields,
  control,
  register,
  formState,
  onChangeHandlers = {},
  isDisabled = false,
  spacing,
}) => {
  const { t, dir } = useI18N();
  const [visible, setVisible] = useState({});
  const { errors } = formState;

  const toggleVisible = (name) => {
    setVisible((prev) => ({ ...prev, [name]: !prev[name] }));
  };

  const renderField = (field) => {
    const {
      type,
      name,
      size,
      options,
      placeholder,
      formLabel,
      defaultValue,
      registerOptions,
      startAdornment,
      endAdornment,
      isMultiple = false,
      disabled = false,
      ...rest
    } = field;
    switch (type) {
      case "select":
        return (
          <Grid2 size={size} key={name}>
            <Controller
              name={name}
              control={control}
              rules={{ ...registerOptions }}
              shouldUnregister
              render={({ field }) => (
                <MUISelect
                  startAdornment={startAdornment}
                  {...{
                    options,
                    id: name,
                    defaultValue,
                    formLabel: t(formLabel),
                    placeholder: t(placeholder),
                    onChange: onChangeHandlers[name],
                    error: t(errors[name]?.message),
                    disabled: disabled || isDisabled,
                    ...field,
                  }}
                />
              )}
            />
          </Grid2>
        );

      case "phone":
        return (
          <Grid2 size={size} key={name}>
            <Controller
              name={name}
              control={control}
              rules={{ ...registerOptions }}
              shouldUnregister
              render={({ field: { value, onChange } }) => (
                <FormControl fullWidth>
                  <MUIFormLabel>{t(formLabel)}</MUIFormLabel>
                  <StyledPhoneInput
                    autoFormat
                    enableSearch
                    country={"bh"}
                    copyNumbersOnly
                    value={value}
                    onChange={(value, data) => {
                      onChange(value);
                      if (onChangeHandlers[name]) {
                        onChangeHandlers[name](value, data);
                      }
                    }}
                    dir={dir}
                    inputComponent={TextField}
                    inputStyle={{
                      height: 40,
                      width: "100%",
                      borderColor: errors[name]?.message
                        ? "#d32f2f"
                        : theme.palette.gray.main,
                    }}
                  />

                  {errors[name]?.message ? (
                    <MUIFormHelperText>
                      {t(errors[name]?.message)}
                    </MUIFormHelperText>
                  ) : (
                    <MUIFormHelperText error={false}>
                      {t(rest?.helperText)}
                    </MUIFormHelperText>
                  )}
                </FormControl>
              )}
            />
          </Grid2>
        );

      case "autocomplete":
        return (
          <Grid2 size={size} key={name}>
            <Controller
              name={name}
              control={control}
              rules={{ ...registerOptions }}
              shouldUnregister
              render={({ field: { value, onChange } }) => (
                <FormControl fullWidth>
                  <MUIFormLabel>{t(formLabel)}</MUIFormLabel>
                  <StyledAutocomplete
                    multiple={isMultiple}
                    disabled={isDisabled}
                    dir={dir}
                    options={options?.map((option) => ({
                      ...option,
                      label: t(option.label),
                    }))}
                    getOptionLabel={(option) => t(option.label) || ""}
                    value={
                      isMultiple
                        ? options?.filter((option) =>
                            value?.includes(option.value),
                          )
                        : options?.find((option) => option.value === value) ||
                          null
                    }
                    onChange={(_, newValue) => {
                      const updatedValue = isMultiple
                        ? newValue?.map((item) => item.value)
                        : newValue?.value || "";
                      onChange(updatedValue);
                      if (onChangeHandlers[name]) {
                        onChangeHandlers[name](updatedValue);
                      }
                    }}
                    renderInput={(params) => (
                      <SATextField
                        {...params}
                        // label={t(formLabel)}
                        placeholder={t(placeholder)}
                        error={errors[name]?.message}
                        helperText={
                          errors[name]?.message && t(errors[name]?.message)
                        }
                      />
                    )}
                  />
                </FormControl>
              )}
            />
          </Grid2>
        );

      case "radio":
        return (
          <Grid2 size={size} key={name}>
            <FormControl component="fieldset">
              <MUIFormLabel component="legend">{t(formLabel)}</MUIFormLabel>
              <RadioGroup
                row
                defaultValue={defaultValue}
                {...register(name, { ...registerOptions })}
              >
                {options.map((option) => (
                  <FormControlLabel
                    key={option.value}
                    value={option.value}
                    control={<Radio />}
                    label={t(option.label)}
                  />
                ))}
              </RadioGroup>
              {errors[name]?.message && (
                <MUIFormHelperText>
                  {t(errors[name]?.message)}
                </MUIFormHelperText>
              )}
            </FormControl>
          </Grid2>
        );

      default:
        return (
          <Grid2 size={size} key={name}>
            <SATextField
              {...{
                id: name,
                placeholder: t(placeholder),
                type: visible[name] ? "text" : type,
                formLabel: t(formLabel),
                error: errors[name]?.message,
                ...register(name, {
                  shouldUnregister: true,
                  onChange: onChangeHandlers[name],
                  ...registerOptions,
                }),
                disabled: disabled || isDisabled,
                ...rest,
                InputProps: {
                  startAdornment: startAdornment,
                  endAdornment:
                    type === "password" ? (
                      <>
                        {visible[name] ? (
                          <VisibilityOutlinedIcon
                            onClick={() => toggleVisible(name)}
                            style={{ cursor: "pointer" }}
                          />
                        ) : (
                          <VisibilityOffOutlinedIcon
                            onClick={() => toggleVisible(name)}
                            style={{ cursor: "pointer" }}
                          />
                        )}
                      </>
                    ) : (
                      endAdornment
                    ),
                },
              }}
            />
          </Grid2>
        );
    }
  };

  return (
    <Grid2 container spacing={spacing}>
      {fields.map((field) => renderField(field))}
    </Grid2>
  );
};

export default SAFormFields;
