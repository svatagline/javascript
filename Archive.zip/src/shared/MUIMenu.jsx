import { Menu } from "@mui/material";

const MUIMenu = ({ children, ...props }) => {
  return <Menu {...props}>{children}</Menu>;
};

export default MUIMenu;
