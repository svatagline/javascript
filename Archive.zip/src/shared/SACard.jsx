import { Card, CardContent, Typography } from "@mui/material";

import { MUIStyled } from "./MUIStyled";
import SABox from "./SABox";

const ContentWrapper = MUIStyled(Card)(({ theme }) => ({
  backgroundColor: theme.palette.white.main,
  borderRadius: 16,
  boxShadow: "0 0 20px rgba(0,0,0,0.04)",
  "& .titleBox": {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
}));

const SACard = ({ children, title, leftJoint }) => {
  return (
    <ContentWrapper>
      <CardContent>
        {(title || leftJoint) && (
          <SABox className="titleBox">
            {title && (
              <Typography gutterBottom variant="h5" component="div">
                {title}
              </Typography>
            )}
            {leftJoint}
          </SABox>
        )}

        {children}
      </CardContent>
    </ContentWrapper>
  );
};

export default SACard;
