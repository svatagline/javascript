import { Stack } from "@mui/material";

const SAStack = ({ children, ...props }) => {
  return <Stack {...props}>{children}</Stack>;
};

export default SAStack;
