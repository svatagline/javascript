import { SpinnerCircularFixed } from "spinners-react";

const SALoader = ({
  size = 35,
  thickness = 300,
  color = "#444444",
  secondaryColor = "#c9c9c9",
  ...rest
}) => {
  return (
    <SpinnerCircularFixed
      {...{
        size,
        color,
        thickness,
        secondaryColor,
        ...rest,
      }}
    />
  );
};

export default SALoader;
