import { useEffect, useState } from "react";

import { filterValidEntries, objectLength } from "../utils/functions";
import showToast from "../utils/toast";
import { Filter } from "./icon";
import MUIModal from "./MUIModal";
import { MUIStyled } from "./MUIStyled";
import SABox from "./SABox";
import SAButton from "./SAButton";
import SAForm from "./SAForm";
import SAFormFields from "./SAFormFields";
import SAStack from "./SAStack";
import SATypography from "./SATypography";

const Filters = MUIStyled(SATypography)(() => ({
  cursor: "pointer",
  padding: 10,
  "& svg": {
    verticalAlign: "middle",
  },
}));

const SAFilterMenu = ({
  t,
  open,
  handleClose,
  handleClick,
  onSubmit,
  useFormControls,
  setFilterData,
  defaultFilterValues,
  filterFields,
}) => {
  const { register, handleSubmit, formState, control, reset, watchFields } =
    useFormControls;

  const [initialFilterValueExist, setInitialFilterValueExist] =
    useState(filterFields);
  let isFilterValuesBlank =
    objectLength(
      filterValidEntries({
        ...(watchFields ?? {}),
      }),
    ) == 0;
  const onReset = () => {
    setInitialFilterValueExist(!isFilterValuesBlank);
    if (!isFilterValuesBlank) {
      setFilterData(defaultFilterValues);
      reset(defaultFilterValues);
    }
  };

  const handleCloseBtn = () => {
    if (!isFilterValuesBlank) {
      setFilterData(defaultFilterValues);
      reset(defaultFilterValues);
      onSubmit(filterValidEntries(defaultFilterValues));
    }

    handleClose();
  };

  const onHandleSubmit = (data) => {
    if (!isFilterValuesBlank || initialFilterValueExist) {
      onSubmit(filterValidEntries(data));
      setFilterData(watchFields);
      setInitialFilterValueExist(false);
    } else {
      showToast(t(`form-should-not-be-blank`), { type: "error" });
    }
  };

  useEffect(() => {
    if (open) setInitialFilterValueExist(!isFilterValuesBlank);
  }, [open]);

  return (
    <>
      <Filters onClick={handleClick}>
        {t("advanced-filter")} <Filter />
      </Filters>
      <MUIModal
        open={open}
        handleClose={handleClose}
        maxWidth={500}
        title={t("advanced-filter")}
        content={
          <SABox px={2} pt={2} pb={4}>
            <SAForm onSubmit={handleSubmit((data) => onHandleSubmit(data))}>
              <SAStack spacing={2}>
                <SABox>
                  <SAFormFields
                    spacing={2}
                    {...{
                      fields: filterFields,
                      register,
                      formState,
                      control,
                    }}
                  />
                </SABox>

                <SAStack direction="row" mt={3} textAlign="center" gap={1}>
                  <SAButton
                    variant="contained"
                    color="primary"
                    type="submit"
                    sx={{ width: "163px" }}
                    // loading={loading}
                  >
                    {t("submit")}
                  </SAButton>
                  <SAButton
                    variant="outlined"
                    color="primary"
                    onClick={handleCloseBtn}
                  >
                    {t("cancel")}
                  </SAButton>
                  <SAButton
                    variant="outlined"
                    color="primary"
                    onClick={onReset}
                  >
                    {t("reset")}
                  </SAButton>
                </SAStack>
              </SAStack>
            </SAForm>
          </SABox>
        }
      ></MUIModal>
    </>
  );
};

export default SAFilterMenu;
