import CloseIcon from "@mui/icons-material/Close";
import { DialogActions } from "@mui/material";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import IconButton from "@mui/material/IconButton";
import { styled } from "@mui/material/styles";

import useI18N from "../hooks/useI18N";

const MUIDialog = styled(Dialog)(({ theme, maxWidth, dir }) => ({
  "& .MuiDialogContent-root": { padding: theme.spacing(2) },
  "& .MuiDialogActions-root": { padding: theme.spacing(1) },
  "& .MuiPaper-root": { ...(maxWidth ? { maxWidth: maxWidth } : {}) },
  "& .MuiIconButton-root": {
    left: dir === "rtl" ? 8 : "unset",
    right: dir === "rtl" ? "unset" : 8,
  },
}));

export default function MUIModal({
  open,
  title,
  titleSx,
  content,
  maxWidth,
  actionPallet,
  handleClose,
  fullWidth = "md",
}) {
  const { dir } = useI18N();
  return (
    <MUIDialog
      {...{
        dir,
        open,
        maxWidth,
        fullWidth,
        onClose: handleClose,
        "aria-labelledby": "customized-dialog-title",
      }}
    >
      <DialogTitle sx={{ m: 0, p: 2, ...titleSx }} id="customized-dialog-title">
        {title}
      </DialogTitle>
      <IconButton
        aria-label="close"
        onClick={handleClose}
        sx={(theme) => ({
          position: "absolute",
          top: 8,
          right: 8,
          color: theme.palette.grey[500],
        })}
      >
        <CloseIcon />
      </IconButton>
      {content}
      {actionPallet && <DialogActions>{actionPallet}</DialogActions>}
    </MUIDialog>
  );
}
