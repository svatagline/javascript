import { FormLabel } from "@mui/material";

import { MUIStyled } from "./MUIStyled";

const StyledFromLabel = MUIStyled(FormLabel)(({ theme }) => ({
  fontSize: 14,
  fontWeight: 600,
  lineHeight: "1.5",
  color: theme.palette.black.light,
  marginBottom: 4,
  display: "block",
  "&.Mui-focused": {
    color: theme.palette.primary.dark200,
  },
}));

const MUIFormLabel = ({ children, ...props }) => {
  return <StyledFromLabel {...props}>{children}</StyledFromLabel>;
};

export default MUIFormLabel;
