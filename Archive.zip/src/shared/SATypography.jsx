import { Typography } from "@mui/material";

const SATypography = ({ children, ...props }) => {
  return <Typography {...props}>{children}</Typography>;
};

export default SATypography;
