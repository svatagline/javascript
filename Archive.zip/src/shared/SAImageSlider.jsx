import { ChevronLeft, ChevronRight } from "@mui/icons-material";
import { IconButton } from "@mui/material";
import { useState } from "react";

import useI18N from "../hooks/useI18N";
import { MUIStyled } from "./MUIStyled";
import SABox from "./SABox";
import LazyImage from "./SAImageLoader";
import SAImagePreviewer from "./SAImagePreviewer";

const SlideContainer = MUIStyled(SABox)({
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  width: "100%",
  maxWidth: "100%",
  height: "auto",
  overflow: "hidden",
  position: "relative",
});

const SlideItem = MUIStyled(SABox)(() => ({
  width: "100%",
  position: "relative",
  overflow: "hidden",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  borderRadius: 8,
  "& .main-img": {
    position: "relative",
    width: "100%",
    height: "auto",
    maxHeight: "70vh",
    display: "block",
    objectFit: "contain",
    zIndex: 1,
  },
  "& .bg-main-img": {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    objectFit: "cover",
    filter: "blur(8px)",
  },
}));

const DotIndicators = MUIStyled(SABox)(() => ({
  padding: "10px",
  width: "100%",
  display: "flex",
  justifyContent: "center",
  gap: "6px",
}));

const Dot = MUIStyled(SABox)(({ active }) => ({
  width: "8px",
  height: "8px",
  borderRadius: "50%",
  cursor: "pointer",
  backgroundColor: active ? "#111" : "#d1d1d1",
  transition: "background-color 0.2s ease",
  "&:hover": { backgroundColor: "#222" },
}));

const NavigationButton = MUIStyled(IconButton)(({ direction }) => ({
  position: "absolute",
  top: "50%",
  [direction]: "0",
  transform: "translateY(-50%)",
  background: "rgba(0, 0, 0, 0.5)",
  color: "white",
  padding: "8px",
  borderRadius: "50%",
  zIndex: 10,
  "&:hover": { background: "rgba(0, 0, 0, 0.7)" },
}));

const SAImageSlider = ({ images = [] }) => {
  const { t } = useI18N();
  const [currentImg, setCurrentImg] = useState(0);
  const [previewOpen, setPreviewOpen] = useState(false);

  const areMultipleImages = images?.length > 1;

  const handleNext = () => {
    setCurrentImg((prev) => (prev < images?.length - 1 ? prev + 1 : prev));
  };

  const handlePrev = () => {
    setCurrentImg((prev) => (prev > 0 ? prev - 1 : prev));
  };

  if (!images?.length) return <SABox>{t("no-images-available")}</SABox>;

  return (
    <SlideContainer>
      <SlideItem>
        {images?.map((img, index) => (
          <SABox
            key={index}
            sx={{ display: index === currentImg ? "block" : "none" }}
          >
            <LazyImage
              src={img}
              className="main-img"
              previewImage={false}
              onImageClick={() => setPreviewOpen(true)}
            />
            <img src={img} alt="" className="bg-main-img" />
          </SABox>
        ))}
        {areMultipleImages && (
          <>
            <NavigationButton direction="left" onClick={handlePrev}>
              <ChevronLeft />
            </NavigationButton>
            <NavigationButton direction="right" onClick={handleNext}>
              <ChevronRight />
            </NavigationButton>
          </>
        )}
      </SlideItem>
      {areMultipleImages && (
        <DotIndicators>
          {images.map((_, index) => (
            <Dot
              key={index}
              active={currentImg === index}
              onClick={() => setCurrentImg(index)}
            />
          ))}
        </DotIndicators>
      )}
      <SAImagePreviewer
        alt="img"
        src={images?.[currentImg]}
        slider={areMultipleImages}
        open={previewOpen}
        onNext={handleNext}
        onPrevious={handlePrev}
        onClose={() => setPreviewOpen(false)}
      />
    </SlideContainer>
  );
};

export default SAImageSlider;
