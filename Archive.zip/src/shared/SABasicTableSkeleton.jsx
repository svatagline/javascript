import { TableCell, TableRow } from "@mui/material";
import Skeleton from "@mui/material/Skeleton";

const SABasicTableSkeleton = ({ columns }) => {
  return Array.from({ length: 10 }).map((_, index) => (
    <TableRow
      display="flex"
      alignItems="center"
      key={index}
      gap={2}
      padding={1}
    >
      {columns.map((_, ind) =>
        ind === columns?.length - 1 ? (
          <TableCell key={ind}>
            <Skeleton variant="rounded" width={90} height={30} />
          </TableCell>
        ) : (
          <TableCell key={ind}>
            <Skeleton variant="text" width={80} height={20} />
          </TableCell>
        ),
      )}
    </TableRow>
  ));
};

export default SABasicTableSkeleton;
