import { Box } from "@mui/material";

import useI18N from "../hooks/useI18N";
import { MUIStyled } from "./MUIStyled";
import SABox from "./SABox";
import SALoader from "./SALoader";
import SATypography from "./SATypography";

const StyledTableContainer = MUIStyled(Box)(() => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  flexGrow: "1",
  "& .noDataFound": {
    position: "relative",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    minHeight: "30vh",
  },
  "& .loaderBox": {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
  },
}));

const SADataLoading = ({ nodataExist, loading, loadingElement }) => {
  const { t } = useI18N();

  return (
    <>
      {loadingElement && loading ? (
        loadingElement
      ) : (
        <StyledTableContainer>
          {(nodataExist || loading) && (
            <SABox className="noDataFound">
              {loading ? (
                <SABox className="loaderBox">
                  <SALoader />
                </SABox>
              ) : (
                <SATypography variant="h4">{t("no-data-found")}</SATypography>
              )}
            </SABox>
          )}
        </StyledTableContainer>
      )}
    </>
  );
};

export default SADataLoading;
