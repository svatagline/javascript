export const ORGANIZATION_CODE = process.env.REACT_APP_ORGANIZATION_CODE;

export const SHUFTI_CALLBACK_URL =
  "https://5453-16-24-38-147.ngrok-free.app/api/webhook/shufti/";

export const ADMIN = "ADMIN";
export const TAQABETH_ENFORCER = "TAQABETH_ENFORCER";
export const JEWELLERY_INSPECTOR = "JEWELLERY_INSPECTOR";
export const JEWELLERY_BUYER = "JEWELLERY_BUYER";

export const MANUFACTURER = "MANUFACTURER";
export const JEWELER = "JEWELER";
export const SELLER = "SELLER";
export const INVESTOR = "INVESTOR";

export const BUSINESS = "BUSINESS";
export const INDIVIDUAL = "INDIVIDUAL";

export const ADMIN_ROLES = {
  ADMIN: "system-admin",
  TAQABETH_ENFORCER: "taqabeth-enforcer",
  JEWELLERY_INSPECTOR: "jewellery-inspector",
  JEWELLERY_BUYER: "jewellery-buyer",
};

export const USER_ROLES = {
  MANUFACTURER: "manufacturer",
  JEWELER: "jeweler",
  SELLER: "seller",
  INVESTOR: "investor",
};
export const TABLE_RECORD_PER_PAGE = 10;
export const ROW_PER_PAGE_OPTIONS = [10, 25, 50, 100];
