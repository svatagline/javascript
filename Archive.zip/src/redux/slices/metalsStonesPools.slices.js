import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  pools: {},
  refreshList: false,
};

const metalsStonesPoolsSlice = createSlice({
  name: "metalsStonesPools",
  initialState,
  reducers: {
    addPools: (state, action) => {
      const { data } = action.payload;
      state.pools = data;
    },
    isRefreshList: (state, action) => {
      state.refreshList = action.payload;
    },
  },
});

export default metalsStonesPoolsSlice;
export const { addPools, isRefreshList } = metalsStonesPoolsSlice.actions;
