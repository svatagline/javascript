import { createSlice } from "@reduxjs/toolkit";

const initialState = {};

const loaderSlice = createSlice({
  name: "loader",
  initialState,
  reducers: {
    setLoader: (state, action) => {
      const { name, status } = action.payload;
      state[name] = status || !state[name];
    },
  },
});

export default loaderSlice;
export const { setLoader } = loaderSlice.actions;
