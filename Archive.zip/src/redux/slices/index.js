import { combineSlices } from "@reduxjs/toolkit";

import appSlice from "./app.slices";
import bankTransferRequestsSlice from "./bankTransferRequests.slices";
import loaderSlice from "./loader.slices";
import metalsStonesPoolsSlice from "./metalsStonesPools.slices";
import musharkaContractSlice from "./musharkaContracts.slice";
import purchaseRequestSlice from "./purchaseRequests.slice";
import settingsSlice from "./settings.slices";
import transactionsSlice from "./transactions.slice";
import userProfileSlice from "./userProfile.slices";
import usersSlice from "./users.slices";

const rootReducer = combineSlices(
  appSlice,
  userProfileSlice,
  loaderSlice,
  usersSlice,
  settingsSlice,
  transactionsSlice,
  purchaseRequestSlice,
  bankTransferRequestsSlice,
  metalsStonesPoolsSlice,
  musharkaContractSlice,
);

export default rootReducer;
