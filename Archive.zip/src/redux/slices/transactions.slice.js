import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  transactions: [],
  refreshList: false,
};

const transactionsSlice = createSlice({
  name: "transactions",
  initialState,
  reducers: {
    addTransaction: (state, action) => {
      const { data } = action.payload;
      state.transactions = data;
    },
    isRefreshList: (state, action) => {
      state.refreshList = action.payload;
    },
  },
});

export default transactionsSlice;
export const { addTransaction, isRefreshList } = transactionsSlice.actions;
