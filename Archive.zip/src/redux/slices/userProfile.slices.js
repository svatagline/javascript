import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  session: {},
};

const userProfileSlice = createSlice({
  name: "userProfile",
  initialState,
  reducers: {
    setUserProfile: (state, action) => {
      state.session = action.payload;
    },
  },
});

export default userProfileSlice;
export const { setUserProfile } = userProfileSlice.actions;
