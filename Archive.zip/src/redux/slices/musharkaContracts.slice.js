import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  musharkaContracts: [],
  refreshList: false,
};

const musharkaContractSlice = createSlice({
  name: "musharkaContracts",
  initialState,
  reducers: {
    addMusharkaContracts: (state, action) => {
      const { data } = action.payload;
      state.musharkaContracts = data;
    },
    isRefreshList: (state, action) => {
      state.refreshList = action.payload;
    },
  },
});

export default musharkaContractSlice;
export const { addMusharkaContracts, isRefreshList } =
  musharkaContractSlice.actions;
