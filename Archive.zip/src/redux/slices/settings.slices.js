import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  materialsList: [],
  organizationData: [],
  currencyData: [],
  bankData: {},
  shapeCutsList: [],
  metalCaratTypesList: [],
  productsList: [],
  productColorList: [],
};

const settingsSlice = createSlice({
  name: "settings",
  initialState,
  reducers: {
    addMaterials: (state, action) => {
      const { data } = action.payload;
      state.materialsList = data;
    },
    addGeneralData: (state, action) => {
      const { data } = action.payload;
      state.organizationData = data;
    },
    addCurrencyData: (state, action) => {
      const { data } = action.payload;
      state.currencyData = data;
    },
    addBankData: (state, action) => {
      const { data } = action.payload;
      state.bankData = data;
    },
    addShapeCuts: (state, action) => {
      const { data } = action.payload;
      state.shapeCutsList = data;
    },
    addMetalCaratTypes: (state, action) => {
      const { data } = action.payload;
      state.metalCaratTypesList = data;
    },
    addProductType: (state, action) => {
      const { data } = action.payload;
      state.productsList = data;
    },
    addProductColor: (state, action) => {
      const { data } = action.payload;
      state.productColorList = data;
    },
  },
});

export default settingsSlice;
export const {
  addMaterials,
  addGeneralData,
  addCurrencyData,
  addBankData,
  addShapeCuts,
  addMetalCaratTypes,
  addProductType,
  addProductColor,
} = settingsSlice.actions;
