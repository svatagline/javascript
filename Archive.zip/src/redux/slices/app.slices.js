import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  language: "en",
};

const appSlice = createSlice({
  name: "app",
  initialState,
  reducers: {
    setAppLanguage: (state, action) => {
      state.language = action.payload;
    },
    addAppData: (state, action) => {
      const { name, data } = action.payload;
      state[name] = data;
    },
  },
});

export default appSlice;
export const { setAppLanguage, addAppData } = appSlice.actions;
