import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  users: [],
  subAdmins: [],
  refreshList: false,
};

const usersSlice = createSlice({
  name: "users",
  initialState,
  reducers: {
    addUsers: (state, action) => {
      const { data } = action.payload;
      state.users = data;
    },
    addSubAdmins: (state, action) => {
      const { data } = action.payload;
      state.subAdmins = data;
    },
    isRefreshList: (state, action) => {
      state.refreshList = action.payload;
    },
  },
});

export default usersSlice;
export const { addUsers, addSubAdmins, isRefreshList } = usersSlice.actions;
