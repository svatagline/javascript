import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  purchaseRequests: [],
  refreshList: false,
};

const purchaseRequestSlice = createSlice({
  name: "purchaseRequests",
  initialState,
  reducers: {
    addPurchaseRequests: (state, action) => {
      const { data } = action.payload;
      state.purchaseRequests = data;
    },
    isRefreshList: (state, action) => {
      state.refreshList = action.payload;
    },
  },
});

export default purchaseRequestSlice;
export const { addPurchaseRequests, isRefreshList } =
  purchaseRequestSlice.actions;
