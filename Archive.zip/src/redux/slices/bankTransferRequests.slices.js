import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  refreshList: false,
  bankTransferRequests: [],
};

const bankTransferRequestsSlice = createSlice({
  name: "bankTransferRequests",
  initialState,
  reducers: {
    addBankTransferRequests: (state, action) => {
      const { data } = action.payload;
      state.bankTransferRequests = data;
    },
    isRefreshList: (state, action) => {
      state.refreshList = action.payload;
    },
  },
});

export default bankTransferRequestsSlice;
export const { addBankTransferRequests, isRefreshList } =
  bankTransferRequestsSlice.actions;
