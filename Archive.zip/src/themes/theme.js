import { createTheme } from "@mui/material";

const theme = createTheme({
  palette: {
    primary: {
      main: "#2c2410",
      light: "#fff6e0",
      dark100: "#606060",
      dark200: "#161616",
    },
    gray: {
      main: "#9DA4AE",
      light: "#F0F0F0",
      light100: "#F1F5F9",
      light200: "#f4f4f4",
      light300: "#666666",
      light400: "#A2A2A2",
      light500: "#E0E0E0",
      light600: "#e5e5e5",
      light700: "#faf8f8",
      light800: "#EBEBEB",
    },
    white: {
      main: "#ffffff",
    },
    black: {
      main: "#333333",
      dark: "#444444",
      light: "#6C737F",
      light100: "#171717",
    },
    danger: {
      main: "#B42318",
    },
    success: {
      main: "#009060",
    },
  },
  typography: {
    fontFamily: "'IBM Plex Sans Arabic', sans-serif",
  },
});

export default theme;
