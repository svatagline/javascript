import i18n from "i18next";
import LanguageDetector from "i18next-browser-languagedetector";
import Backend from "i18next-http-backend";
import { initReactI18next } from "react-i18next";

i18n
  .use(Backend)
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    // lng attribute will Override LanguageDetector
    lng: "en",
    fallbackLng: "en",
    debug: true,
    supportedLngs: ["en", "ar"],
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;
